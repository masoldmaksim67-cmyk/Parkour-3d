// Экраны меню: режимы, выбор карты (с учётом режима), настройки, статистика, достижения.
import { S, saveSettings, HUD_KEYS, getRec, fmt, STATS, recsForMap, recsForMode, ACHIEVED, resetAllProgress } from './state.js';
import { MAPS, SOON, drawPreview } from './maps.js';
import { MODES, MODE_BY_ID, supports, firstSupported } from './modes.js';
import { ACH_LIST, achCount } from './progress.js';

const $ = id => document.getElementById(id);
export const SEL = { mode: MODE_BY_ID[S.mode] ? S.mode : 'classic', map: S.map };
export const mapById = id => MAPS.find(m => m.id === id);
export const curMode = () => MODE_BY_ID[SEL.mode];
const DIFF = ['', 'ЛЁГКАЯ', 'СРЕДНЯЯ', 'СЛОЖНАЯ'];
const stars = n => { let s = ''; for (let i = 1; i <= 3; i++) s += i <= n ? '★' : '<i>★</i>'; return s; };
export const fmtDist = m => (m >= 1000 ? (m / 1000).toFixed(2) + ' км' : Math.round(m) + ' м');
export const fmtRec = (mode, v) => (v === null || v === undefined ? '--' : MODE_BY_ID[mode].rec === 'time' ? fmt(v) : MODE_BY_ID[mode].rec === 'dist' ? Math.round(v) + ' м' : Math.round(v) + ' очк.');
const esc = s => String(s).replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));

// синхронизировать выбор режима/карты (если карта не подходит режиму — выбрать первую подходящую)
export function normalizeSel() {
  if (!MODE_BY_ID[SEL.mode]) SEL.mode = 'classic';
  if (!mapById(SEL.map)) SEL.map = MAPS[0].id;
  if (!supports(SEL.mode, mapById(SEL.map)).ok) { const f = firstSupported(SEL.mode, MAPS); if (f) SEL.map = f.id; }
}
export function persistSel() { S.mode = SEL.mode; S.map = SEL.map; saveSettings(); }

/* ================= режимы ================= */
export function initModes(cb) {
  const grid = $('modeGrid'); grid.innerHTML = '';
  MODES.forEach(m => {
    const b = document.createElement('button'); b.type = 'button'; b.className = 'modecard'; b.dataset.id = m.id;
    b.innerHTML = '<span class="mi-ic">' + m.icon + '</span><span class="mi-n">' + m.name + '</span>';
    b.onclick = () => { SEL.mode = m.id; const had = SEL.map; normalizeSel(); persistSel(); refreshModes(); if (had !== SEL.map) cb.toast('Карта изменена на ' + mapById(SEL.map).name + ' — прежняя не поддерживает этот режим', 2800); cb.refreshMenu(); };
    grid.appendChild(b);
  });
  refreshModes();
}
export function refreshModes() {
  const m = curMode();
  document.querySelectorAll('#modeGrid .modecard').forEach(b => b.classList.toggle('sel', b.dataset.id === SEL.mode));
  const chips = MAPS.map(mp => { const s = supports(m.id, mp); return '<span class="chip ' + (s.ok ? 'ok' : 'no') + (mp.id === SEL.map ? ' cur' : '') + '" title="' + esc(s.why || '') + '">' + (s.ok ? '✓ ' : '✕ ') + mp.name + '</span>'; }).join('');
  const why = MAPS.map(mp => ({ mp, s: supports(m.id, mp) })).filter(x => !x.s.ok).map(x => '<li><b>' + x.mp.name + ':</b> ' + esc(x.s.why) + '</li>').join('');
  const rec = m.rec ? '<div class="mi-rec">Рекорд на «' + mapById(SEL.map).name + '»: <b>' + fmtRec(m.id, getRec(m.id, SEL.map)) + '</b></div>' : '<div class="mi-rec">Без рекордов — свободная тренировка</div>';
  $('modeInfo').innerHTML = '<h3>' + m.icon + ' ' + m.name + '</h3><p>' + m.desc + '</p><ul class="rules">' + m.rules.map(r => '<li>' + r + '</li>').join('') + '</ul>' + rec +
    '<div class="chips">' + chips + '</div>' + (why ? '<ul class="why">' + why + '</ul>' : '');
}

/* ================= карты ================= */
const cardEls = {};
export function initMaps(cb) {
  const grid = $('mapGrid'); grid.innerHTML = '';
  MAPS.concat(SOON).forEach(m => {
    const soon = !m.build, el = document.createElement('button'); el.className = 'mcard' + (soon ? ' soon' : ''); el.type = 'button';
    const cv = document.createElement('canvas'); el.appendChild(cv); drawPreview(cv, m);
    const info = document.createElement('div'); info.className = 'mi';
    info.innerHTML = '<h3>' + m.name + '</h3><p>' + m.desc + '</p><div class="meta"><span class="stars" title="' + DIFF[m.diff] + '">' + stars(m.diff) + '</span>' +
      (soon ? '<span>—</span>' : '<span data-recl></span>') + '</div>' + (soon ? '' : '<div class="tags">' + m.tags.map(t => '<span>' + t + '</span>').join('') + '</div>');
    el.appendChild(info);
    const rb = document.createElement('div'); rb.className = soon ? 'ribbon' : 'chk'; rb.textContent = soon ? 'СКОРО' : 'ВЫБРАНО'; el.appendChild(rb);
    if (!soon) {
      const lock = document.createElement('div'); lock.className = 'lock'; el.appendChild(lock);
      el.onclick = () => { const s = supports(SEL.mode, m); if (!s.ok) { cb.toast('✕ ' + s.why, 3200); return; } SEL.map = m.id; persistSel(); refreshMaps(); cb.refreshMenu(); };
      cardEls[m.id] = el;
    }
    grid.appendChild(el);
  });
  $('mapModeBar').onclick = () => cb.goto('modes');
  refreshMaps();
}
export function refreshMaps() {
  const md = curMode();
  $('mapModeBar').innerHTML = '<span>РЕЖИМ</span> <b>' + md.icon + ' ' + md.name + '</b> <u>ИЗМЕНИТЬ</u>';
  MAPS.forEach(m => {
    const el = cardEls[m.id], s = supports(SEL.mode, m); if (!el) return;
    el.classList.toggle('sel', m.id === SEL.map); el.classList.toggle('locked', !s.ok);
    el.querySelector('.lock').textContent = s.ok ? '' : '✕ ' + s.why;
    const r = el.querySelector('[data-recl]'); if (r) r.innerHTML = md.rec ? 'РЕКОРД <b>' + fmtRec(md.id, getRec(md.id, m.id)) + '</b>' : 'БЕЗ РЕКОРДОВ';
  });
}

/* ================= настройки ================= */
const QDESC = [
  'Без теней · дальность 200 м · фон 30% · без облаков · без эффектов скорости · разрешение ×1.0 — для слабых телефонов',
  'Тени 1024 · дальность 300 м · фон 65% · облака 50% · лёгкие эффекты · разрешение до ×1.5 — баланс для Android',
  'Тени 2048 · дальность 400 м · фон 100% · все облака · все эффекты · разрешение до ×2.0',
  'Мягкие тени 4096 · дальность 520 м · максимум детализации · разрешение до ×2.5 — для мощных устройств'
];
let setTab = 'sound';
export function initSettings(cb) {
  document.querySelectorAll('#setTabs button').forEach(b => { b.onclick = () => { setTab = b.dataset.t; renderSettings(cb); }; });
  renderSettings(cb);
}
function row(label, ctl) { const r = document.createElement('div'); r.className = 'row'; const l = document.createElement('label'); l.textContent = label; const c = document.createElement('div'); c.className = 'ctl'; c.appendChild(ctl); r.appendChild(l); r.appendChild(c); return r; }
function sw(get, set) {
  const b = document.createElement('button'); b.className = 'sw'; b.type = 'button'; const sync = () => b.classList.toggle('on', !!get());
  b.onclick = () => { set(!get()); sync(); }; sync(); b.sync = sync; return b;
}
export function renderSettings(cb) {
  document.querySelectorAll('#setTabs button').forEach(b => b.classList.toggle('on', b.dataset.t === setTab));
  const body = $('setBody'); body.innerHTML = '';
  const chg = k => { saveSettings(); cb.onSetting(k); };
  const range = (key, min, max, step, f) => {
    const w = document.createElement('div'); w.className = 'rw'; const i = document.createElement('input'); i.type = 'range'; i.min = min; i.max = max; i.step = step; i.value = S[key];
    const v = document.createElement('span'); v.className = 'val'; v.textContent = f(S[key]);
    i.oninput = () => { S[key] = +i.value; v.textContent = f(S[key]); chg(key); }; w.appendChild(i); w.appendChild(v); return w;
  };
  const sws = (label, key) => body.appendChild(row(label, sw(() => S[key], v => { S[key] = v; chg(key); })));
  if (setTab === 'sound') {
    body.appendChild(row('Общая громкость', range('volume', 0, 1, 0.05, v => Math.round(v * 100) + '%')));
    body.appendChild(row('Громкость звуковых эффектов', range('sfx', 0, 1, 0.05, v => Math.round(v * 100) + '%')));
    sws('Звуковые эффекты', 'sound'); sws('Музыка', 'music'); sws('Вибрация', 'vibration');
  } else if (setTab === 'gfx') {
    const seg = document.createElement('div'); seg.className = 'seg';
    ['LOW', 'MEDIUM', 'HIGH', 'ULTRA'].forEach((n, i) => { const b = document.createElement('button'); b.textContent = n; b.classList.toggle('on', S.quality === i); b.onclick = () => { S.quality = i; chg('quality'); renderSettings(cb); }; seg.appendChild(b); });
    body.appendChild(row('Качество графики', seg));
    const note = document.createElement('p'); note.className = 'qnote'; note.textContent = QDESC[S.quality]; body.appendChild(note);
    const n2 = document.createElement('p'); n2.className = 'qnote dim'; n2.textContent = 'Тени, дальность, облака, свет и эффекты меняются сразу. Плотность фонового декора применяется при следующем запуске/рестарте карты. Разрешение подстраивается автоматически по FPS.'; body.appendChild(n2);
    sws('Эффект скорости (FOV, линии)', 'speedFx');
  } else if (setTab === 'game') {
    body.appendChild(row('Чувствительность камеры', range('sens', 0.3, 2.5, 0.1, v => (+v).toFixed(1))));
    sws('Покачивание и анимации камеры', 'bob'); sws('Наклон камеры (стрейф / серф)', 'tilt'); sws('Нож от первого лица', 'knife'); sws('Авто-прыжок (удержание JUMP)', 'autoHop');
    const fs = sw(() => S.fs, () => cb.toggleFs()); fs.id = 'swFs'; body.appendChild(row('Полноэкранный режим', fs));
  } else {
    HUD_KEYS.forEach(([k, l]) => body.appendChild(row(l, sw(() => S.hud[k], v => { S.hud[k] = v; chg('hud'); }))));
    const p = document.createElement('p'); p.className = 'qnote dim'; p.textContent = 'HUD автоматически подстраивается под режим: элементы, которых нет в режиме, не показываются.'; body.appendChild(p);
  }
}
export function syncFsSwitch() { const b = $('swFs'); if (b && b.sync) b.sync(); }

/* ================= статистика ================= */
let stTab = 'all';
const tm = s => { s = Math.round(s || 0); const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60); return h ? h + ' ч ' + m + ' мин' : m + ' мин ' + (s % 60) + ' с'; };
const card = (l, v) => '<div class="scard"><span>' + l + '</span><b>' + v + '</b></div>';
const blockStats = o => card('Попытки', o.attempts || 0) + card('Финиши', o.finishes || 0) + card('Падения', o.falls || 0) + card('Успешные BHOP', o.bhops || 0) +
  card('Лучшая серия BHOP', o.bestStreak || 0) + card('Макс. скорость', Math.round((o.maxSpeed || 0) * 3.6) + ' км/ч') + card('Дистанция', fmtDist(o.distance || 0));
export function initStats() {
  document.querySelectorAll('#stTabs button').forEach(b => { b.onclick = () => { stTab = b.dataset.t; renderStats(); }; });
  $('stReset').onclick = () => { if (confirm('Удалить всю статистику, рекорды и достижения?')) resetAllProgress(); };
}
export function renderStats() {
  document.querySelectorAll('#stTabs button').forEach(b => b.classList.toggle('on', b.dataset.t === stTab));
  const body = $('stBody'); let h = '';
  if (stTab === 'all') {
    const t = STATS.total; h = '<div class="sgrid">' + blockStats(t) + card('Прыжки', t.jumps || 0) + card('Время в игре', tm(t.playTime)) + card('Достижения', achCount() + ' / ' + ACH_LIST.length) + '</div>';
  } else if (stTab === 'maps') {
    h = MAPS.map(m => { const o = STATS.maps[m.id] || {}, r = recsForMap(m.id); const recs = Object.keys(r).filter(k => MODE_BY_ID[k]).map(k => '<span class="rc">' + MODE_BY_ID[k].icon + ' ' + MODE_BY_ID[k].name + ' <b>' + fmtRec(k, r[k]) + '</b></span>').join('') || '<span class="rc dim">рекордов пока нет</span>';
      return '<div class="sblock"><h4>' + m.name + '</h4><div class="sgrid">' + blockStats(o) + '</div><div class="recs">' + recs + '</div></div>'; }).join('');
  } else {
    h = MODES.map(m => { const o = STATS.modes[m.id] || {}, r = recsForMode(m.id); const recs = m.rec ? (Object.keys(r).map(k => { const mp = mapById(k); return mp ? '<span class="rc">' + mp.name + ' <b>' + fmtRec(m.id, r[k]) + '</b></span>' : ''; }).join('') || '<span class="rc dim">рекордов пока нет</span>') : '<span class="rc dim">режим без рекордов</span>';
      return '<div class="sblock"><h4>' + m.icon + ' ' + m.name + '</h4><div class="sgrid">' + blockStats(o) + '</div><div class="recs">' + recs + '</div></div>'; }).join('');
  }
  body.innerHTML = h;
}

/* ================= достижения ================= */
export function renderAch() {
  $('achCount').textContent = achCount() + ' / ' + ACH_LIST.length;
  $('achGrid').innerHTML = ACH_LIST.map(a => { const t = ACHIEVED[a.id]; return '<div class="ach ' + (t ? 'done' : '') + '"><span class="ai">' + (t ? a.icon : '🔒') + '</span><div><b>' + a.name + '</b><p>' + a.desc + '</p><em>' + (t ? 'ВЫПОЛНЕНО · ' + new Date(t).toLocaleDateString() : 'не выполнено') + '</em></div></div>'; }).join('');
}
