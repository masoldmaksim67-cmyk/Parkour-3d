// Игровые режимы: правила, HUD и совместимость с картами.
// kind рекорда: 'time' (меньше — лучше), 'score' (больше — лучше), 'dist' (больше — лучше).
export const MODES = [
  {
    id: 'classic', name: 'CLASSIC PARKOUR', icon: '🏁', rec: 'time',
    desc: 'Пройдите карту от старта до финиша. Контрольные точки сохраняют прогресс — после падения вы возродитесь на последней из них.',
    rules: ['Таймер стартует при первом движении', 'Падение → возрождение на чекпоинте', 'Рекорд сохраняется — улучшайте время'],
    hud: ['main', 'falls', 'cp', 'prog', 'speed', 'max', 'mode']
  },
  {
    id: 'timeattack', name: 'TIME ATTACK', icon: '⏱', rec: 'time',
    desc: 'Гонка со временем. Обратный отсчёт 3-2-1, таймер идёт с первой секунды. Каждое падение добавляет штраф +5 секунд.',
    rules: ['Отсчёт 3-2-1 и автоматический старт', 'Падение = штраф +5 с к итоговому времени', 'Результат и лучшее время на финише'],
    hud: ['main', 'falls', 'cp', 'prog', 'speed', 'max', 'mode']
  },
  {
    id: 'bhop', name: 'BHOP CHALLENGE', icon: '🐇', rec: 'score',
    desc: 'Цель — не время, а чистая техника: набирайте скорость длинными сериями Bunny Hop. Очки = успешные BHOP × 10 + макс. скорость.',
    rules: ['Считаются прыжки в серии (приземление → мгновенный прыжок)', 'Падение обрывает серию', 'Финиш завершает попытку, рекорд — по очкам'],
    hud: ['main', 'falls', 'prog', 'speed', 'max', 'bhop', 'mode']
  },
  {
    id: 'speedrun', name: 'SPEEDRUN', icon: '⚡', rec: 'time',
    desc: 'Для опытных. Падение = сброс забега с самого старта. На чекпоинтах показывается разница со сплитами вашего рекорда.',
    rules: ['Падение сбрасывает забег (счётчик RESET)', 'Сплиты на чекпоинтах относительно рекорда', 'Быстрый рестарт: R или кнопка ⟲'],
    hud: ['main', 'falls', 'cp', 'prog', 'speed', 'max', 'mode']
  },
  {
    id: 'endless', name: 'ENDLESS PARKOUR', icon: '♾', rec: 'dist',
    desc: 'Каждый раз новая процедурная трасса, сложность растёт: площадки мельче, прыжки длиннее. Одно падение — и попытка окончена.',
    rules: ['Случайная трасса при каждой попытке', 'Только проходимые прыжки, сложность растёт', 'Рекорд — дистанция в метрах'],
    hud: ['main', 'speed', 'max', 'bhop', 'mode']
  },
  {
    id: 'freeroam', name: 'FREE ROAM', icon: '🧭', rec: null,
    desc: 'Свободная тренировка без таймера и финиша. Отрабатывайте Bunny Hop, Air Strafe и Surf. Падение — возврат на последний чекпоинт.',
    rules: ['Нет таймера и обязательного финиша', 'Кнопка ⟲ — возврат на старт', 'Счётчики скорости и BHOP для тренировки'],
    hud: ['speed', 'max', 'bhop', 'falls', 'mode']
  },
  {
    id: 'checkpoint', name: 'CHECKPOINT CHALLENGE', icon: '🚩', rec: 'time',
    desc: 'Карта разбита на этапы — каждый сложнее прошлого. Активна только следующая точка. Показывается время каждого этапа и падения на нём.',
    rules: ['Активна только следующая контрольная точка', 'Падение → возврат на последнюю пройденную', 'Итог: время этапов и число падений'],
    hud: ['main', 'falls', 'cp', 'prog', 'speed', 'mode']
  }
];
export const MODE_BY_ID = Object.fromEntries(MODES.map(m => [m.id, m]));

// Совместимость режима и карты. Возвращает { ok, why }.
export function supports(modeId, map) {
  if (!map) return { ok: false, why: 'Карта недоступна' };
  const procedural = !!map.procedural;
  if (modeId === 'endless') return procedural ? { ok: true } : { ok: false, why: 'ENDLESS работает только на процедурной карте ENDLESS TRACK' };
  if (procedural) {
    if (modeId === 'freeroam') return { ok: true };
    return { ok: false, why: 'Процедурная трасса без чекпоинтов: подходит только ENDLESS и FREE ROAM' };
  }
  if (modeId === 'speedrun' && map.diff < 2) return { ok: false, why: 'Слишком лёгкая трасса для SPEEDRUN — нужна сложность СРЕДНЯЯ или выше' };
  if (modeId === 'bhop' && !map.bhopOk) return { ok: false, why: 'Нет длинных участков для разгона' };
  if (modeId === 'checkpoint' && (map.cps || 0) < 4) return { ok: false, why: 'Мало контрольных точек для этапов' };
  return { ok: true };
}
export function firstSupported(modeId, maps) { return maps.find(m => supports(modeId, m).ok) || null; }
