// Физика игрока: Source-подобное движение (ускорение, трение, air-strafe, bunny hop),
// скольжение (slide) и серф по наклонным плоскостям. Фиксированный шаг K.STEP.
import { COL, RAMPS, MOV, updateMoverPos } from './collision.js';

export const HW = 0.3, EPS = 1e-4;
export const K = {
  STEP: 1 / 120,
  JUMP: 8.6, G_UP: 22, G_DN: 30,
  RUN: 8.2, WALK: 5.0, CROUCH: 2.4,
  GROUND_ACCEL: 9, FRICTION: 4.8, STOP: 2.4,
  AIR_ACCEL: 14, AIR_CAP: 1.0,
  SOFT: 21, SOFT_SURF: 26, HARD: 32,
  SLIDE_MIN: 6.0, SLIDE_FRIC: 0.9, SLIDE_BOOST: 1.06,
  WALK_NY: 0.7, SNAP: 0.14
};

export const P = {
  x: 0, y: 20, z: 3, vx: 0, vy: 0, vz: 0, yaw: 0, pitch: 0,
  onGround: false, ground: null, coyote: 0, h: 1.8, eye: 1.62, crouch: false, slide: 0, hs: 0,
  groundT: 0, hopT: 9, hops: 0, surfT: 0, surfNx: 0, surfNy: 1, surfNz: 0, surfed: false,
  bobPh: 0, bobAmp: 0, bobY: 0, bobR: 0, landY: 0, landV: 0, kick: 0, kickV: 0, roll: 0, fovX: 0,
  killY: -10, fallT: 0, stepIdx: 0
};
export const IN = { x: 0, y: 0, run: false, keyRun: false, crouchWant: false, jumpHeld: false, jumpBuf: 0, autoHop: true };
// Колбэки событий (назначаются из main)
export const EV = { land: null, jump: null, slide: null, uncrouch: null, bhop: null };

let simT = 0, gndNow = false;
const NEAR = [], NEARR = [];
const PEN = { depth: 0 };

export function resetSim() { simT = 0; }

export function gather() {
  NEAR.length = 0; NEARR.length = 0;
  for (let i = 0; i < COL.length; i++) {
    const c = COL[i];
    if (c.maxX > P.x - 8 && c.minX < P.x + 8 && c.maxZ > P.z - 8 && c.minZ < P.z + 8 && c.maxY > P.y - 5 && c.minY < P.y + P.h + 5) NEAR.push(c);
  }
  for (let i = 0; i < RAMPS.length; i++) {
    const r = RAMPS[i];
    if (r.maxX > P.x - 6 && r.minX < P.x + 6 && r.maxZ > P.z - 6 && r.minZ < P.z + 6 && r.maxY > P.y - 6 && r.minY < P.y + P.h + 6) NEARR.push(r);
  }
}

const ov = c => P.x + HW > c.minX && P.x - HW < c.maxX && P.z + HW > c.minZ && P.z - HW < c.maxZ && P.y + P.h > c.minY && P.y < c.maxY;

// Проникновение AABB игрока в выпуклую плиту: возвращает плоскость минимального проникновения (глубина в PEN.depth)
function penetrate(r) {
  if (P.x + HW <= r.minX || P.x - HW >= r.maxX || P.z + HW <= r.minZ || P.z - HW >= r.maxZ || P.y + P.h <= r.minY || P.y >= r.maxY) return null;
  const cy = P.y + P.h * 0.5, hh = P.h * 0.5;
  let best = 1e9, bp = null;
  for (let i = 0; i < 6; i++) {
    const pl = r.planes[i];
    const ext = Math.abs(pl.nx) * HW + Math.abs(pl.ny) * hh + Math.abs(pl.nz) * HW;
    const depth = pl.d - (pl.nx * P.x + pl.ny * cy + pl.nz * P.z - ext);
    if (depth <= 0) return null;
    if (depth < best) { best = depth; bp = pl; }
  }
  PEN.depth = best; return bp;
}
function blockedNow() {
  for (let i = 0; i < NEAR.length; i++) if (ov(NEAR[i])) return true;
  for (let i = 0; i < NEARR.length; i++) if (penetrate(NEARR[i])) return true;
  return false;
}
function setCrouch(want) {
  if (want) { if (!P.crouch) { P.crouch = true; P.h = 1.1; } }
  else if (P.crouch) { P.h = 1.8; if (blockedNow()) P.h = 1.1; else P.crouch = false; }
}
function depen(c) {
  if (!ov(c)) return;
  const up = c.maxY - P.y, dn = P.y + P.h - c.minY, xp = c.maxX - (P.x - HW), xn = P.x + HW - c.minX, zp = c.maxZ - (P.z - HW), zn = P.z + HW - c.minZ;
  let m = up, k = 0; if (dn < m) { m = dn; k = 1; } if (xp < m) { m = xp; k = 2; } if (xn < m) { m = xn; k = 3; } if (zp < m) { m = zp; k = 4; } if (zn < m) { m = zn; k = 5; }
  switch (k) {
    case 0: P.y = c.maxY; if (P.vy < 0) P.vy = 0; break;
    case 1: P.y = c.minY - P.h - EPS; if (P.vy > 0) P.vy = 0; break;
    case 2: P.x = c.maxX + HW + EPS; break; case 3: P.x = c.minX - HW - EPS; break;
    case 4: P.z = c.maxZ + HW + EPS; break; default: P.z = c.minZ - HW - EPS;
  }
}
function moveH(axis, d) {
  if (d === 0) return;
  if (axis === 0) P.x += d; else P.z += d;
  for (let i = 0; i < NEAR.length; i++) {
    const c = NEAR[i]; if (!ov(c)) continue;
    const su = c.maxY - P.y;
    if (su > 0 && su <= (gndNow ? 0.5 : 0.6) && P.vy <= 3) {
      const y0 = P.y; P.y = c.maxY + 0.002; let blk = false;
      for (let j = 0; j < NEAR.length; j++) if (NEAR[j] !== c && ov(NEAR[j])) { blk = true; break; }
      if (!blk) { P.y = c.maxY; continue; } P.y = y0;
    }
    if (axis === 0) { if (d > 0) P.x = c.minX - HW - EPS; else P.x = c.maxX + HW + EPS; P.vx = 0; }
    else { if (d > 0) P.z = c.minZ - HW - EPS; else P.z = c.maxZ + HW + EPS; P.vz = 0; }
  }
}
function onLand(imp, c) {
  if (c.mv) { P.vx -= c.mv.vx; P.vz -= c.mv.vz; }
  const pending = IN.jumpBuf > 0 || (IN.jumpHeld && IN.autoHop);
  if (imp > 17 && !pending) { P.vx *= 0.65; P.vz *= 0.65; } // жёсткое приземление без прыжка гасит скорость
  if (EV.land) EV.land(imp);
}

// ---- наклонные плоскости ----
function rampContact(r, pl, depth) {
  if (pl.ny >= K.WALK_NY) {
    // проходимый склон: выталкиваем по вертикали, скорость остаётся параллельна склону
    const vn = P.vx * pl.nx + P.vy * pl.ny + P.vz * pl.nz;
    P.y += depth / pl.ny + 0.0003;
    if (vn <= 0.05) {
      const imp = -P.vy;
      P.vy = -(P.vx * pl.nx + P.vz * pl.nz) / pl.ny;
      P.onGround = true; P.ground = r;
      if (!gndNow && imp > 3) onLand(imp, r);
    }
  } else {
    // крутая плоскость (surf) или стена: выталкиваем по нормали, обрезаем скорость
    const push = depth + EPS;
    P.x += pl.nx * push; P.y += pl.ny * push; P.z += pl.nz * push;
    const vn = P.vx * pl.nx + P.vy * pl.ny + P.vz * pl.nz;
    if (vn < 0) { P.vx -= pl.nx * vn; P.vy -= pl.ny * vn; P.vz -= pl.nz * vn; }
    if (pl.ny > 0.04) { P.surfT = 0.12; P.surfNx = pl.nx; P.surfNy = pl.ny; P.surfNz = pl.nz; P.surfed = true; }
  }
}
function resolveRamps() {
  for (let it = 0; it < 3; it++) {
    let any = false;
    for (let i = 0; i < NEARR.length; i++) {
      const r = NEARR[i], pl = penetrate(r);
      if (!pl) continue; any = true; rampContact(r, pl, PEN.depth);
    }
    if (!any) break;
  }
}
function snapToRamp() {
  P.y -= K.SNAP;
  for (let i = 0; i < NEARR.length; i++) {
    const r = NEARR[i], pl = penetrate(r);
    if (pl && pl.ny >= K.WALK_NY) {
      P.y += PEN.depth / pl.ny + 0.0003; P.vy = -(P.vx * pl.nx + P.vz * pl.nz) / pl.ny;
      P.onGround = true; P.ground = r; return;
    }
  }
  P.y += K.SNAP;
}

// ---- движение ----
function friction(h, coef) {
  const sp = Math.hypot(P.vx, P.vz); if (sp < 0.001) return;
  const drop = Math.max(sp, K.STOP) * coef * h, ns = Math.max(0, sp - drop) / sp;
  P.vx *= ns; P.vz *= ns;
}
function accelerate(dx, dz, wishspeed, accel, h) {
  const cur = P.vx * dx + P.vz * dz, add = wishspeed - cur;
  if (add <= 0) return;
  const a = Math.min(add, accel * wishspeed * h);
  P.vx += dx * a; P.vz += dz * a;
}
function airMove(h, wx, wz, m) {
  if (m <= 0.02) return;
  const dl = Math.hypot(wx, wz) || 1, dx = wx / dl, dz = wz / dl;
  const wishspeed = m * K.RUN, wishspd = Math.min(wishspeed, K.AIR_CAP);
  const add = wishspd - (P.vx * dx + P.vz * dz);
  if (add <= 0) return;
  const a = Math.min(add, K.AIR_ACCEL * wishspeed * h);
  P.vx += dx * a; P.vz += dz * a;
}
function groundMove(h, wx, wz, m, runOn) {
  const spd = Math.hypot(P.vx, P.vz);
  if (P.crouch && P.slide <= 0 && spd > K.SLIDE_MIN) {
    P.slide = 0.001;
    if (spd < 13) { P.vx *= K.SLIDE_BOOST; P.vz *= K.SLIDE_BOOST; }
    if (EV.slide) EV.slide();
  }
  if (P.slide > 0) {
    P.slide += h;
    if (!P.crouch) P.slide = 0;
    else if (spd < 2.8) { P.slide = 0; IN.crouchWant = false; if (EV.uncrouch) EV.uncrouch(); }
  }
  if (P.slide > 0) {
    // скольжение: малое трение, лёгкое рулевое управление без прибавки скорости
    friction(h, K.SLIDE_FRIC * (P.slide < 0.25 ? 0.4 + P.slide * 2.4 : 1));
    if (m > 0.05) {
      const ca = Math.atan2(P.vz, P.vx), ta = Math.atan2(wz, wx), sp = Math.hypot(P.vx, P.vz);
      let da = ta - ca; while (da > Math.PI) da -= 2 * Math.PI; while (da < -Math.PI) da += 2 * Math.PI;
      const lim = 1.3 * m * h; da = da > lim ? lim : da < -lim ? -lim : da;
      P.vx = Math.cos(ca + da) * sp; P.vz = Math.sin(ca + da) * sp;
    }
    return;
  }
  friction(h, K.FRICTION);
  const base = P.crouch ? K.CROUCH : runOn ? K.RUN : K.WALK, dl = Math.hypot(wx, wz);
  if (dl > 0.001) accelerate(wx / dl, wz / dl, Math.min(1, m) * base, K.GROUND_ACCEL, h);
}

export function stepPhysics(h) {
  simT += h;
  for (let i = 0; i < MOV.length; i++) updateMoverPos(MOV[i], h, simT);
  const prevG = P.ground, gnd = P.onGround; gndNow = gnd;
  if (gnd && prevG && prevG.mv) { P.x += prevG.mv.dx; P.y += prevG.mv.dy; P.z += prevG.mv.dz; }
  for (let i = 0; i < MOV.length; i++) depen(MOV[i].col);
  if (IN.crouchWant !== P.crouch) setCrouch(IN.crouchWant);

  if (gnd) { P.coyote = 0.11; P.groundT += h; } else { P.coyote -= h; P.groundT = 0; }
  P.hopT += h; IN.jumpBuf -= h; P.surfT -= h;

  const sy = Math.sin(P.yaw), cy = Math.cos(P.yaw);
  let ix = IN.x, iy = IN.y, m = Math.hypot(ix, iy); if (m > 1) { ix /= m; iy /= m; m = 1; }
  const wx = -sy * iy + cy * ix, wz = -cy * iy - sy * ix;

  // ---- прыжок (jump buffer + coyote + auto-hop) ----
  let jumped = false;
  const wantJump = IN.jumpBuf > 0 || (IN.jumpHeld && IN.autoHop);
  if (wantJump && (gnd || P.coyote > 0)) {
    // бхоп: прыжок в первый тик контакта — трение не применяется, скорость сохраняется
    if (P.groundT < 0.13 && P.hopT < 1.6) P.hops++; else P.hops = 1;
    P.hopT = 0;
    P.vy = K.JUMP + Math.max(0, P.vy); IN.jumpBuf = 0; P.coyote = 0; jumped = true; P.slide = 0;
    if (P.crouch) { IN.crouchWant = false; if (EV.uncrouch) EV.uncrouch(); setCrouch(false); }
    if (EV.jump) EV.jump();
    if (EV.bhop && P.hops >= 2) EV.bhop(P.hops);
  } else if (IN.jumpBuf > 0 && P.surfT > 0 && !gnd) {
    // отскок от поверхности серфа
    P.vx += P.surfNx * 3.2; P.vz += P.surfNz * 3.2; P.vy = Math.max(P.vy, 0) + 6.5; P.surfT = 0; IN.jumpBuf = 0; P.hopT = 0;
    if (EV.jump) EV.jump();
  }

  const grounded = gnd && !jumped;
  const runOn = IN.run || IN.keyRun;
  if (grounded) groundMove(h, wx, wz, m, runOn);
  else { P.slide = 0; airMove(h, wx, wz, m); }

  P.vy -= (P.vy > 0 ? K.G_UP : K.G_DN) * h; if (P.vy < -45) P.vy = -45;

  // мягкий и жёсткий пределы горизонтальной скорости
  let hs = Math.hypot(P.vx, P.vz);
  const soft = P.surfT > 0 ? K.SOFT_SURF : K.SOFT;
  if (hs > soft) { const t = hs - (hs - soft) * 1.3 * h; P.vx *= t / hs; P.vz *= t / hs; hs = t; }
  if (hs > K.HARD) { P.vx *= K.HARD / hs; P.vz *= K.HARD / hs; }

  moveH(0, P.vx * h); moveH(1, P.vz * h);
  P.onGround = false; P.ground = null; P.surfed = false;
  P.y += P.vy * h;
  for (let i = 0; i < NEAR.length; i++) {
    const c = NEAR[i]; if (!ov(c)) continue;
    if (P.vy <= 0) { const imp = -P.vy; P.y = c.maxY; P.vy = 0; P.onGround = true; P.ground = c; if (!gnd && imp > 3) onLand(imp, c); }
    else { P.y = c.minY - P.h - EPS; P.vy = 0; }
  }
  resolveRamps();
  if (gnd && !P.onGround && !jumped && prevG && prevG.ramp) snapToRamp();
  if (gnd && !P.onGround && prevG && prevG.mv) { P.vx += prevG.mv.vx; P.vz += prevG.mv.vz; if (prevG.mv.vy > 0) P.vy += prevG.mv.vy; }
}

export function resetPlayer(x, y, z) {
  P.x = x; P.y = y; P.z = z; P.vx = P.vy = P.vz = 0; P.yaw = 0; P.pitch = 0; P.onGround = false; P.ground = null;
  P.h = 1.8; P.crouch = false; P.slide = 0; P.landY = P.landV = P.kick = P.kickV = 0; P.coyote = 0; P.groundT = 0; P.hops = 0; P.hopT = 9; P.surfT = 0;
  IN.jumpBuf = 0; IN.crouchWant = false; IN.x = IN.y = 0;
}
