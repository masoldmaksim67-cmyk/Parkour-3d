// Главный модуль: ввод, HUD, камера, игровой цикл, режимы, меню.
import './boot.js';
import { S, saveSettings, fmt, getRec, setRec, addStats, STATS, LS } from './state.js';
import { THREE, renderer, scene, camera, sky, sunSprite, lightDir, updateShadow, applyQuality as coreApplyQuality, QUAL, W, clamp, qualityParams } from './core.js';
import { MAPS, loadMap } from './maps.js';
import { CPS } from './collision.js';
import { P, IN, K, EV, gather, stepPhysics, resetPlayer } from './physics.js';
import { AU, buzz } from './audio.js';
import { createKnife } from './knife.js';
import { MODE_BY_ID, supports } from './modes.js';
import { ACH_LIST, award, achCount } from './progress.js';
import { applyLayout, openEditor } from './controls.js';
import * as UI from './screens.js';

const $ = id => document.getElementById(id);
const knife = createKnife();
const SEL = UI.SEL;

/* ---------- состояние ---------- */
let state = 'menu', menuT = 0, blend = 1, baseFov = 72;
let curMap = null, routePts = [], runMode = SEL.mode;
const R = {
  time: 0, falls: 0, cp: 0, started: false, maxSpeed: 0, bhops: 0, bestStreak: 0, jumps: 0, dist: 0, travel: 0, penalty: 0, cd: 0, cdN: 0,
  stageT: 0, stageTimes: [], stageFalls: [], stageFallsCur: 0, splits: [], splitMsg: '', splitT: 0, pb: null,
  surfRun: 0, surfGap: 0, surfPend: 0, finTouch: 0, flush: 0, lx: 0, lz: 0
};
const blendPos = new THREE.Vector3(), blendQuat = new THREE.Quaternion(), tq = new THREE.Quaternion(), tv = new THREE.Vector3(), te = new THREE.Euler(0, 0, 0, 'YXZ');
let acc = 0, px0 = 0, py0 = 0, pz0 = 0, rX = 0, rY = 0, rZ = 0;
let prevYaw = 0, prevPitch = 0, surfRoll = 0;
const keys = {};
const joy = { id: null, cx: 0, cy: 0, R: 60, size: 130, x: 0, y: 0, defX: 20, defY: 200 };
const look = { id: null, x: 0, y: 0 };
const mode = () => MODE_BY_ID[runMode];

/* ---------- статистика (накопление и сохранение) ---------- */
const pend = { attempts: 0, finishes: 0, falls: 0, bhops: 0, jumps: 0, distance: 0, playTime: 0, maxSpeed: 0, bestStreak: 0 };
function flush() {
  let any = false; Object.keys(pend).forEach(k => { if (pend[k]) any = true; });
  if (!any || !curMap) return;
  addStats(pend, curMap.id, runMode); Object.keys(pend).forEach(k => { pend[k] = 0; });
}
window.addEventListener('beforeunload', flush);

/* ---------- достижения ---------- */
let achQ = [], achBusy = false;
const achEl = document.createElement('div'); achEl.id = 'achPop'; $('toast').before(achEl);
function grant(id) {
  const a = award(id); if (!a) return;
  achQ.push(a); if (!achBusy) nextAch();
}
function nextAch() {
  const a = achQ.shift(); if (!a) { achBusy = false; return; }
  achBusy = true; achEl.innerHTML = a.icon + ' ДОСТИЖЕНИЕ: ' + a.name + '<small>' + a.desc + '</small>'; achEl.classList.add('show'); AU.ach();
  setTimeout(() => { achEl.classList.remove('show'); setTimeout(nextAch, 450); }, 2800);
}

/* ---------- карта ---------- */
function loadAndPrepare(id) {
  curMap = loadMap(id);
  routePts = [W.START].concat(CPS, [W.FINISH]).map(p => new THREE.Vector3(p.x, p.y, p.z));
  $('hMap').textContent = curMap.name;
  applyQuality(); resetGame(); menuT = 0;
}

/* ---------- события физики ---------- */
EV.land = imp => {
  AU.land(imp); if (imp > 11) buzz(14);
  if (S.bob) { P.landV = -Math.min(imp * 0.2, 3.6); P.kickV = -Math.min(imp * 0.03, 0.5); }
  knife.landKick(imp);
};
EV.jump = () => {
  AU.jump(); if (S.bob) { P.landV += 0.9; P.kickV += 0.45; } knife.jumpKick();
  if (state !== 'play') return;
  R.jumps++; pend.jumps++; grant('first_jump');
  if (STATS.total.jumps + pend.jumps >= 100) grant('jumps_100');
};
EV.slide = () => { AU.slide(); buzz(10); if (state === 'play') grant('slider'); };
EV.uncrouch = () => { $('bCrouch').classList.remove('on'); };
EV.bhop = n => {
  if (state !== 'play') return;
  R.bhops++; pend.bhops++; if (n > R.bestStreak) { R.bestStreak = n; if (n > pend.bestStreak) pend.bestStreak = n; }
  AU.bhop(n); grant('first_bhop'); if (n >= 10) grant('bhop_10');
};

/* ---------- HUD ---------- */
const E = {}; ['hTime', 'hFalls', 'hCp', 'hCpMax', 'hProg', 'hSpd', 'hSpBar', 'hTag', 'hMax', 'hBhop', 'hBigW', 'hBigL', 'hExtra', 'hModeN', 'hFallsL', 'hCpL', 'countdown'].forEach(i => { E[i] = $(i); });
const fx = $('speedfx');
const tcache = {};
function setT(id, v) { v = String(v); if (tcache[id] !== v) { tcache[id] = v; E[id].textContent = v; } }
function applyHudVis() {
  const set = new Set(mode().hud);
  document.querySelectorAll('#hud [data-h]').forEach(el => { const k = el.dataset.h; el.classList.toggle('off', !set.has(k) || S.hud[k] === false); });
  const cpOn = runMode !== 'endless' && runMode !== 'freeroam' && runMode !== 'bhop';
  document.querySelector('[data-h="cp"]').classList.toggle('off', !cpOn || !set.has('cp') || S.hud.cp === false);
  E.hBigW.classList.toggle('xl', runMode === 'timeattack');
  setT('hModeN', mode().name); E.hCpMax.textContent = CPS.length;
  setT('hFallsL', runMode === 'speedrun' ? 'СБРОСЫ' : 'ПАДЕНИЯ');
  const m = mode(), cpL = runMode === 'checkpoint' ? 'ЭТАП' : 'ЧЕКПОИНТ'; setT('hCpL', cpL);
  const L = { classic: 'ВРЕМЯ', timeattack: 'TIME ATTACK', speedrun: 'SPEEDRUN', bhop: 'УСПЕШНЫЕ BHOP', endless: 'ДИСТАНЦИЯ', checkpoint: 'ЭТАП' }[runMode] || ''; setT('hBigL', L);
  void m;
}
const total = () => R.time + R.penalty;
const score = () => R.bhops * 10 + Math.round(R.maxSpeed * 3.6);
let lastFx = '', lastTag = '';
function updateHud() {
  const hs = P.hs, kmh = Math.round(hs * 3.6);
  setT('hSpd', kmh); setT('hMax', Math.round(R.maxSpeed * 3.6)); setT('hBhop', R.bhops); setT('hFalls', R.falls);
  E.hSpBar.style.transform = 'scaleX(' + clamp(hs / 22, 0, 1).toFixed(3) + ')';
  const fin = W.FINISH, sz = W.START.z;
  E.hProg.style.transform = 'scaleX(' + clamp((sz - P.z) / (sz - fin.z), 0, 1).toFixed(3) + ')';
  const streak = P.hopT < 1.3 && P.hops >= 2 ? P.hops : 0;
  let big = '', extra = '', neg = false;
  switch (runMode) {
    case 'classic': case 'speedrun': big = fmt(R.time); break;
    case 'timeattack': big = fmt(total()); extra = R.penalty ? 'ШТРАФ +' + R.penalty + ' с' : ''; break;
    case 'checkpoint': big = fmt(R.stageT); setT('hCp', Math.min(R.cp + 1, CPS.length + 1)); extra = 'ВСЕГО ' + fmt(R.time); break;
    case 'bhop': big = R.bhops; extra = 'СЕРИЯ ' + streak + ' · ЛУЧШАЯ ' + R.bestStreak + ' · ОЧКИ ' + score(); break;
    case 'endless': big = Math.round(R.dist) + ' м'; extra = 'УРОВЕНЬ ' + (1 + Math.floor(R.dist / 150)) + ' · РЕКОРД ' + Math.round(getRec('endless', 'endless') || 0) + ' м'; break;
    case 'freeroam': extra = 'FREE ROAM · без таймера' + (streak ? ' · серия ' + streak : ''); break;
  }
  if (runMode === 'speedrun' && R.splitT > 0) { extra = R.splitMsg; neg = R.splitMsg.indexOf('−') >= 0; }
  if (runMode === 'speedrun' && !extra) extra = 'ПОПЫТКА #' + (R.falls + 1);
  setT('hTime', big); setT('hExtra', extra); E.hBigW.classList.toggle('neg', neg);
  if (runMode !== 'checkpoint') setT('hCp', R.cp);
  let tag = '', cls = '';
  if (P.surfT > 0 && !P.onGround) { tag = 'SURF'; cls = 'surf'; } else if (P.slide > 0) { tag = 'SLIDE'; cls = 'slide'; } else if (P.hops >= 3 && P.hopT < 1.3) tag = 'BHOP ×' + P.hops;
  if (tag !== lastTag) { E.hTag.textContent = tag; E.hTag.className = 'hTag' + (tag ? ' on ' + cls : ''); lastTag = tag; }
  const fq = qualityParams().fx, o = S.speedFx && fq > 0 ? (clamp((hs - 10) / 11, 0, 0.85) * (fq === 1 ? 0.6 : 1)).toFixed(2) : '0';
  if (o !== lastFx) { fx.style.opacity = o; lastFx = o; }
}
let toastT = 0;
function toast(msg, ms) {
  const t = $('toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), ms || 2000);
}
function showCountdown(txt) { const c = E.countdown; c.textContent = txt; c.classList.remove('pop'); void c.offsetWidth; c.classList.add('pop'); }

/* ---------- игровой процесс ---------- */
const stageCol = i => (i < R.cp ? 0x45ff90 : i === R.cp || runMode !== 'checkpoint' ? 0x35d0ff : 0x6c7a8a);
function paintCps() { CPS.forEach((c, i) => { const h = stageCol(i); c.bm.color.setHex(h); c.rm.color.setHex(h); }); }
function respawn() {
  const sp = R.cp > 0 ? CPS[R.cp - 1] : W.START;
  resetPlayer(sp.x, sp.y + 0.02, sp.z);
  P.killY = sp.y - W.killDrop; P.fallT = 0; P.eye = 1.62;
  px0 = rX = P.x; py0 = rY = P.y; pz0 = rZ = P.z; acc = 0; surfRoll = 0; R.lx = P.x; R.lz = P.z;
  $('bCrouch').classList.remove('on'); $('fade').classList.remove('on');
}
function resetGame() {
  Object.assign(R, { time: 0, falls: 0, cp: 0, started: false, maxSpeed: 0, bhops: 0, bestStreak: 0, jumps: 0, dist: 0, travel: 0, penalty: 0, cd: 0, cdN: 0, stageT: 0, stageTimes: [], stageFalls: [], stageFallsCur: 0, splits: [], splitMsg: '', splitT: 0, surfRun: 0, surfGap: 0, surfPend: 0, finTouch: 0 });
  R.pb = runMode === 'speedrun' && curMap ? LS.get('pk3d_splits_' + curMap.id, null) : null;
  if (!Array.isArray(R.pb)) R.pb = null;
  IN.run = false; $('bRun').classList.remove('on');
  paintCps(); respawn(); applyHudVis();
  if (runMode === 'timeattack') { R.cd = 3.6; R.cdN = 4; }
  Object.keys(tcache).forEach(k => delete tcache[k]); updateHud();
}
function doFall() {
  if (P.fallT > 0) return;
  if (runMode === 'endless') { endRun(false); return; }
  P.fallT = 0.3; R.falls++; pend.falls++; R.surfPend = 0; R.surfRun = 0; AU.fall(); buzz(70);
  if (runMode === 'timeattack') R.penalty += 5;
  if (runMode === 'checkpoint') R.stageFallsCur++;
  if (runMode === 'speedrun') { // падение = сброс забега
    R.time = 0; R.started = false; R.cp = 0; R.splits = []; R.splitT = 0; paintCps(); P.fallT = 0.3; R.stageT = 0;
    toast('СБРОС — забег начинается заново', 1400);
  }
  const f = $('fade'); f.classList.remove('dark'); f.classList.add('on');
}
function routeLen() { return W.START.z - W.FINISH.z; }
function finishRun() {
  if (state !== 'play') return;
  const t = total(), id = curMap.id; let rec = false, big = '', bigL = 'ВРЕМЯ', pbTxt = '--', title = 'ФИНИШ!';
  const list = [], stats = [];
  const finishable = runMode !== 'freeroam';
  if (finishable) pend.finishes++;
  if (runMode === 'bhop') {
    const sc = score(); rec = setRec('bhop', id, sc, false); big = String(sc); bigL = 'ОЧКИ'; pbTxt = Math.round(getRec('bhop', id)) + ' очк.'; title = 'BHOP CHALLENGE';
    stats.push(['BHOP', R.bhops], ['ЛУЧШАЯ СЕРИЯ', R.bestStreak], ['МАКС. СКОРОСТЬ', Math.round(R.maxSpeed * 3.6) + ' <small>км/ч</small>'], ['ПАДЕНИЯ', R.falls], ['ВРЕМЯ', fmt(R.time)], ['РЕКОРД', pbTxt]);
  } else {
    rec = setRec(runMode, id, t, true); big = fmt(t); pbTxt = fmt(getRec(runMode, id));
    if (runMode === 'speedrun' && rec) LS.set('pk3d_splits_' + id, R.splits);
    stats.push(['МАКС. СКОРОСТЬ', Math.round(R.maxSpeed * 3.6) + ' <small>км/ч</small>'], ['ПАДЕНИЯ', R.falls], ['УСПЕШНЫЕ BHOP', R.bhops], ['ЛИЧНЫЙ РЕКОРД', pbTxt]);
    if (runMode === 'timeattack') list.push(['Чистое время', fmt(R.time)], ['Штраф за падения', '+' + R.penalty + ' с']);
    if (runMode === 'checkpoint') { title = 'ВСЕ ЭТАПЫ ПРОЙДЕНЫ'; R.stageTimes.forEach((st, i) => list.push(['Этап ' + (i + 1), fmt(st) + ' · падений ' + R.stageFalls[i]])); list.push(['Финальный этап', fmt(R.stageT) + ' · падений ' + R.stageFallsCur]); }
    if (runMode === 'speedrun') { title = 'SPEEDRUN ЗАВЕРШЁН'; list.push(['Попыток (сбросов)', R.falls]); }
  }
  if (R.falls === 0) grant('perfect_run');
  if (runMode === 'checkpoint') grant('stages');
  if ((runMode === 'speedrun' || runMode === 'timeattack') && t < routeLen() / 7) grant('speedrunner');
  flush();
  if (finishable && MAPS.filter(m => m.build && !m.procedural).every(m => (STATS.maps[m.id] || {}).finishes > 0)) grant('all_maps');
  showResult({ title, big, bigL, rec, stats, list });
}
function endRun() { // ENDLESS: попытка окончена падением
  if (state !== 'play') return;
  const d = Math.round(R.dist), rec = setRec('endless', 'endless', d, false);
  if (d >= 500) grant('endless_500');
  AU.fall(); buzz(70); flush();
  showResult({
    title: 'ПОПЫТКА ЗАВЕРШЕНА', big: d + ' м', bigL: 'ДИСТАНЦИЯ', rec,
    stats: [['МАКС. СКОРОСТЬ', Math.round(R.maxSpeed * 3.6) + ' <small>км/ч</small>'], ['УРОВЕНЬ', 1 + Math.floor(R.dist / 150)], ['УСПЕШНЫЕ BHOP', R.bhops], ['РЕКОРД', Math.round(getRec('endless', 'endless') || d) + ' м']], list: []
  });
}
function showResult(o) {
  state = 'result'; resetTouch(); if (o.title !== 'ПОПЫТКА ЗАВЕРШЕНА') { AU.finish(); buzz([40, 40, 90]); }
  setLayers(false, true);
  $('rTitle').textContent = o.title; $('rMap').textContent = mode().name + ' · ' + curMap.name; $('rBigL').textContent = o.bigL; $('rTime').textContent = o.big;
  $('rBadge').classList.toggle('show', !!o.rec);
  $('rStats').innerHTML = o.stats.map(s => '<div>' + s[0] + '<b>' + s[1] + '</b></div>').join('');
  $('rList').innerHTML = o.list.map(s => '<div><span>' + s[0] + '</span><b>' + s[1] + '</b></div>').join('');
  const nx = nextMap(); $('rNext').style.display = nx ? '' : 'none';
  setTimeout(() => { if (state === 'result') showScreen('result'); }, 500);
}
function nextMap() {
  if (runMode === 'endless' || runMode === 'freeroam') return null;
  const i = MAPS.findIndex(m => m.id === curMap.id);
  for (let j = i + 1; j < MAPS.length; j++) if (supports(runMode, MAPS[j]).ok) return MAPS[j];
  return null;
}

function updateGame(dt) {
  if (P.fallT > 0) { P.fallT -= dt; if (P.fallT <= 0) respawn(); updateCamera(dt); return; }
  // сглаживание ввода
  const kx = (keys.KeyD || keys.ArrowRight ? 1 : 0) - (keys.KeyA || keys.ArrowLeft ? 1 : 0), ky = (keys.KeyW || keys.ArrowUp ? 1 : 0) - (keys.KeyS || keys.ArrowDown ? 1 : 0);
  // обратный отсчёт TIME ATTACK: игрок стоит, камера свободна
  if (R.cd > 0) {
    R.cd -= dt; const n = Math.ceil(R.cd - 0.6);
    if (n !== R.cdN) { R.cdN = n; if (n >= 1) { showCountdown(String(n)); AU.beep(false); } else { showCountdown('GO!'); AU.beep(true); } }
    if (R.cd <= 0.6 || n <= 0) { if (R.cd <= 0.6) { R.cd = 0; R.started = true; } }
    IN.x = IN.y = 0; IN.jumpBuf = 0; P.hs = 0;
    updateCamera(dt); updateShadow(rX, rY, rZ); updateHud(); return;
  }
  const tx = joy.x + kx, ty = joy.y + ky;
  const k = 1 - Math.exp(-dt * 22); IN.x += (tx - IN.x) * k; IN.y += (ty - IN.y) * k;
  if (Math.abs(IN.x) < 0.004) IN.x = 0; if (Math.abs(IN.y) < 0.004) IN.y = 0;
  IN.autoHop = S.autoHop;
  if (!R.started && (Math.hypot(tx, ty) > 0.15 || IN.jumpBuf > 0 || IN.jumpHeld)) R.started = true;
  if (R.started) { R.time += dt; R.stageT += dt; pend.playTime += dt; }

  gather();
  acc += dt; let n = 0;
  while (acc >= K.STEP && n < 16) { px0 = P.x; py0 = P.y; pz0 = P.z; stepPhysics(K.STEP); acc -= K.STEP; n++; }
  if (n >= 16) acc = 0;
  const a = acc / K.STEP; rX = px0 + (P.x - px0) * a; rY = py0 + (P.y - py0) * a; rZ = pz0 + (P.z - pz0) * a;

  P.hs = Math.hypot(P.vx, P.vz);
  const moving = P.onGround && P.hs > 0.8 && P.slide <= 0;
  if (moving) P.bobPh += P.hs * dt * (P.crouch ? 1.9 : 1.55);
  const amp = moving && S.bob ? 0.042 * Math.min(1, P.hs / 6) : 0;
  P.bobAmp += (amp - P.bobAmp) * Math.min(1, dt * 9);
  P.bobY = Math.sin(P.bobPh * 2) * P.bobAmp; P.bobR = Math.sin(P.bobPh) * P.bobAmp * 0.14;
  const si = Math.floor(P.bobPh / Math.PI); if (si !== P.stepIdx) { P.stepIdx = si; if (moving) AU.step(); }
  P.landV += (-120 * P.landY - 14 * P.landV) * dt; P.landY += P.landV * dt;
  P.kickV += (-110 * P.kick - 11 * P.kickV) * dt; P.kick += P.kickV * dt;
  const et = P.crouch ? 0.95 : 1.62; P.eye += (et - P.eye) * Math.min(1, dt * 12);

  // статистика попытки
  const step = Math.hypot(P.x - R.lx, P.z - R.lz); R.lx = P.x; R.lz = P.z;
  if (step < 3 && R.started) { R.travel += step; pend.distance += step; }
  if (P.hs > R.maxSpeed) { R.maxSpeed = P.hs; if (P.hs > pend.maxSpeed) pend.maxSpeed = P.hs; }
  if (P.hs * 3.6 >= 70) grant('speed_demon');
  const dProg = W.START.z - P.z; if (dProg > R.dist) R.dist = dProg;
  if (STATS.total.distance + pend.distance >= 5000) grant('marathon');
  R.flush += dt; if (R.flush > 8) { R.flush = 0; flush(); }

  // серф: 3 с на рампах и продолжение пути без падения
  if (P.surfT > 0 && !P.onGround) { R.surfRun += dt; R.surfGap = 0; if (R.surfRun >= 3 && R.surfPend === 0) R.surfPend = 2; }
  else { R.surfGap += dt; if (R.surfGap > 0.6) R.surfRun = 0; }
  if (R.surfPend > 0) { R.surfPend -= dt; if (R.surfPend <= 0) { R.surfPend = -1; grant('surf_master'); } }
  if (R.splitT > 0) R.splitT -= dt;

  // контрольные точки (по режиму)
  const prog = clamp(dProg / routeLen(), 0, 1);
  for (let i = R.cp; i < CPS.length; i++) {
    if (runMode === 'checkpoint' && i !== R.cp) break; // активна только следующая
    const c = CPS[i], dx = P.x - c.x, dz = P.z - c.z;
    if (dx * dx + dz * dz < 9 && Math.abs(P.y - c.y) < 2.6) {
      R.cp = i + 1; paintCps(); AU.checkpoint(); buzz(30);
      if (runMode === 'checkpoint') { R.stageTimes.push(R.stageT); R.stageFalls.push(R.stageFallsCur); toast('Этап ' + R.cp + ' пройден · ' + fmt(R.stageT) + (R.stageFallsCur ? ' · падений ' + R.stageFallsCur : ''), 2200); R.stageT = 0; R.stageFallsCur = 0; }
      else if (runMode === 'speedrun') {
        R.splits[i] = R.time; const pb = R.pb && R.pb[i];
        if (typeof pb === 'number') { const d = R.time - pb; R.splitMsg = 'СПЛИТ ' + R.cp + ': ' + (d <= 0 ? '−' : '+') + Math.abs(d).toFixed(2) + ' с'; } else R.splitMsg = 'СПЛИТ ' + R.cp + ': ' + fmt(R.time);
        R.splitT = 4;
      } else if (runMode !== 'endless') toast('Чекпоинт ' + R.cp + ' / ' + CPS.length, 1600);
      break;
    }
  }
  if (runMode === 'freeroam' && prog >= 0.95) grant('explorer');
  // финиш
  if (P.onGround && W.FINISH && P.ground === W.FINISH.col) {
    if (runMode === 'freeroam') { R.finTouch -= dt; if (R.finTouch <= 0) { R.finTouch = 5; toast('Финиш — в FREE ROAM забег не завершается', 2200); } }
    else if (runMode === 'checkpoint' && R.cp < CPS.length) { R.finTouch -= dt; if (R.finTouch <= 0) { R.finTouch = 4; toast('Сначала пройдите все этапы (' + R.cp + ' / ' + CPS.length + ')', 2200); } }
    else { finishRun(); return; }
  }
  if (P.y < P.killY) doFall();

  AU.wind(P.hs + Math.abs(Math.min(0, P.vy)) * 0.5, !P.onGround);
  updateShadow(rX, rY, rZ);
  updateCamera(dt);
  knife.update(dt, { hs: P.hs, onGround: P.onGround, vy: P.vy, bobPh: P.bobPh, crouch: P.crouch, slide: P.slide > 0, surf: P.surfT > 0 && !P.onGround, bob: S.bob, dyaw: P.yaw - prevYaw, dpitch: P.pitch - prevPitch });
  prevYaw = P.yaw; prevPitch = P.pitch;
  updateHud();
}
const ease = t => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
function updateCamera(dt) {
  let sr = 0;
  if (P.surfT > 0 && !P.onGround) { const nR = P.surfNx * Math.cos(P.yaw) - P.surfNz * Math.sin(P.yaw); sr = clamp(-nR * 0.22, -0.2, 0.2); }
  surfRoll += (sr - surfRoll) * Math.min(1, dt * 7);
  const targetRoll = (S.tilt ? -IN.x * 0.035 * Math.min(1, P.hs / 6) + surfRoll : 0) + (S.bob ? P.bobR : 0);
  P.roll += (targetRoll - P.roll) * Math.min(1, dt * 8);
  const fxOn = S.speedFx && qualityParams().fx > 0;
  const fxv = fxOn ? clamp((P.hs - 5) * 0.85, 0, 14) + (P.vy < -14 ? Math.min(6, (-P.vy - 14) * 0.3) : 0) : 0;
  P.fovX += (fxv - P.fovX) * Math.min(1, dt * 4);
  const f = baseFov + P.fovX; if (Math.abs(camera.fov - f) > 0.03) { camera.fov = f; camera.updateProjectionMatrix(); }
  const ey = rY + P.eye + (S.bob ? P.bobY + P.landY : 0), pit = P.pitch + (S.bob ? P.kick : 0);
  if (blend < 1) {
    blend = Math.min(1, blend + dt / 1.1); const e = ease(blend);
    te.set(pit, P.yaw, P.roll, 'YXZ'); tq.setFromEuler(te); tv.set(rX, ey, rZ);
    camera.position.lerpVectors(blendPos, tv, e); camera.quaternion.slerpQuaternions(blendQuat, tq, e);
  } else { camera.position.set(rX, ey, rZ); camera.rotation.set(pit, P.yaw, P.roll); }
}
function menuCamera() {
  const n = routePts.length; if (n < 2) return;
  const s = (0.5 - 0.5 * Math.cos(menuT * 0.03)) * (n - 1), i = Math.min(n - 2, Math.floor(s)), f = s - i, a = menuT * 0.11 + 0.6;
  tv.lerpVectors(routePts[i], routePts[i + 1], f);
  camera.position.set(tv.x + Math.cos(a) * 20, tv.y + 11 + Math.sin(menuT * 0.27) * 1.5, tv.z + Math.sin(a) * 20);
  camera.lookAt(tv.x, tv.y + 1, tv.z - 3);
  if (Math.abs(camera.fov - 62) > 0.05) { camera.fov = 62; camera.updateProjectionMatrix(); }
  updateShadow(tv.x, tv.y, tv.z);
}

/* ---------- сенсорный ввод (Pointer Events, мультитач) ---------- */
const touchEl = $('touch'), hudEl = $('hud');
const joyZone = $('joyZone'), joyBase = $('joyBase'), joyStick = $('joyStick'), lookZone = $('lookZone'), probe = $('safe');
function getInsets() {
  const cs = getComputedStyle(probe);
  return { l: parseFloat(cs.paddingLeft) || 0, r: parseFloat(cs.paddingRight) || 0, t: parseFloat(cs.paddingTop) || 0, b: parseFloat(cs.paddingBottom) || 0 };
}
// раскладка кнопок/джойстика/зоны камеры берётся из controls.js (пресеты или пользовательская)
function layoutJoy() {
  const w = innerWidth, h = innerHeight, res = applyLayout(w, h, getInsets());
  joy.size = res.joy.size; joy.R = joy.size * 0.42;
  joyBase.style.width = joyBase.style.height = joy.size + 'px';
  const st = joy.size * 0.44; joyStick.style.width = joyStick.style.height = st + 'px'; joyStick.style.marginLeft = joyStick.style.marginTop = (-st / 2) + 'px';
  joy.defX = res.joy.cx - joy.size / 2; joy.defY = res.joy.cy - joy.size / 2;
  joyZone.style.top = Math.max(0, Math.min(h * 0.28, res.joy.cy - joy.size * 0.9)) + 'px';
  if (joy.id === null) setJoyPos(joy.defX, joy.defY);
}
const setJoyPos = (x, y) => { joyBase.style.transform = 'translate3d(' + x + 'px,' + y + 'px,0)'; };
function moveJoy(e) {
  let dx = e.clientX - joy.cx, dy = e.clientY - joy.cy; const len = Math.hypot(dx, dy);
  if (len > joy.R) { dx *= joy.R / len; dy *= joy.R / len; }
  joyStick.style.transform = 'translate3d(' + dx + 'px,' + dy + 'px,0)';
  const mag = Math.min(1, len / joy.R), m2 = mag < 0.08 ? 0 : (mag - 0.08) / 0.92, dl = Math.hypot(dx, dy);
  if (dl > 0) { joy.x = dx / dl * m2; joy.y = -dy / dl * m2; } else { joy.x = joy.y = 0; }
}
function releaseJoy() {
  joy.id = null; joy.x = joy.y = 0; joyBase.classList.remove('active');
  joyStick.style.transform = 'translate3d(0,0,0)'; setJoyPos(joy.defX, joy.defY);
}
joyZone.addEventListener('pointerdown', e => {
  if (joy.id !== null || state !== 'play') return; e.preventDefault(); joy.id = e.pointerId;
  try { joyZone.setPointerCapture(e.pointerId); } catch (_) { /* ignore */ }
  const half = joy.size / 2, zr = joyZone.clientWidth || innerWidth * 0.55;
  joy.cx = clamp(e.clientX, half + 8, Math.max(half + 8, zr - half)); joy.cy = clamp(e.clientY, half + 8, innerHeight - half - 8);
  setJoyPos(joy.cx - half, joy.cy - half); joyBase.classList.add('active'); moveJoy(e);
});
joyZone.addEventListener('pointermove', e => { if (e.pointerId === joy.id) { e.preventDefault(); moveJoy(e); } });
['pointerup', 'pointercancel', 'lostpointercapture'].forEach(ev => joyZone.addEventListener(ev, e => { if (e.pointerId === joy.id) releaseJoy(); }));

const LOOK_K = 0.0042;
lookZone.addEventListener('pointerdown', e => {
  if (look.id !== null || state !== 'play') return; e.preventDefault(); look.id = e.pointerId; look.x = e.clientX; look.y = e.clientY;
  try { lookZone.setPointerCapture(e.pointerId); } catch (_) { /* ignore */ }
  if (e.pointerType === 'mouse' && lookZone.requestPointerLock) { try { lookZone.requestPointerLock(); } catch (_) { /* ignore */ } }
});
lookZone.addEventListener('pointermove', e => {
  if (e.pointerId !== look.id || state !== 'play' || document.pointerLockElement) return; e.preventDefault();
  const dx = e.clientX - look.x, dy = e.clientY - look.y; look.x = e.clientX; look.y = e.clientY;
  P.yaw -= dx * LOOK_K * S.sens; P.pitch = clamp(P.pitch - dy * LOOK_K * S.sens * 0.9, -1.5, 1.5);
});
['pointerup', 'pointercancel', 'lostpointercapture'].forEach(ev => lookZone.addEventListener(ev, e => { if (e.pointerId === look.id) look.id = null; }));
document.addEventListener('mousemove', e => {
  if (document.pointerLockElement !== lookZone || state !== 'play') return;
  P.yaw -= e.movementX * LOOK_K * S.sens * 0.6; P.pitch = clamp(P.pitch - e.movementY * LOOK_K * S.sens * 0.6 * 0.9, -1.5, 1.5);
});
document.addEventListener('pointerlockchange', () => { if (!document.pointerLockElement && state === 'play') pauseGame(); });

function bindBtn(el, down, up) {
  el.addEventListener('pointerdown', e => { e.preventDefault(); try { el.setPointerCapture(e.pointerId); } catch (_) { /* ignore */ } el.classList.add('press'); if (down) down(); });
  const end = () => { el.classList.remove('press'); if (up) up(); };
  el.addEventListener('pointerup', end); el.addEventListener('pointercancel', end);
}
function doSlash() { if (state === 'play' && S.knife && knife.swing()) AU.swing(); }
function doInspect() { if (state === 'play' && S.knife && knife.inspect()) AU.inspect(); }
const pressJump = () => { if (state === 'play') { IN.jumpBuf = 0.13; IN.jumpHeld = true; } };
bindBtn($('bJump'), pressJump, () => { IN.jumpHeld = false; });
bindBtn($('bRun'), () => { if (state !== 'play') return; IN.run = !IN.run; $('bRun').classList.toggle('on', IN.run); });
bindBtn($('bCrouch'), () => { if (state !== 'play') return; IN.crouchWant = !IN.crouchWant; $('bCrouch').classList.toggle('on', IN.crouchWant); });
bindBtn($('bSlash'), doSlash);
bindBtn($('bLook'), doInspect);
function resetTouch() {
  releaseJoy(); look.id = null; IN.jumpBuf = 0; IN.jumpHeld = false; IN.x = IN.y = 0;
  ['bJump', 'bRun', 'bCrouch', 'bSlash', 'bLook'].forEach(i => $(i).classList.remove('press'));
}

// клавиатура (ПК)
window.addEventListener('keydown', e => {
  keys[e.code] = true;
  if (e.code === 'Space') { e.preventDefault(); pressJump(); }
  if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') IN.keyRun = true;
  if ((e.code === 'KeyC' || e.code === 'ControlLeft') && state === 'play' && !e.repeat) { IN.crouchWant = !IN.crouchWant; $('bCrouch').classList.toggle('on', IN.crouchWant); }
  if (e.code === 'KeyE' && !e.repeat) doSlash();
  if (e.code === 'KeyF' && !e.repeat) doInspect();
  if (e.code === 'KeyR' && !e.repeat && (state === 'play' || state === 'pause' || state === 'result')) restartGame(true);
  if ((e.code === 'Escape' || e.code === 'KeyP') && !e.repeat) { if (state === 'play') pauseGame(); else if (state === 'pause') resumeGame(); }
});
window.addEventListener('keyup', e => {
  keys[e.code] = false;
  if (e.code === 'Space') IN.jumpHeld = false;
  if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') IN.keyRun = false;
});
document.addEventListener('touchmove', e => { if (!e.target.closest || !e.target.closest('.panel')) e.preventDefault(); }, { passive: false });
['gesturestart', 'gesturechange', 'gestureend', 'contextmenu', 'selectstart', 'dragstart'].forEach(ev => document.addEventListener(ev, e => e.preventDefault()));

/* ---------- экраны / меню ---------- */
const screens = {}; ['Main', 'Modes', 'Maps', 'Settings', 'Controls', 'Stats', 'Ach', 'About', 'Pause', 'Result'].forEach(n => { screens[n.toLowerCase()] = $('s' + n); });
let backTo = 'main', ctlFrom = 'main';
function showScreen(n) {
  Object.keys(screens).forEach(k => screens[k].classList.toggle('active', k === n));
  if (n === 'modes') UI.refreshModes(); if (n === 'maps') UI.refreshMaps(); if (n === 'stats') UI.renderStats(); if (n === 'ach') UI.renderAch();
  if (n === 'settings') UI.renderSettings(settingsCb); if (n === 'main') refreshMenu(); if (n === 'pause') $('pInfo').textContent = mode().name + ' · ' + curMap.name;
  if (n && n !== 'result') AU.click();
}
function setLayers(touchOn, hudOn) { touchEl.classList.toggle('hidden', !touchOn); hudEl.classList.toggle('hidden', !hudOn); }
function refreshMenu() {
  UI.normalizeSel(); const m = MODE_BY_ID[SEL.mode], mp = UI.mapById(SEL.map);
  $('mPlaySub').textContent = m.name + ' · ' + mp.name; $('mAchN').textContent = achCount() + '/' + ACH_LIST.length;
}
function goFullscreen() {
  const el = document.documentElement, rq = el.requestFullscreen || el.webkitRequestFullscreen;
  if (!rq) { toast('iPhone: «Поделиться» → «На экран Домой» для полного экрана', 3800); return false; }
  try { const p = rq.call(el); if (p && p.then) p.then(() => { try { screen.orientation.lock('landscape').catch(() => {}); } catch (e) { /* ignore */ } }).catch(() => {}); } catch (e) { /* ignore */ }
  return true;
}
function exitFullscreen() { const ex = document.exitFullscreen || document.webkitExitFullscreen; try { if (ex) ex.call(document); } catch (e) { /* ignore */ } }
const isFs = () => !!(document.fullscreenElement || document.webkitFullscreenElement);
function toggleFs() { if (isFs()) { exitFullscreen(); S.fs = false; } else { S.fs = goFullscreen(); } UI.syncFsSwitch(); saveSettings(); }

function beginPlay() {
  blendPos.copy(camera.position); blendQuat.copy(camera.quaternion); blend = 0;
  state = 'play'; resetGame(); pend.attempts++; prevYaw = P.yaw; prevPitch = P.pitch; showScreen(null); setLayers(true, true);
  if (innerHeight > innerWidth) toast('Лучше играть в горизонтальном режиме', 2600);
}
const needsReload = id => W.id !== id || (UI.mapById(id) || {}).procedural || W.decor !== qualityParams().decor;
function startRun(modeId, mapId) {
  if (state === 'loading') return;
  const mp = UI.mapById(mapId), sp = supports(modeId, mp);
  if (!sp.ok) { toast('✕ ' + sp.why, 3200); return; }
  runMode = modeId; SEL.mode = modeId; SEL.map = mapId; UI.persistSel();
  AU.init(); AU.apply(); if (S.fs && !isFs()) goFullscreen();
  if (!needsReload(mapId)) { beginPlay(); return; }
  state = 'loading'; const f = $('fade'); f.classList.add('dark', 'on');
  setTimeout(() => {
    try { loadAndPrepare(mapId); } catch (err) { console.error(err); runMode = 'classic'; SEL.mode = 'classic'; SEL.map = 'city'; loadAndPrepare('city'); toast('Не удалось загрузить карту — открыта CITY ROOFTOPS', 3000); }
    menuCamera(); beginPlay();
    f.classList.remove('on'); setTimeout(() => f.classList.remove('dark'), 260);
  }, 320);
}
function pauseGame() {
  if (state !== 'play') return; flush(); state = 'pause'; resetTouch(); setLayers(false, true); showScreen('pause');
  if (document.pointerLockElement) { try { document.exitPointerLock(); } catch (e) { /* ignore */ } }
}
function resumeGame() { state = 'play'; showScreen(null); setLayers(true, true); }
function toScreen(name) {
  if (state === 'loading') return;
  flush();
  const f = $('fade'); f.classList.add('dark', 'on'); resetTouch();
  if (document.pointerLockElement) { try { document.exitPointerLock(); } catch (e) { /* ignore */ } }
  state = 'loading';
  setTimeout(() => {
    state = 'menu'; blend = 1; setLayers(false, false); showScreen(name);
    f.classList.remove('on'); setTimeout(() => f.classList.remove('dark'), 260);
  }, 260);
}
// quick=true: мгновенный перезапуск без затемнения (кроме ENDLESS: новая трасса требует перестройки мира)
function restartGame(quick) {
  if (state === 'loading' || state === 'menu' || state === 'edit') return;
  flush();
  const rebuild = runMode === 'endless' || W.decor !== qualityParams().decor;
  const go = () => { resetTouch(); if (rebuild) { try { loadAndPrepare(curMap.id); } catch (err) { console.error(err); } } else resetGame(); pend.attempts++; prevYaw = P.yaw; prevPitch = P.pitch; state = 'play'; showScreen(null); setLayers(true, true); };
  if (quick && !rebuild) { go(); const f = $('fade'); f.classList.remove('dark'); f.classList.add('on'); setTimeout(() => f.classList.remove('on'), 90); return; }
  const f = $('fade'); f.classList.add('dark', 'on'); state = 'loading';
  setTimeout(() => { go(); f.classList.remove('on'); setTimeout(() => f.classList.remove('dark'), 260); }, 240);
}
const playSel = () => startRun(SEL.mode, SEL.map);
function openEditorFrom(from) {
  ctlFrom = from; const was = state; state = 'edit'; showScreen(null); setLayers(true, false); resetTouch();
  openEditor({
    getInsets, relayout: layoutJoy,
    onClose: () => { state = was; setLayers(false, was === 'pause'); showScreen('controls'); }
  });
  layoutJoy();
}

$('mPlay').onclick = playSel;
$('mModes').onclick = () => showScreen('modes');
$('mMaps').onclick = () => showScreen('maps');
$('mSettings').onclick = () => { backTo = 'main'; showScreen('settings'); };
$('mControls').onclick = () => { ctlFrom = 'main'; showScreen('controls'); };
$('mStats').onclick = () => showScreen('stats');
$('mAch').onclick = () => showScreen('ach');
$('mAbout').onclick = () => showScreen('about');
$('modeBack').onclick = () => showScreen('main');
$('modeMaps').onclick = () => showScreen('maps');
$('modeStart').onclick = playSel;
$('mapBack').onclick = () => showScreen('main');
$('mapStart').onclick = playSel;
$('setBack').onclick = () => showScreen(backTo);
$('ctlBack').onclick = () => showScreen(ctlFrom);
$('ctlEdit').onclick = () => openEditorFrom(ctlFrom);
$('stBack').onclick = () => showScreen('main');
$('achBack').onclick = () => showScreen('main');
$('abBack').onclick = () => showScreen('main');
$('pResume').onclick = resumeGame;
$('pRestart').onclick = () => restartGame(false);
$('pMaps').onclick = () => toScreen('modes');
$('pSettings').onclick = () => { backTo = 'pause'; showScreen('settings'); };
$('pControls').onclick = () => { ctlFrom = 'pause'; showScreen('controls'); };
$('pMenu').onclick = () => toScreen('main');
$('rAgain').onclick = () => restartGame(false);
$('rNext').onclick = () => { const nx = nextMap(); if (nx) { SEL.map = nx.id; showScreen(null); startRun(runMode, nx.id); } };
$('rMaps').onclick = () => toScreen('modes');
$('rMenu').onclick = () => toScreen('main');
$('btnPause').addEventListener('pointerdown', e => { e.preventDefault(); pauseGame(); });
$('btnRestart').addEventListener('pointerdown', e => { e.preventDefault(); restartGame(true); });
$('fsMenuBtn').onclick = toggleFs;

/* ---------- настройки ---------- */
function syncBody() { document.body.classList.toggle('noknife', !S.knife); }
const settingsCb = {
  toggleFs,
  onSetting(k) {
    if (k === 'volume' || k === 'sfx' || k === 'sound' || k === 'music') { AU.init(); AU.apply(); if (k === 'sound' && S.sound) AU.click(); }
    if (k === 'vibration' && S.vibration) buzz(25);
    if (k === 'quality') { applyQuality(); if (state === 'pause' && W.decor !== qualityParams().decor) toast('Детализация фона применится после рестарта', 2400); }
    if (k === 'knife') { knife.cancel(); syncBody(); }
    if (k === 'hud' && curMap) applyHudVis();
  }
};
['fullscreenchange', 'webkitfullscreenchange'].forEach(ev => document.addEventListener(ev, () => { S.fs = isFs(); UI.syncFsSwitch(); setTimeout(resize, 150); }));

/* ---------- качество / resize / цикл ---------- */
function applyQuality() { coreApplyQuality(resize); }
function resize() {
  const w = innerWidth, h = innerHeight; if (!w || !h) return;
  renderer.setSize(w, h, false); camera.aspect = w / h; knife.setAspect(w / h);
  const HF = 100 * Math.PI / 180; baseFov = clamp(2 * Math.atan(Math.tan(HF / 2) / camera.aspect) * 180 / Math.PI, 70, 100);
  camera.fov = baseFov; camera.updateProjectionMatrix();
  document.body.classList.toggle('portrait', h > w);
  layoutJoy();
}
window.addEventListener('resize', resize);
window.addEventListener('orientationchange', () => setTimeout(resize, 250));
if (window.visualViewport) window.visualViewport.addEventListener('resize', resize);

function envUpdate() {
  sky.position.copy(camera.position);
  sunSprite.position.set(camera.position.x + lightDir.x * 540, camera.position.y + lightDir.y * 540, camera.position.z + lightDir.z * 540);
  for (let i = 0; i < CPS.length; i++) CPS[i].ring.rotation.z += 0.02;
  if (W.FINISH) W.FINISH.ring.rotation.z -= 0.015;
}
let accT = 0, accN = 0, prCool = 4;
function adaptRes(dt) {
  accT += dt; accN++; prCool -= dt;
  if (accN >= 60) {
    const avg = accT / accN; accT = 0; accN = 0;
    if (prCool <= 0) {
      if (avg > 0.026 && QUAL.cur > 0.7) { QUAL.cur = Math.max(0.7, QUAL.cur - 0.15); renderer.setPixelRatio(QUAL.cur); prCool = 3; }
      else if (avg < 0.0185 && QUAL.cur < QUAL.target - 0.01) { QUAL.cur = Math.min(QUAL.target, QUAL.cur + 0.1); renderer.setPixelRatio(QUAL.cur); prCool = 6; }
    }
  }
}
let last = performance.now();
function frame(now) {
  requestAnimationFrame(frame);
  let dt = (now - last) / 1000; last = now; if (dt > 0.1) dt = 0.1; if (dt <= 0) return;
  if (state === 'play') updateGame(dt);
  else if (state === 'menu' || state === 'loading' || (state === 'edit' && ctlFrom === 'main')) { menuT += dt; if (state !== 'loading') menuCamera(); }
  else if (state === 'pause' || state === 'result' || state === 'edit') updateShadow(rX, rY, rZ);
  envUpdate();
  if (state === 'play' || state === 'menu') adaptRes(dt);
  renderer.render(scene, camera);
  if (S.knife && (state === 'play' || state === 'pause' || state === 'result' || (state === 'edit' && ctlFrom === 'pause'))) knife.render(renderer);
}
document.addEventListener('visibilitychange', () => {
  if (document.hidden) { pauseGame(); flush(); if (AU.ctx && AU.ctx.state === 'running') AU.ctx.suspend(); }
  else { if (AU.ctx && AU.ctx.state === 'suspended') AU.ctx.resume(); last = performance.now(); }
});
window.addEventListener('blur', () => { if (state === 'play') pauseGame(); });
['pointerdown', 'touchstart'].forEach(ev => document.addEventListener(ev, () => AU.init(), { once: true, passive: true }));

/* ---------- init ---------- */
UI.normalizeSel(); syncBody();
try { loadAndPrepare(SEL.map); } catch (err) { console.error(err); SEL.map = 'city'; SEL.mode = 'classic'; runMode = 'classic'; loadAndPrepare('city'); }
runMode = SEL.mode; applyHudVis();
UI.initModes({ toast, refreshMenu }); UI.initMaps({ toast, refreshMenu, goto: showScreen }); UI.initSettings(settingsCb); UI.initStats();
refreshMenu(); resize(); menuCamera();
renderer.render(scene, camera);
requestAnimationFrame(t => { last = t; requestAnimationFrame(frame); });
setTimeout(() => $('loading').classList.add('done'), 350);

// отладочный доступ для автотестов (не влияет на игру)
window.__pk3d = { get state() { return state; }, get runMode() { return runMode; }, R, P, IN, SEL, CPS, W, startRun, restartGame, pauseGame, resumeGame, finishRun, endRun, showScreen, joy };
