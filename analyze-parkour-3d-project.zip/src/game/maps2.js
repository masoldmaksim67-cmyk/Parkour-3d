// Дополнительные карты: BHOP TRACK (тренировочная трасса для длинных серий прыжков)
// и ENDLESS TRACK (процедурная трасса со всё возрастающей сложностью).
import { W, box, addCol, cp, buildFinish, makeGround, makeClouds, skyline, rnd, sign, ac, vent, tank } from './core.js';
import { place, beam, pads, kicker, surfCorridor, addMoverBridge, moverChain } from './kit.js';

const NEON = [0x00e5ff, 0xff2fd0, 0xffe14a, 0x7dff6a];
const PAL = [0xffffff, 0xf2e8da, 0xd9e5f2, 0xeadbd2, 0xdbe9de, 0xe8e2f0];
let pi = 0;

// Платформа-башня. o.pad — небольшая неоновая площадка бхоп-дорожки (kit.pads передаёт pad:true).
function tower(x, y, z, w, d, o) {
  o = o || {};
  const x0 = x - w / 2, x1 = x + w / 2, z0 = z - d / 2, z1 = z + d / 2;
  if (o.pad) {
    const c = NEON[pi++ % NEON.length];
    box(x0, y - .9, z0, x1, y, z1, 'metal', 'neon', c);
    const col = addCol(x0, y - 60, z0, x1, y, z1);
    return { x, y, z, w, d, col };
  }
  box(x0, W.groundY, z0, x1, y, z1, 'facade', 'roof', PAL[(rnd() * PAL.length) | 0]);
  box(x0 - .2, y - .6, z0 - .2, x1 + .2, y - .02, z1 + .2, 'concrete', 'concrete', 0xe0ded8, null, true);
  const col = addCol(x0, y - 60, z0, x1, y, z1);
  const t = .22, hh = .14, lt = 0xe9e7e0;
  box(x0, y, z0, x1, y + hh, z0 + t, 'concrete', 'concrete', lt); box(x0, y, z1 - t, x1, y + hh, z1, 'concrete', 'concrete', lt);
  box(x0, y, z0, x0 + t, y + hh, z1, 'concrete', 'concrete', lt); box(x1 - t, y, z0, x1, y + hh, z1, 'concrete', 'concrete', lt);
  if (!o.noProps && w >= 11 && rnd() < .6) { const px = x + (rnd() < .5 ? -1 : 1) * (w / 2 - 1.4); if (rnd() < .5) ac(px, y, z); else vent(px, y, z); }
  return { x, y, z, w, d, col };
}

/* ---------------------------- BHOP TRACK ---------------------------- */
export function buildBhop() {
  W.groundY = -70; W.platform = tower; pi = 0;
  tower(0, 40, 0, 16, 16, { noProps: true });
  sign(0, 46.5, 7.6, 9, 3.4, 'BHOP TRACK', '#ff2fd0'); ac(-5.5, 40, -3.5); vent(5.8, 40, -4); tank(5.4, 40, 4.5);
  W.START = { x: 0, y: 40, z: 3 }; W.cur = { x: 0, y: 40, zEdge: -8 };
  let r;
  // 1. длинный разгон + растущие зазоры
  r = place(3, 0, 9, 60, 0, { noProps: true }); cp(r, 24);
  pads(8, 3.6, 3.0, 5.4, [0], 0);
  r = place(4, 0, 12, 12); cp(r, 0);
  // 2. второй разгон и зигзаг
  r = place(3, 0, 9, 46, 0, { noProps: true });
  pads(10, 3.2, 3.4, 5.8, [2.6, -2.6], 0);
  r = place(4, 0, 12, 12); cp(r, 0);
  // 3. разгон, трамплин и серф-жёлоб
  r = place(3.5, 0, 8, 46, 0, { noProps: true }); cp(r, 18);
  kicker(7, 6, .28, 'concrete', 0x59607a);
  r = place(8.5, -1.6, 9, 12, 0, { noProps: true });
  surfCorridor({ L: 40, th: .9, p: .1, tintL: 0x00e5ff, tintR: 0xff2fd0 });
  r = place(.5, 0, 12, 12); cp(r, 0);
  // 4. длинная линия на тайминг: мелкие площадки, зазоры до 6.8 м
  r = place(3, 0, 9, 50, 0, { noProps: true });
  pads(12, 2.8, 3.4, 6.4, [0, 2.2, -2.2, 0], 0);
  r = place(4, 0, 12, 12); cp(r, 0);
  pads(14, 2.6, 3.8, 6.8, [2.4, -2.4, 0], 0);
  r = place(4.5, 0, 22, 24, 0, { noProps: true }); buildFinish(r);
  sign(r.x, r.y + 8.5, r.z - 8, 10, 3, 'FINISH', '#ffd34a');
  W.end = W.cur.zEdge;
  skyline({ side: 'nfacade', top: 'roof', tints: [0xffffff], hMax: 120, neon: NEON });
  makeGround(-70, 0x0b0d18, false);
}

/* ---------------------------- ENDLESS TRACK ---------------------------- */
// Генерация с гарантией проходимости: максимальный горизонтальный зазор ограничен физикой
// (бег 8.2 м/с, прыжок ≈0.72 с => ≈5.9 м), подъёмы укорачивают зазор, спуски его почти не меняют.
export const ENDLESS = { count: 118, restEvery: 20 };
export function buildEndless() {
  W.groundY = -70; W.platform = tower; W.killDrop = 26; pi = 0;
  tower(0, 36, 0, 16, 16, { noProps: true });
  W.START = { x: 0, y: 36, z: 3 }; W.cur = { x: 0, y: 36, zEdge: -8 };
  let r = null, y = 36, pw = 16;
  for (let i = 1; i <= ENDLESS.count; i++) {
    const d = Math.min(1, i / 95);
    if (i % ENDLESS.restEvery === 0) { r = place(3, 0, 14, 14, 0, { noProps: true }); cp(r, 0); pw = 14; continue; }
    const k = i % ENDLESS.restEvery;
    if (k === 7 && d > 0.05) { // подвижный мост
      beam(10 + d * 6, 1.5 - d * 0.35); r = place(0, 0, 8, 8); pw = 8; continue;
    }
    if (k === 13 && i > 25) { // разгон -> трамплин -> серф
      r = place(3.5, 0, 9, 34, 0, { noProps: true }); kicker(7, 6, .28, 'concrete', 0xe6dccb);
      r = place(8, -1.6, 9, 12, 0, { noProps: true });
      surfCorridor({ L: 30, th: .9, p: .1, tintL: 0x4fd8ff, tintR: 0xff8a3c });
      r = place(.5, 0, 12, 14); y = r.y; pw = 12; continue;
    }
    if (k === 16 && i > 50) { addMoverBridge(10, 4, 7); r = place(10, 0, 10, 10); pw = 10; continue; }
    const w = Math.max(3.4, 10 - d * 6.0 + rnd() * 1.5), dep = Math.max(3.4, 8 - d * 4.2 + rnd() * 2);
    let dy = rnd() < .5 ? -rnd() * 1.3 : rnd() * 0.75 * (1 - d * 0.3);
    if (y > 50) dy = -Math.abs(dy) - 0.3; else if (y < 22) dy = Math.abs(dy) + 0.2;
    let dx = (rnd() - .5) * 2 * (0.8 + d * 2.4);
    if (W.cur.x > 9) dx = -Math.abs(dx); else if (W.cur.x < -9) dx = Math.abs(dx);
    let gap = 2.2 + d * 2.9 + rnd() * 0.6;
    if (dy > 0) gap -= dy * 1.6;
    const lat = Math.max(0, Math.abs(dx) - 0.25 * (w + pw));
    while (Math.hypot(gap, lat) > 5.3 && gap > 1.8) gap -= .2;
    gap = Math.max(1.8, gap);
    r = place(gap, dy, w, dep, dx, { noProps: w < 8 }); y = r.y; pw = w;
  }
  r = place(4, 0, 22, 24, 0, { noProps: true }); buildFinish(r);
  W.end = W.cur.zEdge;
  skyline({ side: 'facade', top: 'roof', tints: PAL, hMax: 110 });
  makeGround(-70, 0x4a4650, true);
  makeClouds(18, 110, 180, .75, 1);
}
