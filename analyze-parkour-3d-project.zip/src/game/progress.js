// Список достижений. Выдаются из main.js за реальные игровые события.
import { ACHIEVED, unlockAch } from './state.js';

export const ACH_LIST = [
  { id: 'first_jump', icon: '🦘', name: 'FIRST JUMP', desc: 'Совершить первый прыжок.' },
  { id: 'first_bhop', icon: '🐇', name: 'FIRST BHOP', desc: 'Выполнить первый успешный Bunny Hop (два прыжка подряд без потери скорости).' },
  { id: 'bhop_10', icon: '🔥', name: 'BHOP CHAIN', desc: 'Серия из 10 успешных BHOP подряд.' },
  { id: 'speed_demon', icon: '💨', name: 'SPEED DEMON', desc: 'Развить скорость 70 км/ч.' },
  { id: 'slider', icon: '🛷', name: 'SLIDER', desc: 'Выполнить скольжение (SLIDE) на скорости.' },
  { id: 'surf_master', icon: '🌊', name: 'SURF MASTER', desc: 'Удержаться на рампе серфа 3 секунды и продолжить путь без падения.' },
  { id: 'perfect_run', icon: '💎', name: 'PERFECT RUN', desc: 'Пройти трассу до финиша без единого падения.' },
  { id: 'speedrunner', icon: '⚡', name: 'SPEEDRUNNER', desc: 'Пройти трассу в SPEEDRUN или TIME ATTACK быстрее эталонного времени карты.' },
  { id: 'explorer', icon: '🧭', name: 'EXPLORER', desc: 'FREE ROAM: добраться до дальнего конца карты (95% маршрута).' },
  { id: 'stages', icon: '🚩', name: 'STAGE CLEARED', desc: 'Пройти CHECKPOINT CHALLENGE целиком.' },
  { id: 'endless_500', icon: '♾', name: 'ENDLESS 500', desc: 'Пробежать 500 м в режиме ENDLESS.' },
  { id: 'jumps_100', icon: '⬆', name: '100 JUMPS', desc: 'Совершить 100 прыжков суммарно.' },
  { id: 'marathon', icon: '🏃', name: 'MARATHON', desc: 'Пробежать 5 км суммарно.' },
  { id: 'all_maps', icon: '🏆', name: 'WORLD TOUR', desc: 'Пройти до финиша все 6 карт с финишем.' }
];
export const isUnlocked = id => !!ACHIEVED[id];
export const achCount = () => ACH_LIST.filter(a => ACHIEVED[a.id]).length;
// возвращает объект достижения, если оно только что открыто
export function award(id) { return unlockAch(id) ? ACH_LIST.find(a => a.id === id) : null; }
