// Настройки и рекорды (localStorage)
export const S = {
  sens: 1, volume: 0.7, quality: 1,
  vibration: true, bob: true, tilt: true, speedFx: true,
  knife: true, autoHop: true, fs: false, map: 'city'
};
try { Object.assign(S, JSON.parse(localStorage.getItem('pk3d_settings') || '{}')); } catch (e) { /* ignore */ }
export const saveSettings = () => { try { localStorage.setItem('pk3d_settings', JSON.stringify(S)); } catch (e) { /* ignore */ } };

const bestKey = id => (id === 'city' ? 'pk3d_best' : 'pk3d_best_' + id);
export function getBest(id) {
  try { const v = parseFloat(localStorage.getItem(bestKey(id))); return isNaN(v) ? null : v; } catch (e) { return null; }
}
export function setBest(id, t) { try { localStorage.setItem(bestKey(id), String(t)); } catch (e) { /* ignore */ } }
export const fmt = t => { const m = Math.floor(t / 60), s = t - m * 60; return (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s.toFixed(2); };
