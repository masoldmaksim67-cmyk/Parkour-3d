// Главный модуль: ввод, HUD, камера, игровой цикл, меню и выбор карт.
import './boot.js';
import { S, saveSettings, getBest, setBest, fmt } from './state.js';
import { THREE, renderer, scene, camera, sky, sunSprite, lightDir, updateShadow, applyQuality as coreApplyQuality, QUAL, W, clamp } from './core.js';
import { MAPS, SOON, loadMap, drawPreview } from './maps.js';
import { CPS } from './collision.js';
import { P, IN, K, EV, gather, stepPhysics, resetPlayer } from './physics.js';
import { AU, buzz } from './audio.js';
import { createKnife } from './knife.js';

const $ = id => document.getElementById(id);
const knife = createKnife();

/* ---------- состояние игры ---------- */
let state = 'menu', runTime = 0, falls = 0, cpIdx = 0, started = false, menuT = 0, blend = 1, baseFov = 72;
let curMap = null, routePts = [], selMap = S.map;
const blendPos = new THREE.Vector3(), blendQuat = new THREE.Quaternion(), tq = new THREE.Quaternion(), tv = new THREE.Vector3(), te = new THREE.Euler(0, 0, 0, 'YXZ');
let acc = 0, px0 = 0, py0 = 0, pz0 = 0, rX = 0, rY = 0, rZ = 0;
let prevYaw = 0, prevPitch = 0, surfRoll = 0;
const keys = {};
const joy = { id: null, cx: 0, cy: 0, R: 60, size: 130, x: 0, y: 0, defX: 20, defY: 200 };
const look = { id: null, x: 0, y: 0 };

/* ---------- карта ---------- */
function loadAndPrepare(id) {
  curMap = loadMap(id); S.map = id; selMap = id; saveSettings();
  routePts = [W.START].concat(CPS, [W.FINISH]).map(p => new THREE.Vector3(p.x, p.y, p.z));
  $('hCpMax').textContent = CPS.length; $('hMap').textContent = curMap.name;
  applyQuality(); resetGame(); menuT = 0;
}

/* ---------- события физики ---------- */
EV.land = imp => {
  AU.land(imp); if (imp > 11) buzz(14);
  if (S.bob) { P.landV = -Math.min(imp * 0.2, 3.6); P.kickV = -Math.min(imp * 0.03, 0.5); }
  knife.landKick(imp);
};
EV.jump = () => { AU.jump(); if (S.bob) { P.landV += 0.9; P.kickV += 0.45; } knife.jumpKick(); };
EV.slide = () => { AU.slide(); buzz(10); };
EV.uncrouch = () => { $('bCrouch').classList.remove('on'); };

/* ---------- HUD ---------- */
const hTime = $('hTime'), hFalls = $('hFalls'), hCp = $('hCp'), hProg = $('hProg'), hSpd = $('hSpd'), hSpBar = $('hSpBar'), hTag = $('hTag'), fx = $('speedfx');
let lastT = '', lastK = -1, lastF = -1, lastC = -1, lastTag = '', lastFx = '';
function updateHud() {
  const t = fmt(runTime); if (t !== lastT) { hTime.textContent = t; lastT = t; }
  if (falls !== lastF) { hFalls.textContent = falls; lastF = falls; }
  if (cpIdx !== lastC) { hCp.textContent = cpIdx; lastC = cpIdx; }
  const k = Math.round(P.hs * 3.6); if (k !== lastK) { hSpd.textContent = k; lastK = k; }
  hSpBar.style.transform = 'scaleX(' + clamp(P.hs / 22, 0, 1).toFixed(3) + ')';
  const fin = W.FINISH, sz = W.START.z;
  hProg.style.transform = 'scaleX(' + clamp((sz - P.z) / (sz - fin.z), 0, 1).toFixed(3) + ')';
  let tag = '', cls = '';
  if (P.surfT > 0 && !P.onGround) { tag = 'SURF'; cls = 'surf'; }
  else if (P.slide > 0) { tag = 'SLIDE'; cls = 'slide'; }
  else if (P.hops >= 3 && P.hopT < 1.3) tag = 'BHOP ×' + P.hops;
  if (tag !== lastTag) { hTag.textContent = tag; hTag.className = 'hTag' + (tag ? ' on ' + cls : ''); lastTag = tag; }
  const o = S.speedFx ? clamp((P.hs - 10) / 11, 0, 0.85).toFixed(2) : '0';
  if (o !== lastFx) { fx.style.opacity = o; lastFx = o; }
}
let toastT = 0;
function toast(msg, ms) {
  const t = $('toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), ms || 2000);
}

/* ---------- игровой процесс ---------- */
function respawn() {
  const sp = cpIdx > 0 ? CPS[cpIdx - 1] : W.START;
  resetPlayer(sp.x, sp.y + 0.02, sp.z);
  P.killY = sp.y - W.killDrop; P.fallT = 0; P.eye = 1.62;
  px0 = rX = P.x; py0 = rY = P.y; pz0 = rZ = P.z; acc = 0; surfRoll = 0;
  $('bCrouch').classList.remove('on');
  $('fade').classList.remove('on');
}
function resetGame() {
  cpIdx = 0; falls = 0; runTime = 0; started = false; IN.run = false; $('bRun').classList.remove('on');
  CPS.forEach(c => { c.bm.color.setHex(0x35d0ff); c.rm.color.setHex(0x35d0ff); });
  respawn(); lastC = lastF = -1; updateHud();
}
function doFall() {
  if (P.fallT > 0) return; P.fallT = 0.3; falls++; AU.fall(); buzz(70);
  const f = $('fade'); f.classList.remove('dark'); f.classList.add('on');
}
function finishGame() {
  state = 'result'; resetTouch(); AU.finish(); buzz([40, 40, 90]); setLayers(false, true);
  let best = getBest(curMap.id);
  const rec = best === null || runTime < best;
  if (rec) { best = runTime; setBest(curMap.id, runTime); }
  $('rTime').textContent = fmt(runTime); $('rFalls').textContent = falls; $('rBest').textContent = fmt(best); $('rMap').textContent = curMap.name;
  $('rBadge').classList.toggle('show', rec);
  const idx = MAPS.findIndex(m => m.id === curMap.id); $('rNext').style.display = idx >= 0 && idx < MAPS.length - 1 ? '' : 'none';
  setTimeout(() => { if (state === 'result') showScreen('result'); }, 500);
}
function updateGame(dt) {
  if (P.fallT > 0) { P.fallT -= dt; if (P.fallT <= 0) respawn(); updateCamera(dt); return; }
  // сглаживание ввода
  const kx = (keys.KeyD || keys.ArrowRight ? 1 : 0) - (keys.KeyA || keys.ArrowLeft ? 1 : 0), ky = (keys.KeyW || keys.ArrowUp ? 1 : 0) - (keys.KeyS || keys.ArrowDown ? 1 : 0);
  const tx = joy.x + kx, ty = joy.y + ky;
  const k = 1 - Math.exp(-dt * 22); IN.x += (tx - IN.x) * k; IN.y += (ty - IN.y) * k;
  if (Math.abs(IN.x) < 0.004) IN.x = 0; if (Math.abs(IN.y) < 0.004) IN.y = 0;
  IN.autoHop = S.autoHop;
  if (!started && (Math.hypot(tx, ty) > 0.15 || IN.jumpBuf > 0 || IN.jumpHeld)) started = true;
  if (started) runTime += dt;

  gather();
  acc += dt; let n = 0;
  while (acc >= K.STEP && n < 16) { px0 = P.x; py0 = P.y; pz0 = P.z; stepPhysics(K.STEP); acc -= K.STEP; n++; }
  if (n >= 16) acc = 0;
  const a = acc / K.STEP; rX = px0 + (P.x - px0) * a; rY = py0 + (P.y - py0) * a; rZ = pz0 + (P.z - pz0) * a;

  P.hs = Math.hypot(P.vx, P.vz);
  const moving = P.onGround && P.hs > 0.8 && P.slide <= 0;
  if (moving) P.bobPh += P.hs * dt * (P.crouch ? 1.9 : 1.55);
  const amp = moving && S.bob ? 0.042 * Math.min(1, P.hs / 6) : 0;
  P.bobAmp += (amp - P.bobAmp) * Math.min(1, dt * 9);
  P.bobY = Math.sin(P.bobPh * 2) * P.bobAmp; P.bobR = Math.sin(P.bobPh) * P.bobAmp * 0.14;
  const si = Math.floor(P.bobPh / Math.PI); if (si !== P.stepIdx) { P.stepIdx = si; if (moving) AU.step(); }
  P.landV += (-120 * P.landY - 14 * P.landV) * dt; P.landY += P.landV * dt;
  P.kickV += (-110 * P.kick - 11 * P.kickV) * dt; P.kick += P.kickV * dt;
  const et = P.crouch ? 0.95 : 1.62; P.eye += (et - P.eye) * Math.min(1, dt * 12);

  for (let i = cpIdx; i < CPS.length; i++) {
    const c = CPS[i], dx = P.x - c.x, dz = P.z - c.z;
    if (dx * dx + dz * dz < 9 && Math.abs(P.y - c.y) < 2.6) {
      cpIdx = i + 1; c.bm.color.setHex(0x45ff90); c.rm.color.setHex(0x45ff90); AU.checkpoint(); buzz(30); toast('Чекпоинт ' + cpIdx + ' / ' + CPS.length, 1600);
      break;
    }
  }
  if (P.onGround && W.FINISH && P.ground === W.FINISH.col) { finishGame(); return; }
  if (P.y < P.killY) doFall();

  AU.wind(P.hs + Math.abs(Math.min(0, P.vy)) * 0.5, !P.onGround);
  updateShadow(rX, rY, rZ);
  updateCamera(dt);
  knife.update(dt, { hs: P.hs, onGround: P.onGround, vy: P.vy, bobPh: P.bobPh, crouch: P.crouch, slide: P.slide > 0, surf: P.surfT > 0 && !P.onGround, bob: S.bob, dyaw: P.yaw - prevYaw, dpitch: P.pitch - prevPitch });
  prevYaw = P.yaw; prevPitch = P.pitch;
  updateHud();
}
const ease = t => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
function updateCamera(dt) {
  let sr = 0;
  if (P.surfT > 0 && !P.onGround) { const nR = P.surfNx * Math.cos(P.yaw) - P.surfNz * Math.sin(P.yaw); sr = clamp(-nR * 0.22, -0.2, 0.2); }
  surfRoll += (sr - surfRoll) * Math.min(1, dt * 7);
  const targetRoll = (S.tilt ? -IN.x * 0.035 * Math.min(1, P.hs / 6) + surfRoll : 0) + (S.bob ? P.bobR : 0);
  P.roll += (targetRoll - P.roll) * Math.min(1, dt * 8);
  const fxv = S.speedFx ? clamp((P.hs - 5) * 0.85, 0, 14) + (P.vy < -14 ? Math.min(6, (-P.vy - 14) * 0.3) : 0) : 0;
  P.fovX += (fxv - P.fovX) * Math.min(1, dt * 4);
  const f = baseFov + P.fovX; if (Math.abs(camera.fov - f) > 0.03) { camera.fov = f; camera.updateProjectionMatrix(); }
  const ey = rY + P.eye + (S.bob ? P.bobY + P.landY : 0), pit = P.pitch + (S.bob ? P.kick : 0);
  if (blend < 1) {
    blend = Math.min(1, blend + dt / 1.1); const e = ease(blend);
    te.set(pit, P.yaw, P.roll, 'YXZ'); tq.setFromEuler(te); tv.set(rX, ey, rZ);
    camera.position.lerpVectors(blendPos, tv, e); camera.quaternion.slerpQuaternions(blendQuat, tq, e);
  } else { camera.position.set(rX, ey, rZ); camera.rotation.set(pit, P.yaw, P.roll); }
}
function menuCamera() {
  const n = routePts.length; if (n < 2) return;
  const s = (0.5 - 0.5 * Math.cos(menuT * 0.03)) * (n - 1), i = Math.min(n - 2, Math.floor(s)), f = s - i, a = menuT * 0.11 + 0.6;
  tv.lerpVectors(routePts[i], routePts[i + 1], f);
  camera.position.set(tv.x + Math.cos(a) * 20, tv.y + 11 + Math.sin(menuT * 0.27) * 1.5, tv.z + Math.sin(a) * 20);
  camera.lookAt(tv.x, tv.y + 1, tv.z - 3);
  if (Math.abs(camera.fov - 62) > 0.05) { camera.fov = 62; camera.updateProjectionMatrix(); }
  updateShadow(tv.x, tv.y, tv.z);
}

/* ---------- сенсорный ввод (Pointer Events, мультитач) ---------- */
const touchEl = $('touch'), hudEl = $('hud');
const joyZone = $('joyZone'), joyBase = $('joyBase'), joyStick = $('joyStick'), lookZone = $('lookZone'), probe = $('safe');
function layoutJoy() {
  const w = innerWidth, h = innerHeight, m = Math.min(w, h), cs = getComputedStyle(probe);
  const sl = parseFloat(cs.paddingLeft) || 0, sb = parseFloat(cs.paddingBottom) || 0;
  joy.size = clamp(m * 0.3, 110, 180); joy.R = joy.size * 0.42;
  joyBase.style.width = joyBase.style.height = joy.size + 'px';
  const st = joy.size * 0.44; joyStick.style.width = joyStick.style.height = st + 'px'; joyStick.style.marginLeft = joyStick.style.marginTop = (-st / 2) + 'px';
  joy.defX = sl + Math.max(18, m * 0.06); joy.defY = h - sb - joy.size - Math.max(18, m * 0.07);
  if (joy.id === null) setJoyPos(joy.defX, joy.defY);
}
const setJoyPos = (x, y) => { joyBase.style.transform = 'translate3d(' + x + 'px,' + y + 'px,0)'; };
function moveJoy(e) {
  let dx = e.clientX - joy.cx, dy = e.clientY - joy.cy; const len = Math.hypot(dx, dy);
  if (len > joy.R) { dx *= joy.R / len; dy *= joy.R / len; }
  joyStick.style.transform = 'translate3d(' + dx + 'px,' + dy + 'px,0)';
  const mag = Math.min(1, len / joy.R), m2 = mag < 0.08 ? 0 : (mag - 0.08) / 0.92, dl = Math.hypot(dx, dy);
  if (dl > 0) { joy.x = dx / dl * m2; joy.y = -dy / dl * m2; } else { joy.x = joy.y = 0; }
}
function releaseJoy() {
  joy.id = null; joy.x = joy.y = 0; joyBase.classList.remove('active');
  joyStick.style.transform = 'translate3d(0,0,0)'; setJoyPos(joy.defX, joy.defY);
}
joyZone.addEventListener('pointerdown', e => {
  if (joy.id !== null || state !== 'play') return; e.preventDefault(); joy.id = e.pointerId;
  try { joyZone.setPointerCapture(e.pointerId); } catch (_) { /* ignore */ }
  const half = joy.size / 2;
  joy.cx = clamp(e.clientX, half + 8, innerWidth * 0.55 - half); joy.cy = clamp(e.clientY, half + 8, innerHeight - half - 8);
  setJoyPos(joy.cx - half, joy.cy - half); joyBase.classList.add('active'); moveJoy(e);
});
joyZone.addEventListener('pointermove', e => { if (e.pointerId === joy.id) { e.preventDefault(); moveJoy(e); } });
['pointerup', 'pointercancel', 'lostpointercapture'].forEach(ev => joyZone.addEventListener(ev, e => { if (e.pointerId === joy.id) releaseJoy(); }));

const LOOK_K = 0.0042;
lookZone.addEventListener('pointerdown', e => {
  if (look.id !== null || state !== 'play') return; e.preventDefault(); look.id = e.pointerId; look.x = e.clientX; look.y = e.clientY;
  try { lookZone.setPointerCapture(e.pointerId); } catch (_) { /* ignore */ }
  if (e.pointerType === 'mouse' && lookZone.requestPointerLock) { try { lookZone.requestPointerLock(); } catch (_) { /* ignore */ } }
});
lookZone.addEventListener('pointermove', e => {
  if (e.pointerId !== look.id || state !== 'play' || document.pointerLockElement) return; e.preventDefault();
  const dx = e.clientX - look.x, dy = e.clientY - look.y; look.x = e.clientX; look.y = e.clientY;
  P.yaw -= dx * LOOK_K * S.sens; P.pitch = clamp(P.pitch - dy * LOOK_K * S.sens * 0.9, -1.5, 1.5);
});
['pointerup', 'pointercancel', 'lostpointercapture'].forEach(ev => lookZone.addEventListener(ev, e => { if (e.pointerId === look.id) look.id = null; }));
document.addEventListener('mousemove', e => {
  if (document.pointerLockElement !== lookZone || state !== 'play') return;
  P.yaw -= e.movementX * LOOK_K * S.sens * 0.6; P.pitch = clamp(P.pitch - e.movementY * LOOK_K * S.sens * 0.6 * 0.9, -1.5, 1.5);
});
document.addEventListener('pointerlockchange', () => { if (!document.pointerLockElement && state === 'play') pauseGame(); });

function bindBtn(el, down, up) {
  el.addEventListener('pointerdown', e => { e.preventDefault(); try { el.setPointerCapture(e.pointerId); } catch (_) { /* ignore */ } el.classList.add('press'); if (down) down(); });
  const end = () => { el.classList.remove('press'); if (up) up(); };
  el.addEventListener('pointerup', end); el.addEventListener('pointercancel', end);
}
function doSlash() { if (state === 'play' && S.knife && knife.swing()) AU.swing(); }
function doInspect() { if (state === 'play' && S.knife && knife.inspect()) AU.inspect(); }
const pressJump = () => { if (state === 'play') { IN.jumpBuf = 0.13; IN.jumpHeld = true; } };
bindBtn($('bJump'), pressJump, () => { IN.jumpHeld = false; });
bindBtn($('bRun'), () => { IN.run = !IN.run; $('bRun').classList.toggle('on', IN.run); });
bindBtn($('bCrouch'), () => { IN.crouchWant = !IN.crouchWant; $('bCrouch').classList.toggle('on', IN.crouchWant); });
bindBtn($('bSlash'), doSlash);
bindBtn($('bLook'), doInspect);
function resetTouch() {
  releaseJoy(); look.id = null; IN.jumpBuf = 0; IN.jumpHeld = false; IN.x = IN.y = 0;
  ['bJump', 'bRun', 'bCrouch', 'bSlash', 'bLook'].forEach(i => $(i).classList.remove('press'));
}

// клавиатура (ПК)
window.addEventListener('keydown', e => {
  keys[e.code] = true;
  if (e.code === 'Space') { e.preventDefault(); pressJump(); }
  if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') IN.keyRun = true;
  if ((e.code === 'KeyC' || e.code === 'ControlLeft') && state === 'play' && !e.repeat) { IN.crouchWant = !IN.crouchWant; $('bCrouch').classList.toggle('on', IN.crouchWant); }
  if (e.code === 'KeyE' && !e.repeat) doSlash();
  if (e.code === 'KeyF' && !e.repeat) doInspect();
  if ((e.code === 'Escape' || e.code === 'KeyP') && !e.repeat) { if (state === 'play') pauseGame(); else if (state === 'pause') resumeGame(); }
});
window.addEventListener('keyup', e => {
  keys[e.code] = false;
  if (e.code === 'Space') IN.jumpHeld = false;
  if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') IN.keyRun = false;
});
document.addEventListener('touchmove', e => { if (!e.target.closest || !e.target.closest('.panel')) e.preventDefault(); }, { passive: false });
['gesturestart', 'gesturechange', 'gestureend', 'contextmenu', 'selectstart', 'dragstart'].forEach(ev => document.addEventListener(ev, e => e.preventDefault()));

/* ---------- экраны / меню ---------- */
const screens = { main: $('sMain'), maps: $('sMaps'), settings: $('sSettings'), controls: $('sControls'), about: $('sAbout'), pause: $('sPause'), result: $('sResult') };
let backTo = 'main';
function showScreen(n) { Object.keys(screens).forEach(k => screens[k].classList.toggle('active', k === n)); }
function setLayers(touchOn, hudOn) { touchEl.classList.toggle('hidden', !touchOn); hudEl.classList.toggle('hidden', !hudOn); }
function goFullscreen() {
  const el = document.documentElement, rq = el.requestFullscreen || el.webkitRequestFullscreen;
  if (!rq) { toast('iPhone: «Поделиться» → «На экран Домой» для полного экрана', 3800); return false; }
  try { const p = rq.call(el); if (p && p.then) p.then(() => { try { screen.orientation.lock('landscape').catch(() => {}); } catch (e) { /* ignore */ } }).catch(() => {}); } catch (e) { /* ignore */ }
  return true;
}
function exitFullscreen() { const ex = document.exitFullscreen || document.webkitExitFullscreen; try { if (ex) ex.call(document); } catch (e) { /* ignore */ } }
const isFs = () => !!(document.fullscreenElement || document.webkitFullscreenElement);
function toggleFs() { if (isFs()) { exitFullscreen(); S.fs = false; } else { S.fs = goFullscreen(); } syncSettingsUI(); saveSettings(); }

function beginPlay() {
  blendPos.copy(camera.position); blendQuat.copy(camera.quaternion); blend = 0;
  resetGame(); prevYaw = P.yaw; prevPitch = P.pitch; state = 'play'; showScreen(null); setLayers(true, true);
  if (innerHeight > innerWidth) toast('Лучше играть в горизонтальном режиме', 2600);
}
function startMap(id) {
  if (state === 'loading') return;
  AU.init(); if (S.fs && !isFs()) goFullscreen();
  if (W.id === id) { beginPlay(); return; }
  state = 'loading'; const f = $('fade'); f.classList.add('dark', 'on');
  setTimeout(() => {
    try { loadAndPrepare(id); } catch (err) { console.error(err); loadAndPrepare('city'); }
    menuCamera(); beginPlay();
    f.classList.remove('on'); setTimeout(() => f.classList.remove('dark'), 260);
  }, 320);
}
function pauseGame() {
  if (state !== 'play') return; state = 'pause'; resetTouch(); setLayers(false, true); showScreen('pause');
  if (document.pointerLockElement) { try { document.exitPointerLock(); } catch (e) { /* ignore */ } }
}
function resumeGame() { state = 'play'; showScreen(null); setLayers(true, true); }
function toScreen(name) {
  if (state === 'loading') return;
  const f = $('fade'); f.classList.add('dark', 'on'); resetTouch();
  if (document.pointerLockElement) { try { document.exitPointerLock(); } catch (e) { /* ignore */ } }
  state = 'loading';
  setTimeout(() => {
    state = 'menu'; blend = 1; setLayers(false, false); if (name === 'maps') refreshCards(); showScreen(name);
    f.classList.remove('on'); setTimeout(() => f.classList.remove('dark'), 260);
  }, 260);
}
function restartGame() {
  const f = $('fade'); f.classList.add('dark', 'on');
  setTimeout(() => { resetGame(); prevYaw = P.yaw; prevPitch = P.pitch; state = 'play'; showScreen(null); setLayers(true, true); f.classList.remove('on'); setTimeout(() => f.classList.remove('dark'), 260); }, 240);
}

$('mPlay').onclick = () => { refreshCards(); showScreen('maps'); };
$('mSettings').onclick = () => { backTo = 'main'; showScreen('settings'); };
$('mControls').onclick = () => showScreen('controls');
$('mAbout').onclick = () => showScreen('about');
$('mapBack').onclick = () => showScreen('main');
$('mapStart').onclick = () => startMap(selMap);
$('setBack').onclick = () => showScreen(backTo);
$('ctlBack').onclick = () => showScreen('main');
$('abBack').onclick = () => showScreen('main');
$('pResume').onclick = resumeGame;
$('pRestart').onclick = restartGame;
$('pMaps').onclick = () => toScreen('maps');
$('pSettings').onclick = () => { backTo = 'pause'; showScreen('settings'); };
$('pMenu').onclick = () => toScreen('main');
$('rAgain').onclick = restartGame;
$('rNext').onclick = () => { const i = MAPS.findIndex(m => m.id === curMap.id); if (i >= 0 && i < MAPS.length - 1) { selMap = MAPS[i + 1].id; showScreen(null); startMap(selMap); } };
$('rMaps').onclick = () => toScreen('maps');
$('rMenu').onclick = () => toScreen('main');
$('btnPause').addEventListener('pointerdown', e => { e.preventDefault(); pauseGame(); });
$('fsMenuBtn').onclick = toggleFs;

/* ---------- выбор карт ---------- */
const mapGrid = $('mapGrid'), cardEls = {};
function stars(n) { let s = ''; for (let i = 1; i <= 3; i++) s += i <= n ? '★' : '<i>★</i>'; return s; }
const DIFF = ['', 'ЛЁГКАЯ', 'СРЕДНЯЯ', 'СЛОЖНАЯ'];
MAPS.concat(SOON).forEach(m => {
  const soon = !m.build, el = document.createElement('button');
  el.className = 'mcard' + (soon ? ' soon' : ''); el.type = 'button';
  const cv = document.createElement('canvas'); el.appendChild(cv); drawPreview(cv, m);
  const info = document.createElement('div'); info.className = 'mi';
  info.innerHTML = '<h3>' + m.name + '</h3><p>' + m.desc + '</p><div class="meta"><span class="stars" title="' + DIFF[m.diff] + '">' + stars(m.diff) + '</span>' +
    (soon ? '<span>—</span>' : '<span>РЕКОРД <b data-best="' + m.id + '">--</b></span>') + '</div>' +
    (soon ? '' : '<div class="tags">' + m.tags.map(t => '<span>' + t + '</span>').join('') + '</div>');
  el.appendChild(info);
  const rb = document.createElement('div'); rb.className = soon ? 'ribbon' : 'chk'; rb.textContent = soon ? 'СКОРО' : 'ВЫБРАНО'; el.appendChild(rb);
  if (!soon) { el.onclick = () => { selMap = m.id; refreshCards(); }; cardEls[m.id] = el; }
  mapGrid.appendChild(el);
});
function refreshCards() {
  MAPS.forEach(m => {
    cardEls[m.id].classList.toggle('sel', m.id === selMap);
    const b = getBest(m.id), n = mapGrid.querySelector('[data-best="' + m.id + '"]'); if (n) n.textContent = b === null ? '--' : fmt(b);
  });
}

/* ---------- настройки ---------- */
const setSens = $('setSens'), setVol = $('setVol');
function syncSettingsUI() {
  setSens.value = S.sens; $('valSens').textContent = (+S.sens).toFixed(1);
  setVol.value = S.volume; $('valVol').textContent = Math.round(S.volume * 100) + '%';
  document.querySelectorAll('#segQ button').forEach(b => b.classList.toggle('on', +b.dataset.q === S.quality));
  [['swFs', 'fs'], ['swVib', 'vibration'], ['swBob', 'bob'], ['swTilt', 'tilt'], ['swFx', 'speedFx'], ['swKnife', 'knife'], ['swAuto', 'autoHop']].forEach(p => $(p[0]).classList.toggle('on', !!S[p[1]]));
  document.body.classList.toggle('noknife', !S.knife);
}
setSens.oninput = () => { S.sens = +setSens.value; $('valSens').textContent = S.sens.toFixed(1); saveSettings(); };
setVol.oninput = () => { S.volume = +setVol.value; $('valVol').textContent = Math.round(S.volume * 100) + '%'; AU.setVol(S.volume); saveSettings(); };
document.querySelectorAll('#segQ button').forEach(b => { b.onclick = () => { S.quality = +b.dataset.q; applyQuality(); syncSettingsUI(); saveSettings(); }; });
$('swFs').onclick = toggleFs;
[['swVib', 'vibration'], ['swBob', 'bob'], ['swTilt', 'tilt'], ['swFx', 'speedFx'], ['swKnife', 'knife'], ['swAuto', 'autoHop']].forEach(p => {
  $(p[0]).onclick = () => { S[p[1]] = !S[p[1]]; if (p[1] === 'vibration' && S.vibration) buzz(25); if (p[1] === 'knife') knife.cancel(); syncSettingsUI(); saveSettings(); };
});
['fullscreenchange', 'webkitfullscreenchange'].forEach(ev => document.addEventListener(ev, () => { S.fs = isFs(); syncSettingsUI(); setTimeout(resize, 150); }));

/* ---------- качество / resize / цикл ---------- */
function applyQuality() { coreApplyQuality(resize); }
function resize() {
  const w = innerWidth, h = innerHeight; if (!w || !h) return;
  renderer.setSize(w, h, false); camera.aspect = w / h; knife.setAspect(w / h);
  const HF = 100 * Math.PI / 180; baseFov = clamp(2 * Math.atan(Math.tan(HF / 2) / camera.aspect) * 180 / Math.PI, 70, 100);
  camera.fov = baseFov; camera.updateProjectionMatrix();
  document.body.classList.toggle('portrait', h > w);
  layoutJoy();
}
window.addEventListener('resize', resize);
window.addEventListener('orientationchange', () => setTimeout(resize, 250));
if (window.visualViewport) window.visualViewport.addEventListener('resize', resize);

function envUpdate() {
  sky.position.copy(camera.position);
  sunSprite.position.set(camera.position.x + lightDir.x * 540, camera.position.y + lightDir.y * 540, camera.position.z + lightDir.z * 540);
  for (let i = 0; i < CPS.length; i++) CPS[i].ring.rotation.z += 0.02;
  if (W.FINISH) W.FINISH.ring.rotation.z -= 0.015;
}
let accT = 0, accN = 0, prCool = 4;
function adaptRes(dt) {
  accT += dt; accN++; prCool -= dt;
  if (accN >= 60) {
    const avg = accT / accN; accT = 0; accN = 0;
    if (prCool <= 0) {
      if (avg > 0.026 && QUAL.cur > 0.7) { QUAL.cur = Math.max(0.7, QUAL.cur - 0.15); renderer.setPixelRatio(QUAL.cur); prCool = 3; }
      else if (avg < 0.0185 && QUAL.cur < QUAL.target - 0.01) { QUAL.cur = Math.min(QUAL.target, QUAL.cur + 0.1); renderer.setPixelRatio(QUAL.cur); prCool = 6; }
    }
  }
}
let last = performance.now();
function frame(now) {
  requestAnimationFrame(frame);
  let dt = (now - last) / 1000; last = now; if (dt > 0.1) dt = 0.1; if (dt <= 0) return;
  if (state === 'play') updateGame(dt);
  else if (state === 'menu' || state === 'loading') { menuT += dt; if (state === 'menu') menuCamera(); }
  else if (state === 'pause' || state === 'result') updateShadow(rX, rY, rZ);
  envUpdate();
  if (state === 'play' || state === 'menu') adaptRes(dt);
  renderer.render(scene, camera);
  if (S.knife && (state === 'play' || state === 'pause' || state === 'result')) knife.render(renderer);
}
document.addEventListener('visibilitychange', () => {
  if (document.hidden) { pauseGame(); if (AU.ctx && AU.ctx.state === 'running') AU.ctx.suspend(); }
  else { if (AU.ctx && AU.ctx.state === 'suspended') AU.ctx.resume(); last = performance.now(); }
});
window.addEventListener('blur', () => { if (state === 'play') pauseGame(); });
['pointerdown', 'touchstart'].forEach(ev => document.addEventListener(ev, () => AU.init(), { once: true, passive: true }));

/* ---------- init ---------- */
try { if (!MAPS.some(m => m.id === S.map)) S.map = 'city'; loadAndPrepare(S.map); }
catch (err) { console.error(err); loadAndPrepare('city'); }
syncSettingsUI(); refreshCards(); resize(); menuCamera();
renderer.render(scene, camera);
requestAnimationFrame(t => { last = t; requestAnimationFrame(frame); });
setTimeout(() => $('loading').classList.add('done'), 350);
