// Набор помощников для построения маршрута: курсор W.cur движется по -Z.
import { W, box, solid, cyl, obb, addCol, mover, rnd } from './core.js';

export function place(gap, dy, w, d, dx, o) {
  dx = dx || 0; const c = W.cur;
  const zc = c.zEdge - gap - d / 2, x = c.x + dx, y = c.y + dy;
  const r = W.platform(x, y, zc, w, d, o || {});
  W.cur = { x, y, zEdge: zc - d / 2 };
  return r;
}

export function beam(len, width, o) {
  o = o || {};
  const c = W.cur, x = c.x, y = c.y, z0 = c.zEdge, z1 = z0 - len, key = o.key || 'beam';
  box(x - width / 2, y - .5, z1, x + width / 2, y, z0, key, key, o.tint); addCol(x - width / 2, y - .5, z1, x + width / 2, y, z0);
  for (let z = z0 - 3; z > z1 + 1; z -= 4) box(x - width / 2 - .12, y - .7, z - .1, x + width / 2 + .12, y - .5, z + .1, 'metal', 'metal', 0x555d65);
  c.zEdge = z1;
}
export function pipeBridge(len, r) {
  const c = W.cur, x = c.x, y = c.y, z0 = c.zEdge, z1 = z0 - len;
  cyl('metal', 0x8fa3b0, x, y - r, (z0 + z1) / 2, r, r, len, 'z', 14);
  for (let z = z0 - 2; z > z1 + 1; z -= 3.5) cyl('plain', 0x39424a, x, y - r, z, r + .06, r + .06, .14, 'z', 14);
  addCol(x - r * .85, y - 2 * r, z1, x + r * .85, y, z0);
  c.zEdge = z1;
}
export function pipeRun(r, zOff, rad, tint) {
  rad = rad || .42;
  const x0 = r.x - r.w / 2 + .4, x1 = r.x + r.w / 2 - .4, z = r.z + zOff, cy = r.y + rad;
  cyl('metal', tint || 0x7a8791, (x0 + x1) / 2, cy, z, rad, rad, x1 - x0, 'x', 12);
  for (let x = x0 + 1.5; x < x1 - .5; x += 3) cyl('plain', 0x39424a, x, cy, z, rad + .05, rad + .05, .14, 'x', 12);
  addCol(x0, r.y, z - rad * .9, x1, r.y + 2 * rad, z + rad * .9);
}
export function wallClimb(r, zOff, steps, wallKey, stepKey) {
  wallKey = wallKey || 'brick'; stepKey = stepKey || 'crate';
  const H = (steps + 1) * 1.1, zc = r.z + zOff, T = 1.6;
  solid(r.x - r.w / 2 + .05, r.y, zc - T / 2, r.x + r.w / 2 - .05, r.y + H, zc + T / 2, wallKey, 0xffffff, 'concrete');
  for (let i = 1; i <= steps; i++) { const zb = zc + T / 2 + (steps - i) * 1.6; solid(r.x - 1.6, r.y, zb, r.x + 1.6, r.y + i * 1.1, zb + 1.6, stepKey, 0xffffff); }
}
// Низкая балка: нужно присесть/проскользить (просвет 1.3 м при росте 1.8 / 1.1 в приседе)
export function lowBar(r, zOff, clear) {
  clear = clear || 1.3;
  const z = r.z + zOff, x0 = r.x - r.w / 2 + .2, x1 = r.x + r.w / 2 - .2, y0 = r.y + clear;
  solid(x0, y0, z - .3, x1, y0 + .5, z + .3, 'hazard', 0xffffff);
  solid(x0, r.y, z - .3, x0 + .4, y0, z + .3, 'metal', 0x59626b);
  solid(x1 - .4, r.y, z - .3, x1, y0, z + .3, 'metal', 0x59626b);
}

export function addMoverBridge(gap, d, period, tint) {
  const c = W.cur, z0 = c.zEdge;
  mover(c.x, c.y, z0 - .3 - d / 2, 5, d, c.x, c.y, z0 - gap + .3 + d / 2, period, 0, tint);
}
export function moverChain(n, size, gap, amp, period, tint) {
  const c = W.cur; let zEdge = c.zEdge;
  for (let i = 0; i < n; i++) {
    const zc = zEdge - gap - size / 2;
    mover(c.x - amp, c.y, zc, size, size, c.x + amp, c.y, zc, period, i % 2 ? Math.PI : 0, tint);
    zEdge = zc - size / 2;
  }
  c.zEdge = zEdge;
}
export function elevator(rise, period, tint) {
  const gap = 4.6, c = W.cur, z0 = c.zEdge, zc = z0 - gap / 2;
  mover(c.x, c.y, zc, 5, 4, c.x, c.y + rise, zc, period, 0, tint);
  return gap;
}

// Трамплин (проходимый склон) в конце текущей платформы. Курсор переходит на верхнюю кромку.
export function kicker(len, w, pitch, key, tint) {
  len = len || 7; w = w || 6; pitch = pitch || .28; key = key || 'concrete';
  const c = W.cur, cs = Math.cos(pitch), sn = Math.sin(pitch), b = .35, rise = len * sn;
  const zN = c.zEdge + len * cs;
  obb(c.x, c.y + rise / 2 - b * cs, c.zEdge + len * cs / 2 - b * sn, w / 2, b, len / 2, pitch, 0, 0, key, tint);
  const T = 2 * b / cs, seg = 5;
  for (let i = 0; i < seg; i++) {
    const t0 = i * len * cs / seg, t1 = (i + 1) * len * cs / seg, top = c.y + t0 * Math.tan(pitch) - T;
    if (top > c.y + .05) solid(c.x - w / 2, c.y, zN - t1, c.x + w / 2, top, zN - t0, 'concrete', 0xb0b4b8);
  }
  W.cur = { x: c.x, y: c.y + rise, zEdge: c.zEdge };
}

// Коридор для серфа: пол + две наклонные плиты (V-образный жёлоб), спуск вдоль маршрута.
// th — угол наклона рамп (крутые >45.6° не проходимы => скольжение), p — тангаж спуска.
export function surfCorridor(o) {
  o = Object.assign({ L: 36, th: .9, p: .1, gw: 3.4, a: 4.5, b: .5, gap: 0, tintL: 0x4fd8ff, tintR: 0xff6aa0, floorKey: 'metal', floorTint: 0x9fb0c0 }, o || {});
  const c = W.cur, S0 = { x: c.x, y: c.y, z: c.zEdge - o.gap };
  const phi = -o.p, cp = Math.cos(phi), sp = Math.sin(phi);
  const toW = (lx, ly, lz) => [S0.x + lx, S0.y + ly * cp - lz * sp, S0.z + ly * sp + lz * cp];
  const bf = .5; let q = toW(0, -bf, -o.L / 2);
  obb(q[0], q[1], q[2], o.gw / 2 + .05, bf, o.L / 2, phi, 0, 0, o.floorKey, o.floorTint);
  [1, -1].forEach(sg => {
    const cx = sg * (o.gw / 2 + o.b * Math.sin(o.th) + o.a * Math.cos(o.th)), cy = -o.b * Math.cos(o.th) + o.a * Math.sin(o.th);
    q = toW(cx, cy, -o.L / 2);
    obb(q[0], q[1], q[2], o.a, o.b, o.L / 2, phi, 0, sg * o.th, 'surf', sg > 0 ? o.tintR : o.tintL);
  });
  // опоры (визуал)
  for (let s = 6; s < o.L - 2; s += 12) {
    q = toW(0, -bf * 2, -s);
    box(q[0] - .7, W.groundY, q[2] - .7, q[0] + .7, q[1], q[2] + .7, 'metal', 'metal', 0x5b646d);
  }
  const e = toW(0, 0, -o.L);
  W.cur = { x: c.x, y: e[1], zEdge: e[2] };
  return { x: c.x, y: S0.y, z: S0.z - o.L / 2 };
}

// Серия маленьких площадок (бхоп-дорожка) с растущим зазором
export function pads(n, size, gap0, gap1, dxPat, dyStep) {
  let r = null;
  for (let i = 0; i < n; i++) {
    const g = n > 1 ? gap0 + (gap1 - gap0) * i / (n - 1) : gap0;
    r = place(g, dyStep || 0, size, size, dxPat[i % dxPat.length], { noProps: true, pad: true });
  }
  return r;
}
export { rnd };
