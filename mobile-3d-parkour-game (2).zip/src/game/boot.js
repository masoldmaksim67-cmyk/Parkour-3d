// Монтирует разметку игры (меню, HUD, канвас) в body до инициализации Three.js.
import markup from './markup.html?raw';
import './game.css';

if (!document.getElementById('app')) {
  const host = document.createElement('div');
  host.id = 'game-host';
  host.innerHTML = markup;
  document.body.appendChild(host);
}
