// Карты: геометрия, маршрут, чекпоинты, финиш и атмосфера для каждой локации.
import {
  THREE, W, box, solid, cyl, addCol, crate, ac, vent, tank, antenna, skylight, shed, billboard, sign, cp, buildFinish,
  makeGround, makeClouds, skyline, rnd, seed, resetWorld, buildBatches, applyAtmosphere, add
} from './core.js';
import { place, beam, pipeBridge, pipeRun, wallClimb, lowBar, addMoverBridge, moverChain, elevator, kicker, surfCorridor, pads } from './kit.js';
import { CPS } from './collision.js';

const pick = a => a[(rnd() * a.length) | 0];

/* ======================================================================
   1. CITY ROOFTOPS
====================================================================== */
const PAL = [0xffffff, 0xf2e8da, 0xd9e5f2, 0xeadbd2, 0xdbe9de, 0xe8e2f0];
function cityRoof(x, y, z, w, d, o) {
  o = o || {};
  const tint = PAL[(rnd() * PAL.length) | 0];
  const x0 = x - w / 2, x1 = x + w / 2, z0 = z - d / 2, z1 = z + d / 2;
  box(x0, W.groundY, z0, x1, y, z1, 'facade', 'roof', tint);
  box(x0 - .2, y - .6, z0 - .2, x1 + .2, y - .02, z1 + .2, 'concrete', 'concrete', 0xe0ded8, null, true);
  const col = addCol(x0, y - 60, z0, x1, y, z1);
  const t = .22, hh = .14, lt = 0xe9e7e0;
  box(x0, y, z0, x1, y + hh, z0 + t, 'concrete', 'concrete', lt); box(x0, y, z1 - t, x1, y + hh, z1, 'concrete', 'concrete', lt);
  box(x0, y, z0, x0 + t, y + hh, z1, 'concrete', 'concrete', lt); box(x1 - t, y, z0, x1, y + hh, z1, 'concrete', 'concrete', lt);
  if (w >= 6.5) { solid(x0, y, z0, x0 + .3, y + .45, z1, 'concrete', 0xd6d6d0); solid(x1 - .3, y, z0, x1, y + .45, z1, 'concrete', 0xd6d6d0); }
  if (!o.noProps) {
    if (w >= 11) {
      [-1, 1].forEach(side => {
        if (rnd() < .8) {
          const px = x + side * (w / 2 - 1.4), pz = z + (rnd() - .5) * (d - 5), t2 = (rnd() * 5) | 0;
          if (t2 === 0) ac(px, y, pz); else if (t2 === 1) vent(px, y, pz); else if (t2 === 2 && d >= 12) tank(px, y, pz); else if (t2 === 3) skylight(px, y, pz, 2.4, 1.8); else antenna(px, y, pz, 4 + rnd() * 3);
        }
      });
    } else if (w >= 8 && rnd() < .6) vent(x + (rnd() < .5 ? -1 : 1) * (w / 2 - .9), y, z + d / 2 - 1.2);
  }
  return { x, y, z, w, d, col };
}
function buildCity() {
  W.groundY = -70; W.platform = cityRoof;
  cityRoof(0, 20, 0, 16, 16, { noProps: true });
  shed(-5.2, 20, 5.2, 4, 4, 3); tank(5.4, 20, 5.2); ac(-5.6, 20, -3.5); vent(5.8, 20, -4); billboard(0, 20, 7.4, 6, 3);
  W.START = { x: 0, y: 20, z: 3 }; W.cur = { x: 0, y: 20, zEdge: -8 };
  let r;
  // 1. разминка
  r = place(2, 0, 12, 14, 0, { noProps: true }); pipeRun(r, 0);
  r = place(3, .5, 10, 14, 0, { noProps: true }); crate(r.x - 2.2, r.y, r.z, 1.2); crate(r.x + 2.4, r.y, r.z - 1, 1.3);
  r = place(3.5, 0, 12, 12, -2); cp(r, 0);
  // 2. балки и трубы
  r = place(3, 0, 9, 8); beam(14, 1.5); r = place(0, 0, 10, 10);
  r = place(3, 0, 9, 8); pipeBridge(13, .55); r = place(0, 0, 12, 12); cp(r, 0);
  // 3. стены
  r = place(3, 0, 12, 16, 0, { noProps: true }); wallClimb(r, -1, 1);
  r = place(3.5, 0, 12, 20, 0, { noProps: true }); wallClimb(r, 0, 2); cp(r, 7.5);
  r = place(3, -.5, 10, 10);
  // 4. прыжки через пропасти
  r = place(4, 0, 9, 9); r = place(4.5, 0, 9, 9, 3); r = place(4.5, .4, 9, 9, -3); cp(r, 0);
  r = place(3, 0, 12, 13, 0, { noProps: true }); pipeRun(r, -3.5); pipeRun(r, 0); pipeRun(r, 3.5);
  // 5. подвижные платформы
  addMoverBridge(10, 4, 7); r = place(10, 0, 10, 10); cp(r, 0);
  moverChain(3, 3.5, 2.5, 3.6, 5.2); r = place(2.5, 0, 10, 10);
  const eg = elevator(4, 9); r = place(eg, 4, 10, 10);
  // 6. каменные ступени
  [[3.6, 0, 2], [4, 0, -3], [4.2, .3, 3.5], [4.2, -.3, -3], [4.4, 0, 2]].forEach(s => { r = place(s[0], s[1], 3.2, 3.2, s[2], { noProps: true }); });
  r = place(4, 0, 12, 12); cp(r, 0);
  // 7. разгон (BHOP), трамплин и серф-жёлоб
  r = place(4, 0, 9, 46, 0, { noProps: true }); cp(r, 19);
  kicker(7, 6, .28, 'concrete', 0xe6dccb);
  r = place(8, -1.6, 9, 12, 0, { noProps: true });
  surfCorridor({ L: 34, th: .9, p: .1, tintL: 0x4fd8ff, tintR: 0xff8a3c });
  r = place(.5, 0, 12, 14); cp(r, 0);
  // 8. финальный участок
  beam(16, 1.1); r = place(0, 0, 8, 8);
  r = place(3.5, 0, 12, 22, 0, { noProps: true }); wallClimb(r, 0, 3); cp(r, 8.5);
  r = place(3, -.4, 8, 8); r = place(4.6, 0, 7, 7); r = place(4.8, 0, 6, 6, 1.5);
  beam(12, 1.0);
  r = place(0, 0, 22, 24, 0, { noProps: true }); buildFinish(r);
  tank(r.x + 8, r.y, r.z + 8); ac(r.x - 8.5, r.y, r.z + 7);
  W.end = W.cur.zEdge;
  skyline({ side: 'facade', top: 'roof', tints: PAL });
  makeGround(-70, 0x5d636a, true);
  makeClouds(18, 110, 180, .8, 1);
}

/* ======================================================================
   2. INDUSTRIAL ZONE
====================================================================== */
const CTN = [0xc0392b, 0x2e86c1, 0x229954, 0xd68910, 0x7d3c98, 0x839192];
function deck(x, y, z, w, d, o) {
  o = o || {};
  const x0 = x - w / 2, x1 = x + w / 2, z0 = z - d / 2, z1 = z + d / 2;
  if (o.ctn) {
    box(x0, y - 2.6, z0, x1, y, z1, 'container', 'container', pick(CTN));
    const col = addCol(x0, y - 2.6, z0, x1, y, z1);
    box(x0 + .3, W.groundY, z0 + .5, x0 + .8, y - 2.6, z0 + 1, 'metal', 'metal', 0x4a525a);
    return { x, y, z, w, d, col };
  }
  box(x0, y - 1.2, z0, x1, y, z1, 'rust', 'grate', 0xffffff, null, true);
  const col = addCol(x0, y - 1.2, z0, x1, y, z1);
  [[x0 + .6, z0 + .6], [x1 - .6, z0 + .6], [x0 + .6, z1 - .6], [x1 - .6, z1 - .6]].forEach(c => box(c[0] - .3, W.groundY, c[1] - .3, c[0] + .3, y - 1.2, c[1] + .3, 'metal', 'metal', 0x5d656c));
  if (w >= 6) { box(x0, y, z0, x1, y + .05, z0 + .3, 'hazard', 'hazard'); box(x0, y, z1 - .3, x1, y + .05, z1, 'hazard', 'hazard'); }
  if (!o.noProps && w >= 10 && d >= 10) {
    [-1, 1].forEach(side => {
      if (rnd() < .75) {
        const px = x + side * (w / 2 - 1.5), pz = z + (rnd() - .5) * (d - 5), t = (rnd() * 4) | 0;
        if (t === 0) { solid(px - 1.3, y, pz - 3, px + 1.3, y + 2.6, pz + 3, 'container', pick(CTN)); }
        else if (t === 1) tank(px, y, pz); else if (t === 2) vent(px, y, pz); else { crate(px, y, pz, 1.3); crate(px + 1.3, y, pz, 1.1); }
      }
    });
  }
  return { x, y, z, w, d, col };
}
function buildIndustrial() {
  W.groundY = -50; W.platform = deck;
  deck(0, 16, 0, 18, 18, { noProps: true });
  solid(-7.4, 16, 0.5, -4.8, 18.6, 6.5, 'container', 0xc0392b); tank(6.2, 16, 5.2); vent(6, 16, -4.5); crate(-6.4, 16, -5, 1.3);
  W.START = { x: 0, y: 16, z: 3 }; W.cur = { x: 0, y: 16, zEdge: -9 };
  let r;
  r = place(2.5, 0, 10, 14, 0, { noProps: true }); pipeRun(r, -3); pipeRun(r, 2.5);
  r = place(3, .6, 3.4, 7, 0, { ctn: true }); r = place(2.6, .4, 3.4, 7, 2.2, { ctn: true }); r = place(2.6, -.3, 3.4, 7, -2.2, { ctn: true });
  r = place(3, 0, 12, 12); cp(r, 0);
  // слайд под балками
  r = place(3, 0, 12, 26, 0, { noProps: true }); lowBar(r, -5); lowBar(r, -15);
  r = place(3.5, .4, 9, 8); pipeBridge(14, .55); r = place(0, 0, 12, 12); cp(r, 0);
  // разгон + бхоп-дорожка
  r = place(3.5, 0, 8, 44, 0, { noProps: true }); cp(r, 17);
  pads(7, 3.2, 2.8, 6.4, [0]);
  r = place(4, 0, 12, 12); cp(r, 0);
  // подвижные платформы
  addMoverBridge(10, 4, 7); r = place(10, 0, 10, 10);
  moverChain(3, 3.5, 2.6, 3.8, 5.0); r = place(2.6, 0, 10, 10);
  const eg = elevator(4, 9); r = place(eg, 4, 10, 10); cp(r, 0);
  // серф
  r = place(3, 0, 9, 12, 0, { noProps: true });
  surfCorridor({ L: 38, th: .88, p: .1, tintL: 0xff9a3c, tintR: 0xffd24a });
  r = place(.5, 0, 12, 14); cp(r, 0);
  // стена из контейнеров и финальная бхоп-дорожка
  r = place(3, 0, 12, 22, 0, { noProps: true }); wallClimb(r, 0, 3, 'rust', 'container'); cp(r, 8.5);
  r = place(3, -.5, 9, 9);
  pads(7, 3.0, 3.4, 7.2, [3, -3]);
  r = place(4, 0, 22, 24, 0, { noProps: true }); buildFinish(r);
  tank(r.x + 8, r.y, r.z + 8); solid(r.x - 9.5, r.y, r.z + 4, r.x - 7, r.y + 2.6, r.z + 10, 'container', 0x2e86c1);
  W.end = W.cur.zEdge;
  // фон: заводы, трубы, трубопроводные эстакады
  for (let z = 90; z > W.end - 180; z -= 18 + rnd() * 22) {
    [-1, 1].forEach(side => {
      const x = side * (30 + rnd() * 10), w = 10 + rnd() * 8, d = 14 + rnd() * 10, top = -10 + rnd() * 26;
      box(x - w / 2, W.groundY, z - d / 2, x + w / 2, top, z + d / 2, 'brick', 'roof', pick([0xffffff, 0xe0cfc0, 0xc9c0b8]));
      for (let row = 0; row < 3; row++) {
        const xx = side * (55 + row * 42 + rnd() * 20), ww = 16 + rnd() * 20, dd = 16 + rnd() * 20, tt = 6 + rnd() * 44, zo = z + rnd() * 12;
        box(xx - ww / 2, W.groundY, zo - dd / 2, xx + ww / 2, tt, zo + dd / 2, rnd() < .5 ? 'rust' : 'brick', 'roof', pick([0xffffff, 0xd8c8b8, 0xb8aaa0]));
        if (rnd() < .5) { const h = 30 + rnd() * 40; cyl('brick', 0xe6d6c6, xx, tt + h / 2, zo, 1.6, 2.3, h, 'y', 10); cyl('hazard', 0xffffff, xx, tt + h - 2.5, zo, 1.66, 1.7, 3, 'y', 10); }
      }
    });
  }
  [-1, 1].forEach(side => {
    for (let z = 80; z > W.end - 150; z -= 48) {
      cyl('metal', 0x8a96a0, side * 26, 4, z - 24, .9, .9, 48, 'z', 10);
      box(side * 26 - .5, W.groundY, z - .5, side * 26 + .5, 3.2, z + .5, 'metal', 'metal', 0x5b646d);
    }
  });
  makeGround(-50, 0x3b3a38, true);
}

/* ======================================================================
   3. NIGHT CITY
====================================================================== */
const NEON = [0x00e5ff, 0xff2fd0, 0xffe14a, 0x7dff6a];
let nIdx = 0;
function nightRoof(x, y, z, w, d, o) {
  o = o || {};
  const x0 = x - w / 2, x1 = x + w / 2, z0 = z - d / 2, z1 = z + d / 2;
  box(x0, W.groundY, z0, x1, y, z1, 'nfacade', 'roof', 0xffffff);
  box(x0 - .2, y - .6, z0 - .2, x1 + .2, y - .02, z1 + .2, 'concrete', 'concrete', 0x4a4f60, null, true);
  const col = addCol(x0, y - 60, z0, x1, y, z1);
  const nc = NEON[(nIdx++) % NEON.length], t = .2, hh = .1;
  box(x0, y, z0, x1, y + hh, z0 + t, 'neon', 'neon', nc); box(x0, y, z1 - t, x1, y + hh, z1, 'neon', 'neon', nc);
  box(x0, y, z0, x0 + t, y + hh, z1, 'neon', 'neon', nc); box(x1 - t, y, z0, x1, y + hh, z1, 'neon', 'neon', nc);
  if (w >= 8 && !o.pad) { solid(x0 + .2, y, z0, x0 + .5, y + .45, z1, 'concrete', 0x3a3f50); solid(x1 - .5, y, z0, x1 - .2, y + .45, z1, 'concrete', 0x3a3f50); }
  if (!o.noProps && !o.pad && w >= 11) {
    [-1, 1].forEach(side => {
      if (rnd() < .7) {
        const px = x + side * (w / 2 - 1.6), pz = z + (rnd() - .5) * (d - 5), t2 = (rnd() * 3) | 0;
        if (t2 === 0) ac(px, y, pz); else if (t2 === 1) vent(px, y, pz); else antenna(px, y, pz, 4 + rnd() * 3);
      }
    });
  }
  return { x, y, z, w, d, col };
}
function buildNight() {
  W.groundY = -70; W.platform = nightRoof; nIdx = 0;
  nightRoof(0, 60, 0, 16, 16, { noProps: true });
  sign(0, 66.5, 7.6, 9, 3.4, 'NIGHT CITY', '#00e5ff'); ac(-5.5, 60, -3.5); vent(5.8, 60, -4);
  W.START = { x: 0, y: 60, z: 3 }; W.cur = { x: 0, y: 60, zEdge: -8 };
  let r;
  // подъём по неоновым площадкам
  r = pads(6, 4, 2.6, 3.6, [2.5, -2.5], .9);
  r = place(3, .5, 12, 12); cp(r, 0);
  // разгон и трамплин
  r = place(3.5, 0, 8, 50, 0, { noProps: true }); cp(r, 20);
  kicker(7, 6, .28, 'concrete', 0x59607a);
  r = place(8.5, -1.6, 9, 12, 0, { noProps: true }); 
  // серф 1
  surfCorridor({ L: 40, th: .9, p: .1, tintL: 0x00e5ff, tintR: 0xff2fd0 });
  r = place(.5, 0, 12, 12); cp(r, 0);
  // ворота для слайда + подвижный мост
  r = place(3, 0, 12, 28, 0, { noProps: true }); lowBar(r, -5); lowBar(r, -15); lowBar(r, -23);
  addMoverBridge(11, 4, 7.5, 0xff9ad8); r = place(11, 0, 10, 10); cp(r, 0);
  // зигзаг на маленьких площадках
  r = pads(9, 2.6, 3, 5.8, [3, -3], 0);
  r = place(4, 0, 12, 12); cp(r, 0);
  // серф 2 (круче и быстрее)
  r = place(3, 0, 9, 14, 0, { noProps: true });
  surfCorridor({ L: 50, th: .95, p: .13, gw: 2.8, tintL: 0xffe14a, tintR: 0x7dff6a });
  r = place(.5, 0, 12, 20, 0, { noProps: true }); cp(r, 6);
  kicker(6, 6, .3, 'concrete', 0x59607a);
  r = place(8.5, -1.8, 22, 24, 0, { noProps: true }); buildFinish(r);
  sign(r.x, r.y + 8.5, r.z - 8, 10, 3, 'FINISH', '#ffd34a');
  W.end = W.cur.zEdge;
  skyline({ side: 'nfacade', top: 'roof', tints: [0xffffff], hMax: 130, neon: NEON });
  makeGround(-70, 0x0b0d18, false);
}

/* ======================================================================
   4. SKY PARKOUR
====================================================================== */
function island(x, y, z, w, d, o) {
  const x0 = x - w / 2, x1 = x + w / 2, z0 = z - d / 2, z1 = z + d / 2, ins = Math.min(w, d) * .12;
  box(x0, y - 1.2, z0, x1, y, z1, 'cloudp', 'cloudp', 0xffffff);
  box(x0 + ins, y - 3.6, z0 + ins, x1 - ins, y - 1.2, z1 - ins, 'rock', 'rock', 0xbab2a2);
  box(x0 + ins * 2, y - 6.4, z0 + ins * 2, x1 - ins * 2, y - 3.6, z1 - ins * 2, 'rock', 'rock', 0x9d9586);
  box(x0 + ins * 3, y - 10, z0 + ins * 3, x1 - ins * 3, y - 6.4, z1 - ins * 3, 'rock', 'rock', 0x857d70);
  const col = addCol(x0, y - 1.2, z0, x1, y, z1);
  if (o && !o.pad && !o.noProps && w >= 12 && rnd() < .7) {
    const px = x + (rnd() < .5 ? -1 : 1) * (w / 2 - 1.6), pz = z + (rnd() - .5) * (d - 4);
    cyl('cloudp', 0xdde8f5, px, y + 1.2, pz, .35, .5, 2.4, 'y', 8); cyl('neon', 0x7fdcff, px, y + 2.6, pz, .6, .6, .25, 'y', 8);
  }
  return { x, y, z, w, d, col };
}
function skyRing(x, y, z, r, color) {
  const m = new THREE.Mesh(new THREE.TorusGeometry(r, .35, 8, 36), new THREE.MeshBasicMaterial({ color })); m.position.set(x, y, z); add(m);
}
function buildSky() {
  W.groundY = -8; W.platform = island; W.killDrop = 30;
  island(0, 40, 0, 14, 14, { noProps: true });
  W.START = { x: 0, y: 40, z: 3 }; W.cur = { x: 0, y: 40, zEdge: -7 };
  let r;
  r = pads(6, 3.6, 3, 5.0, [3, -3], .35);
  r = place(4, 0, 12, 12); cp(r, 0);
  r = place(4, 0, 7, 44, 0, { noProps: true }); cp(r, 17);
  kicker(7, 5.5, .28, 'cloudp');
  r = place(8, -1.6, 9, 12, 0, { noProps: true });
  skyRing(r.x, r.y + 6, r.z + 18, 5, 0x7fdcff);
  surfCorridor({ L: 56, th: .92, p: .15, gw: 3, tintL: 0x7fdcff, tintR: 0xff9ad0, floorKey: 'cloudp', floorTint: 0xdfeaf6 });
  r = place(.5, 0, 12, 14); cp(r, 0);
  moverChain(4, 3.8, 2.8, 3.6, 5.0); r = place(2.8, 0, 10, 10); cp(r, 0);
  addMoverBridge(10, 4, 7); r = place(10, 0, 10, 10);
  r = pads(5, 3.2, 3.2, 4.6, [2.6, -2.6], 1.0);
  r = place(4, 0, 12, 12); cp(r, 0);
  r = place(3.5, 0, 6, 36, 0, { noProps: true });
  pads(10, 2.8, 3.4, 7.4, [0]);
  r = place(4, 0, 22, 24, 0, { noProps: true }); buildFinish(r);
  skyRing(r.x, r.y + 7, r.z + 6, 7, 0xffd34a);
  W.end = W.cur.zEdge;
  // декоративные парящие скалы
  for (let i = 0; i < 46; i++) {
    const side = rnd() < .5 ? -1 : 1, x = side * (22 + rnd() * 120), z = 90 - rnd() * (90 - W.end + 160), y = 8 + rnd() * 70, s = 3 + rnd() * 9;
    cyl('rock', pick([0xb0a898, 0x9a9284, 0xc2bcae]), x, y, z, s, s * .18, s * 1.3, 'y', 9); cyl('cloudp', 0xffffff, x, y + s * .66, z, s * 1.02, s * 1.02, .5, 'y', 9);
  }
  makeGround(-8, 0xf3f8ff, false);
  makeClouds(30, -14, 8, .9, 1.5);
}

/* ======================================================================
   5. CONSTRUCTION SITE
====================================================================== */
function slab(x, y, z, w, d, o) {
  o = o || {};
  const x0 = x - w / 2, x1 = x + w / 2, z0 = z - d / 2, z1 = z + d / 2;
  if (o.pad) {
    box(x0, y - .22, z0, x1, y, z1, 'wood', 'wood');
    const col = addCol(x0, y - .5, z0, x1, y, z1);
    [[x0 + .15, z0 + .15], [x1 - .15, z0 + .15], [x0 + .15, z1 - .15], [x1 - .15, z1 - .15]].forEach(c => box(c[0] - .06, W.groundY, c[1] - .06, c[0] + .06, y - .22, c[1] + .06, 'metal', 'metal', 0x59626b));
    for (let yy = y - 3; yy > y - 12; yy -= 3) { box(x0 + .1, yy, z0 + .1, x1 - .1, yy + .08, z0 + .18, 'metal', 'metal', 0x59626b); box(x0 + .1, yy, z1 - .18, x1 - .1, yy + .08, z1 - .1, 'metal', 'metal', 0x59626b); }
    return { x, y, z, w, d, col };
  }
  box(x0, y - .9, z0, x1, y, z1, 'concrete', 'concrete', 0xdad7d0, null, true);
  const col = addCol(x0, y - .9, z0, x1, y, z1);
  if (w >= 8) [[x0 + .7, z0 + .7], [x1 - .7, z0 + .7], [x0 + .7, z1 - .7], [x1 - .7, z1 - .7]].forEach(c => box(c[0] - .35, W.groundY, c[1] - .35, c[0] + .35, y - .9, c[1] + .35, 'concrete', 'concrete', 0xb9b6ae));
  box(x0, y, z0, x1, y + .05, z0 + .3, 'hazard', 'hazard'); box(x0, y, z1 - .3, x1, y + .05, z1, 'hazard', 'hazard');
  if (!o.noProps && w >= 10 && d >= 10) {
    [-1, 1].forEach(side => {
      if (rnd() < .75) {
        const px = x + side * (w / 2 - 1.5), pz = z + (rnd() - .5) * (d - 5), t = (rnd() * 3) | 0;
        if (t === 0) { crate(px, y, pz, 1.3); crate(px + 1.3, y, pz, 1.1); crate(px + .6, y + 1.1, pz, 1.0); }
        else if (t === 1) { cyl('metal', 0xd9852b, px, y + .5, pz, .45, .45, 1, 'y', 10); cyl('metal', 0xd9852b, px + 1.1, y + .5, pz, .45, .45, 1, 'y', 10); addCol(px - .5, y, pz - .5, px + 1.6, y + 1, pz + .5); }
        else { solid(px - 1.2, y, pz - .8, px + 1.2, y + .9, pz + .8, 'wood', 0xffffff); }
      }
    });
  }
  return { x, y, z, w, d, col };
}
function crane(x, y0, z, h, jib) {
  const yel = 0xe8b020;
  box(x - .7, y0, z - .7, x + .7, y0 + h, z + .7, 'beam', 'beam', yel);
  box(x - 1.2, y0 + h, z - 1.2, x + 1.2, y0 + h + 2.4, z + 1.2, 'beam', 'beam', 0xf2c230);
  box(x - .35, y0 + h + 2.4, z - jib, x + .35, y0 + h + 3.2, z + jib * .35, 'beam', 'beam', yel);
  box(x - 1.2, y0 + h + 1.2, z + jib * .35, x + 1.2, y0 + h + 3, z + jib * .35 + 3, 'concrete', 'concrete', 0x777c82);
  cyl('plain', 0x2b2f33, x, y0 + h + 1.6 - jib * .3, z - jib * .6, .05, .05, 3 + jib * .3, 'y', 4);
  box(x - .6, y0 + h - 5 - jib * .3, z - jib * .6 - .6, x + .6, y0 + h - 4 - jib * .3, z - jib * .6 + .6, 'hazard', 'hazard');
}
function buildConstruction() {
  W.groundY = -30; W.platform = slab;
  slab(0, 14, 0, 18, 18, { noProps: true });
  crate(-5.5, 14, 4.5, 1.3); crate(-4.1, 14, 4.8, 1.1); crate(-4.8, 15.1, 4.6, 1.0); tank(6, 14, 5.4); solid(5, 14, -4.5, 7.5, 14.9, -2.5, 'wood', 0xffffff);
  billboard(0, 14, 7.6, 6, 3);
  W.START = { x: 0, y: 14, z: 3 }; W.cur = { x: 0, y: 14, zEdge: -9 };
  let r;
  r = pads(5, 4.4, 2.4, 3.2, [2.5, -2.5], .95);
  r = place(3, .5, 12, 12); cp(r, 0);
  beam(14, 1.5); r = place(0, 0, 10, 10); beam(16, 1.1); r = place(0, 0, 10, 12); cp(r, 0);
  r = place(3, 0, 12, 26, 0, { noProps: true }); lowBar(r, -5); lowBar(r, -15);
  r = place(3.5, 0, 12, 20, 0, { noProps: true }); wallClimb(r, 0, 2, 'concrete', 'wood'); cp(r, 7.5);
  r = place(3, -.5, 10, 10);
  addMoverBridge(10, 4, 6.5); r = place(10, 0, 10, 10);
  moverChain(3, 3.4, 2.6, 3.8, 5.0); r = place(2.6, 0, 10, 10);
  const eg = elevator(5, 10); r = place(eg, 5, 10, 10); cp(r, 0);
  r = place(3.5, 0, 8, 44, 0, { noProps: true }); cp(r, 17);
  kicker(7, 6, .28, 'concrete', 0xcfcac0);
  r = place(8, -1.6, 9, 12, 0, { noProps: true });
  surfCorridor({ L: 34, th: .88, p: .1, tintL: 0xff9a3c, tintR: 0xffd24a, floorKey: 'concrete', floorTint: 0xb9b6ae });
  r = place(.5, 0, 12, 14); cp(r, 0);
  pads(7, 3.2, 3.2, 7.0, [3, -3]);
  r = place(4, 0, 22, 24, 0, { noProps: true }); buildFinish(r);
  crate(r.x + 8, r.y, r.z + 8, 1.4); crate(r.x + 9.4, r.y, r.z + 8, 1.2);
  W.end = W.cur.zEdge;
  for (let z = 70; z > W.end - 120; z -= 70 + rnd() * 30) crane(rnd() < .5 ? -24 : 26, W.groundY, z, 52 + rnd() * 20, 22);
  skyline({ side: 'facade', top: 'roof', tints: [0xffffff, 0xf0e2cf, 0xe6d6c4], hMax: 80, near: 38, nearH: 26, lift: -6 });
  makeGround(-30, 0x6d6a60, true);
  makeClouds(12, 100, 160, .55, 1);
}

/* ======================================================================
   Реестр карт
====================================================================== */
export const MAPS = [
  {
    id: 'city', name: 'CITY ROOFTOPS', desc: 'Классика: крыши высоток, вентиляция, стены, подвижные платформы, длинный разгон с трамплином и серф-жёлоб.',
    diff: 2, tags: ['BHOP', 'SURF', 'SLIDE'], seed: 20240607, preview: 'city', build: buildCity,
    atmo: { sky: [0x2f86e0, 0x86beef, 0xcfe4f6], fog: [0xcfe4f6, 50, 320], hemi: [0xcfe6ff, 0x9a9488, .85], sun: [0xfff0d8, .95, [.7, .55, .3]] }
  },
  {
    id: 'industrial', name: 'INDUSTRIAL ZONE', desc: 'Завод: ржавые платформы, трубы, контейнеры, низкие балки для слайда, бхоп-дорожка и серф между цехами.',
    diff: 2, tags: ['BHOP', 'SURF', 'SLIDE'], seed: 777, preview: 'industrial', build: buildIndustrial,
    atmo: { sky: [0x4d5f70, 0xa8a193, 0xdcb98c], fog: [0xd2ad84, 40, 260], hemi: [0xe6d6c0, 0x6a5848, .8], sun: [0xffd9a8, .9, [-.6, .5, .4]], sunSpriteColor: 0xffc890 }
  },
  {
    id: 'night', name: 'NIGHT CITY', desc: 'Ночной город в неоне: подъём по вывескам, зигзаг по крошечным площадкам, два серф-жёлоба и прыжок на финиш.',
    diff: 3, tags: ['BHOP', 'SURF', 'SLIDE'], seed: 4242, preview: 'night', build: buildNight,
    atmo: { sky: [0x04060f, 0x121a44, 0x2c2260], fog: [0x161a3c, 30, 240], hemi: [0x7f8fe0, 0x1a1230, .8], sun: [0x9fb4ff, .55, [-.5, .6, .5]], sunSpriteColor: 0xb8c8ff }
  },
  {
    id: 'sky', name: 'SKY PARKOUR', desc: 'Парящие острова над облаками: длинный серф-спуск, подвижные облака, трамплин и финальная бхоп-линия на высоте.',
    diff: 3, tags: ['BHOP', 'SURF'], seed: 99, preview: 'sky', build: buildSky,
    atmo: { sky: [0x1c6fe0, 0x7fc3ff, 0xf6fbff], fog: [0xe3f1ff, 80, 420], hemi: [0xffffff, 0xb8c8e0, .95], sun: [0xfff6e0, 1.0, [.4, .7, .3]] }
  },
  {
    id: 'construction', name: 'CONSTRUCTION SITE', desc: 'Стройка на закате: леса и доски, стальные балки, опалубка для слайда, лифт-платформы и деревянный серф.',
    diff: 1, tags: ['BHOP', 'SURF', 'SLIDE'], seed: 31337, preview: 'construction', build: buildConstruction,
    atmo: { sky: [0x3f80d0, 0xf2c89c, 0xffe2b8], fog: [0xf0d2ae, 50, 300], hemi: [0xffeedd, 0x8a7a68, .85], sun: [0xffd49a, 1.0, [.8, .35, .2]], sunSpriteColor: 0xffc070 }
  }
];
export const SOON = [
  { id: 'subway', name: 'SUBWAY PARKOUR', desc: 'Станции, тоннели и вагоны метро.', diff: 2, preview: 'subway', atmo: { sky: [0x10141c, 0x1c2430, 0x2a3442] } },
  { id: 'abandoned', name: 'ABANDONED CITY', desc: 'Заброшенные здания и разрушенные конструкции.', diff: 2, preview: 'ruins', atmo: { sky: [0x56606a, 0x9aa0a0, 0xc4c4bc] } },
  { id: 'nature', name: 'NATURE PARKOUR', desc: 'Скалы, деревья и подвесные мосты.', diff: 1, preview: 'nature', atmo: { sky: [0x3c8cd8, 0x9fd4f0, 0xe0f0e4] } }
];

export function loadMap(id) {
  const m = MAPS.find(x => x.id === id) || MAPS[0];
  resetWorld(); seed(m.seed); applyAtmosphere(m.atmo); W.id = m.id;
  m.build(); buildBatches();
  return m;
}
export const cpCount = () => CPS.length;

/* ---------- 2D-превью для карточек ---------- */
const hex = n => '#' + ('000000' + n.toString(16)).slice(-6);
export function drawPreview(cv, m) {
  const w = cv.width = 320, h = cv.height = 180, g = cv.getContext('2d'), a = m.atmo.sky;
  const gr = g.createLinearGradient(0, 0, 0, h); gr.addColorStop(0, hex(a[0])); gr.addColorStop(.55, hex(a[1])); gr.addColorStop(1, hex(a[2]));
  g.fillStyle = gr; g.fillRect(0, 0, w, h);
  let s = 7; const R = () => { s = (s * 16807) % 2147483647; return s / 2147483647; };
  const st = m.preview;
  const bld = (x, y, bw, bh, col, win) => {
    g.fillStyle = col; g.fillRect(x, y, bw, bh);
    if (win) { for (let yy = y + 6; yy < y + bh - 6; yy += 9) for (let xx = x + 4; xx < x + bw - 5; xx += 8) { if (R() < .6) { g.fillStyle = win[(R() * win.length) | 0]; g.fillRect(xx, yy, 4, 5); } } }
  };
  if (st === 'city' || st === 'night' || st === 'construction' || st === 'ruins') {
    const night = st === 'night';
    for (let i = 0; i < 12; i++) bld(i * 28 - 6, 70 + R() * 40, 26, 120, night ? '#101530' : st === 'ruins' ? '#6b7076' : '#a9bdd0', night ? ['#ffd27a', '#7be8ff', '#ff7ad9'] : ['#e8f3ff']);
    for (let i = 0; i < 5; i++) bld(i * 70 - 10 + R() * 20, 110 + R() * 20, 56, 90, night ? '#1a2048' : st === 'construction' ? '#8a8f95' : '#8097ac', night ? ['#ffd27a', '#7be8ff'] : ['#d6e8f8']);
    if (night) { ['#00e5ff', '#ff2fd0', '#ffe14a'].forEach((c, i) => { g.fillStyle = c; g.shadowColor = c; g.shadowBlur = 12; g.fillRect(30 + i * 100, 118, 70, 4); g.shadowBlur = 0; }); }
    if (st === 'construction') { g.fillStyle = '#e8b020'; g.fillRect(238, 20, 6, 130); g.fillRect(168, 24, 110, 6); g.fillRect(268, 24, 14, 12); g.fillStyle = '#222'; g.fillRect(180, 30, 2, 28); g.fillStyle = '#f2c200'; g.fillRect(176, 58, 10, 8); }
    g.fillStyle = night ? '#1b2038' : '#d8d6cf'; g.fillRect(40, 138, 150, 14); g.fillRect(205, 128, 80, 14);
    g.fillStyle = night ? '#00e5ff' : '#ff8a3c'; g.fillRect(40, 138, 150, 2);
  } else if (st === 'industrial') {
    for (let i = 0; i < 9; i++) bld(i * 38 - 8, 100 + R() * 30, 34, 90, i % 2 ? '#7a5844' : '#8f6c55', null);
    for (let i = 0; i < 4; i++) { const x = 30 + i * 80, hh = 60 + R() * 50; g.fillStyle = '#a58a76'; g.fillRect(x, 130 - hh, 12, hh); g.fillStyle = '#f2c200'; g.fillRect(x, 130 - hh, 12, 6); g.fillStyle = 'rgba(70,60,55,.55)'; g.beginPath(); g.arc(x + 14, 130 - hh - 14, 14, 0, 6.3); g.fill(); }
    g.fillStyle = '#4a4f55'; g.fillRect(30, 140, 130, 10); g.fillStyle = '#c0392b'; g.fillRect(190, 126, 46, 18); g.fillStyle = '#2e86c1'; g.fillRect(238, 126, 46, 18); g.fillStyle = '#d68910'; g.fillRect(214, 108, 46, 18);
  } else if (st === 'sky') {
    g.fillStyle = 'rgba(255,255,255,.9)'; for (let i = 0; i < 14; i++) { g.beginPath(); g.ellipse(R() * w, 150 + R() * 30, 50 + R() * 40, 14 + R() * 8, 0, 0, 6.3); g.fill(); }
    [[30, 120, 60], [120, 100, 44], [200, 80, 40], [260, 56, 50]].forEach(p => { g.fillStyle = '#f4f7fb'; g.fillRect(p[0], p[1], p[2], 7); g.fillStyle = '#9d9586'; g.beginPath(); g.moveTo(p[0] + 4, p[1] + 7); g.lineTo(p[0] + p[2] - 4, p[1] + 7); g.lineTo(p[0] + p[2] / 2, p[1] + 32); g.fill(); });
  } else if (st === 'subway') {
    g.fillStyle = '#1b222c'; g.fillRect(0, 0, w, h); g.fillStyle = '#2d3744'; g.fillRect(0, 100, w, 80); g.fillStyle = '#fff4b0'; for (let i = 0; i < 6; i++) g.fillRect(20 + i * 52, 14, 30, 4);
    g.fillStyle = '#3d7ec4'; g.fillRect(60, 70, 200, 50); g.fillStyle = '#d6eaff'; for (let i = 0; i < 5; i++) g.fillRect(70 + i * 38, 80, 28, 18);
  } else if (st === 'nature') {
    g.fillStyle = '#6f8f58'; g.beginPath(); g.moveTo(0, 150); g.lineTo(80, 80); g.lineTo(160, 140); g.lineTo(240, 70); g.lineTo(320, 130); g.lineTo(320, 180); g.lineTo(0, 180); g.fill();
    g.fillStyle = '#2f6b3a'; for (let i = 0; i < 12; i++) { const x = R() * w, y = 130 + R() * 30; g.beginPath(); g.moveTo(x, y - 34); g.lineTo(x + 12, y); g.lineTo(x - 12, y); g.fill(); }
  }
  const sh = g.createLinearGradient(0, h - 50, 0, h); sh.addColorStop(0, 'rgba(0,0,0,0)'); sh.addColorStop(1, 'rgba(0,0,0,.45)'); g.fillStyle = sh; g.fillRect(0, h - 50, w, 50);
}
