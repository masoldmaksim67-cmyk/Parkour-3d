import './boot.js';
// Ядро рендера и мира: сцена, небо, атмосфера, текстуры, материалы, батчинг геометрии, примитивы уровня.
import * as THREE from 'three';
import { S } from './state.js';
import { COL, CPS, MOV, clearColliders, addCol, addObb, makeMoverData } from './collision.js';

export { THREE, addCol };
export const TAU = Math.PI * 2;
export const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);

/* ---------- renderer / scene ---------- */
export const canvas = document.getElementById('c');
export const dpr = window.devicePixelRatio || 1;
export const renderer = new THREE.WebGLRenderer({ canvas, antialias: dpr < 2, powerPreference: 'high-performance', alpha: false, stencil: false });
renderer.shadowMap.type = THREE.PCFShadowMap;
renderer.setClearColor(0xcfe4f6, 1);

export const scene = new THREE.Scene();
scene.fog = new THREE.Fog(0xcfe4f6, 50, 320);
export const camera = new THREE.PerspectiveCamera(72, 1, 0.12, 800);
camera.rotation.order = 'YXZ';
scene.add(camera);

export const hemi = new THREE.HemisphereLight(0xcfe6ff, 0x9a9488, 0.85);
scene.add(hemi);
export const sun = new THREE.DirectionalLight(0xfff0d8, 0.95);
const SH = 38;
sun.castShadow = true;
sun.shadow.camera.left = -SH; sun.shadow.camera.right = SH; sun.shadow.camera.top = SH; sun.shadow.camera.bottom = -SH;
sun.shadow.camera.near = 1; sun.shadow.camera.far = 280;
sun.shadow.bias = -0.0006; sun.shadow.normalBias = 0.04;
sun.shadow.camera.updateProjectionMatrix();
scene.add(sun); scene.add(sun.target);
export const lightDir = new THREE.Vector3(0.7, 0.55, 0.3).normalize();
const lR = new THREE.Vector3(), lU = new THREE.Vector3();
function calcLightBasis() {
  lR.crossVectors(new THREE.Vector3(0, 1, 0), lightDir).normalize();
  lU.crossVectors(lightDir, lR).normalize();
}
calcLightBasis();
export function updateShadow(cx, cy, cz) {
  const texel = (2 * SH) / (sun.shadow.mapSize.x || 1024);
  const a = cx * lR.x + cy * lR.y + cz * lR.z, b = cx * lU.x + cy * lU.y + cz * lU.z;
  const sa = Math.round(a / texel) * texel - a, sb = Math.round(b / texel) * texel - b;
  const tx = cx + lR.x * sa + lU.x * sb, ty = cy + lR.y * sa + lU.y * sb, tz = cz + lR.z * sa + lU.z * sb;
  sun.target.position.set(tx, ty, tz);
  sun.position.set(tx + lightDir.x * 120, ty + lightDir.y * 120, tz + lightDir.z * 120);
  sun.target.updateMatrixWorld();
}

export const sky = new THREE.Mesh(
  new THREE.SphereGeometry(600, 16, 10),
  new THREE.ShaderMaterial({
    side: THREE.BackSide, depthWrite: false, fog: false,
    uniforms: { top: { value: new THREE.Color(0x2f86e0) }, mid: { value: new THREE.Color(0x86beef) }, hor: { value: new THREE.Color(0xcfe4f6) } },
    vertexShader: 'varying vec3 vP; void main(){ vP=position; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }',
    fragmentShader: 'uniform vec3 top; uniform vec3 mid; uniform vec3 hor; varying vec3 vP; void main(){ float h=normalize(vP).y; vec3 c=h<0.0?hor:mix(hor,mid,smoothstep(0.0,0.22,h)); c=mix(c,top,smoothstep(0.18,0.85,h)); gl_FragColor=vec4(c,1.0); }'
  })
);
sky.frustumCulled = false; sky.renderOrder = -10;
scene.add(sky);

export function radialTex(size, stops) {
  const c = document.createElement('canvas'); c.width = c.height = size;
  const g = c.getContext('2d'); const gr = g.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  stops.forEach(s => gr.addColorStop(s[0], s[1])); g.fillStyle = gr; g.fillRect(0, 0, size, size);
  return new THREE.CanvasTexture(c);
}
export const sunSprite = new THREE.Sprite(new THREE.SpriteMaterial({
  map: radialTex(128, [[0, 'rgba(255,255,255,1)'], [0.12, 'rgba(255,248,210,.95)'], [0.3, 'rgba(255,225,150,.35)'], [1, 'rgba(255,200,120,0)']]),
  blending: THREE.AdditiveBlending, transparent: true, depthWrite: false, fog: false
}));
sunSprite.scale.set(190, 190, 1); sunSprite.renderOrder = -9;
scene.add(sunSprite);

/* ---------- атмосфера карты ---------- */
export const ATMO = { cur: null };
export function applyAtmosphere(a) {
  ATMO.cur = a;
  const u = sky.material.uniforms;
  u.top.value.set(a.sky[0]); u.mid.value.set(a.sky[1]); u.hor.value.set(a.sky[2]);
  scene.fog.color.set(a.fog[0]); scene.fog.near = a.fog[1];
  renderer.setClearColor(a.fog[0], 1);
  hemi.color.set(a.hemi[0]); hemi.groundColor.set(a.hemi[1]); hemi.intensity = a.hemi[2];
  sun.color.set(a.sun[0]); sun.intensity = a.sun[1];
  lightDir.set(a.sun[2][0], a.sun[2][1], a.sun[2][2]).normalize(); calcLightBasis();
  sunSprite.visible = a.sunSprite !== false;
  sunSprite.material.color.set(a.sunSpriteColor || 0xffffff);
  applyFogFar();
}
const QP = [
  { pr: 1.0, shadow: 0, fogFar: 230, clouds: false },
  { pr: 1.5, shadow: 1024, fogFar: 320, clouds: true },
  { pr: 2.0, shadow: 2048, fogFar: 400, clouds: true }
];
export const QUAL = { target: 1, cur: 1 };
function applyFogFar() {
  const q = QP[S.quality] || QP[1], a = ATMO.cur;
  scene.fog.far = Math.min(a ? a.fog[2] : 320, q.fogFar);
}
export function applyQuality(resizeFn) {
  const q = QP[S.quality] || QP[1];
  QUAL.target = Math.min(dpr, q.pr); QUAL.cur = QUAL.target; renderer.setPixelRatio(QUAL.cur);
  const useSh = q.shadow > 0;
  if (renderer.shadowMap.enabled !== useSh) { renderer.shadowMap.enabled = useSh; Object.keys(MAT).forEach(k => { MAT[k].needsUpdate = true; }); }
  sun.castShadow = useSh;
  if (useSh && sun.shadow.mapSize.x !== q.shadow) { sun.shadow.mapSize.set(q.shadow, q.shadow); if (sun.shadow.map) { sun.shadow.map.dispose(); sun.shadow.map = null; } }
  applyFogFar();
  if (W.cloudGroup) W.cloudGroup.visible = q.clouds;
  if (resizeFn) resizeFn();
}

/* ---------- random + textures ---------- */
export function mulberry32(a) { return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
let rndFn = mulberry32(1);
export const seed = n => { rndFn = mulberry32(n); };
export const rnd = () => rndFn();
const trnd = mulberry32(20240607);
const maxAniso = Math.min(4, renderer.capabilities.getMaxAnisotropy());
function mkTex(w, h, draw) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const g = c.getContext('2d'); draw(g, w, h);
  const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.anisotropy = maxAniso; return t;
}
function speckle(g, w, h, n, a, lo, hi) {
  for (let i = 0; i < n; i++) { const v = (lo + trnd() * (hi - lo)) | 0; g.fillStyle = 'rgba(' + v + ',' + v + ',' + v + ',' + a + ')'; g.fillRect(trnd() * w, trnd() * h, 1 + trnd() * 2, 1 + trnd() * 2); }
}
export const TEX = {};
TEX.concrete = mkTex(128, 128, (g, w, h) => { g.fillStyle = '#bcbcb7'; g.fillRect(0, 0, w, h); speckle(g, w, h, 1400, .25, 90, 235); g.strokeStyle = 'rgba(70,70,70,.35)'; g.lineWidth = 2; g.strokeRect(0, 0, w, h); });
TEX.roof = mkTex(128, 128, (g, w, h) => { g.fillStyle = '#6d7075'; g.fillRect(0, 0, w, h); speckle(g, w, h, 2800, .35, 60, 175); g.strokeStyle = 'rgba(30,30,30,.25)'; g.lineWidth = 2; g.strokeRect(0, 0, w, h); });
function facadeDraw(night, emit) {
  return (g, w, h) => {
    g.fillStyle = emit ? '#000' : night ? '#1a1f33' : '#d9dde1'; g.fillRect(0, 0, w, h);
    const tones = [['#7db4de', '#4f88b8'], ['#8cc0e6', '#5b93c3'], ['#6aa3d0', '#3f77a6'], ['#9ccbea', '#6aa0cb']];
    const lit = ['#ffd27a', '#7be8ff', '#ff7ad9', '#fff2b0', '#9bff9b'];
    const cs = 64;
    for (let j = 0; j < 4; j++) for (let i = 0; i < 4; i++) {
      const x = i * cs, y = j * cs;
      if (night) {
        if (!emit) { g.fillStyle = '#10131f'; g.fillRect(x + 6, y + 6, cs - 12, cs - 24); }
        const on = trnd() < 0.5;
        if (emit) { if (on) { g.fillStyle = lit[(trnd() * lit.length) | 0]; g.fillRect(x + 9, y + 9, cs - 18, cs - 30); } }
        else { g.fillStyle = on ? '#2a2f44' : '#171b2b'; g.fillRect(x + 9, y + 9, cs - 18, cs - 30); g.fillStyle = '#2b3148'; g.fillRect(x, y + cs - 12, cs, 12); }
        continue;
      }
      g.fillStyle = '#b4bac1'; g.fillRect(x, y + cs - 12, cs, 12);
      g.fillStyle = '#46505b'; g.fillRect(x + 6, y + 6, cs - 12, cs - 24);
      const t = tones[(trnd() * 4) | 0]; const gr = g.createLinearGradient(x, y + 8, x, y + cs - 20);
      gr.addColorStop(0, t[0]); gr.addColorStop(1, t[1]); g.fillStyle = gr; g.fillRect(x + 9, y + 9, cs - 18, cs - 30);
      g.fillStyle = 'rgba(255,255,255,.2)'; g.beginPath(); g.moveTo(x + 9, y + cs - 21); g.lineTo(x + 9 + (cs - 18) * .55, y + 9); g.lineTo(x + 9 + (cs - 18) * .8, y + 9); g.lineTo(x + 9 + (cs - 18) * .25, y + cs - 21); g.fill();
      g.fillStyle = '#46505b'; g.fillRect(x + cs / 2 - 1.5, y + 9, 3, cs - 30);
    }
    if (!emit && !night) speckle(g, w, h, 500, .12, 80, 200);
  };
}
TEX.facade = mkTex(256, 256, facadeDraw(false, false));
TEX.nfacade = mkTex(256, 256, facadeDraw(true, false));
TEX.nfacadeE = mkTex(256, 256, facadeDraw(true, true));
TEX.brick = mkTex(128, 128, (g, w, h) => {
  g.fillStyle = '#cdbfae'; g.fillRect(0, 0, w, h);
  for (let r = 0; r < 16; r++) for (let c = -1; c < 5; c++) {
    const off = (r % 2) * 16, x = c * 32 + off, y = r * 8; const v = (trnd() * 26) | 0;
    g.fillStyle = 'rgb(' + (150 + v) + ',' + (78 + v / 2) + ',' + (56 + v / 2) + ')'; g.fillRect(x + 1, y + 1, 30, 6);
  }
  speckle(g, w, h, 500, .15, 60, 200);
});
TEX.metal = mkTex(128, 128, (g, w, h) => {
  g.fillStyle = '#8c97a1'; g.fillRect(0, 0, w, h);
  for (let i = 0; i < 90; i++) { g.fillStyle = 'rgba(' + (trnd() < .5 ? '255,255,255' : '0,0,0') + ',.06)'; g.fillRect(trnd() * w, 0, 1 + trnd() * 2, h); }
  g.strokeStyle = 'rgba(40,50,60,.5)'; g.lineWidth = 3; g.strokeRect(0, 0, w, h);
  g.fillStyle = 'rgba(40,50,60,.5)'; g.fillRect(0, h / 2 - 1, w, 2);
});
TEX.beam = mkTex(128, 128, (g, w, h) => {
  g.fillStyle = '#e0a020'; g.fillRect(0, 0, w, h);
  g.fillStyle = 'rgba(0,0,0,.18)'; g.fillRect(0, 0, w, 10); g.fillRect(0, h - 10, w, 10);
  g.fillStyle = '#7a4d08'; for (let i = 0; i < 4; i++) { g.beginPath(); g.arc(16 + i * 32, 64, 4, 0, TAU); g.fill(); }
  g.strokeStyle = 'rgba(0,0,0,.35)'; g.lineWidth = 4; g.strokeRect(0, 0, w, h);
  speckle(g, w, h, 300, .15, 60, 220);
});
TEX.crate = mkTex(128, 128, (g, w, h) => {
  g.fillStyle = '#c58b4e'; g.fillRect(0, 0, w, h);
  for (let i = 0; i < 6; i++) { g.fillStyle = 'rgba(' + (trnd() < .5 ? '0,0,0' : '255,220,170') + ',.12)'; g.fillRect(0, i * 21, w, 20); }
  g.strokeStyle = '#7b4c22'; g.lineWidth = 9; g.strokeRect(5, 5, w - 10, h - 10);
  g.lineWidth = 7; g.beginPath(); g.moveTo(8, 8); g.lineTo(w - 8, h - 8); g.moveTo(w - 8, 8); g.lineTo(8, h - 8); g.stroke();
});
TEX.mover = mkTex(128, 128, (g, w, h) => {
  g.fillStyle = '#1aa0c4'; g.fillRect(0, 0, w, h);
  g.fillStyle = 'rgba(255,255,255,.22)'; for (let i = -4; i < 10; i++) { g.beginPath(); g.moveTo(i * 24, 0); g.lineTo(i * 24 + 12, 0); g.lineTo(i * 24 + 12 + h, h); g.lineTo(i * 24 + h, h); g.fill(); }
  g.strokeStyle = '#e8fbff'; g.lineWidth = 12; g.strokeRect(0, 0, w, h);
});
TEX.surf = mkTex(128, 128, (g, w, h) => {
  g.fillStyle = '#e9eff6'; g.fillRect(0, 0, w, h);
  g.fillStyle = 'rgba(0,0,0,.10)'; for (let i = 0; i < 4; i++) g.fillRect(0, i * 32 + 14, w, 4);
  g.strokeStyle = 'rgba(0,0,0,.22)'; g.lineWidth = 3; g.beginPath(); g.moveTo(64, 0); g.lineTo(64, h); g.stroke();
  g.fillStyle = 'rgba(255,255,255,.7)'; g.beginPath(); g.moveTo(64, 10); g.lineTo(84, 40); g.lineTo(44, 40); g.fill();
  g.strokeStyle = 'rgba(0,0,0,.3)'; g.lineWidth = 4; g.strokeRect(0, 0, w, h);
});
TEX.rust = mkTex(128, 128, (g, w, h) => {
  g.fillStyle = '#8a6046'; g.fillRect(0, 0, w, h); speckle(g, w, h, 1800, .35, 50, 200);
  for (let i = 0; i < 18; i++) { g.fillStyle = 'rgba(70,35,15,' + (0.08 + trnd() * .12) + ')'; g.fillRect(trnd() * w, 0, 2 + trnd() * 6, h); }
  g.strokeStyle = 'rgba(30,20,15,.5)'; g.lineWidth = 3; g.strokeRect(0, 0, w, h);
  g.fillStyle = 'rgba(30,20,15,.4)'; for (let i = 0; i < 4; i++) { g.beginPath(); g.arc(12 + i * 34, 12, 3, 0, TAU); g.fill(); g.beginPath(); g.arc(12 + i * 34, h - 12, 3, 0, TAU); g.fill(); }
});
TEX.container = mkTex(128, 128, (g, w, h) => {
  g.fillStyle = '#d4d4d4'; g.fillRect(0, 0, w, h);
  for (let x = 0; x < w; x += 8) { g.fillStyle = 'rgba(0,0,0,.2)'; g.fillRect(x, 0, 3, h); g.fillStyle = 'rgba(255,255,255,.25)'; g.fillRect(x + 3, 0, 2, h); }
  g.fillStyle = 'rgba(0,0,0,.35)'; g.fillRect(0, 0, w, 6); g.fillRect(0, h - 6, w, 6);
  speckle(g, w, h, 500, .2, 40, 200);
});
TEX.grate = mkTex(128, 128, (g, w, h) => {
  g.fillStyle = '#3d4247'; g.fillRect(0, 0, w, h);
  g.strokeStyle = '#8b939b'; g.lineWidth = 3;
  for (let i = 0; i <= 8; i++) { g.beginPath(); g.moveTo(i * 16, 0); g.lineTo(i * 16, h); g.moveTo(0, i * 16); g.lineTo(w, i * 16); g.stroke(); }
  speckle(g, w, h, 300, .2, 20, 120);
});
TEX.cloudp = mkTex(128, 128, (g, w, h) => {
  g.fillStyle = '#f1f5fa'; g.fillRect(0, 0, w, h); speckle(g, w, h, 900, .14, 170, 250);
  g.strokeStyle = 'rgba(120,150,190,.35)'; g.lineWidth = 2; g.strokeRect(1, 1, w - 2, h - 2);
  g.strokeStyle = 'rgba(150,175,210,.25)'; g.beginPath(); g.moveTo(10, 20); g.lineTo(50, 60); g.lineTo(40, 100); g.stroke();
});
TEX.rock = mkTex(128, 128, (g, w, h) => {
  g.fillStyle = '#8f8778'; g.fillRect(0, 0, w, h); speckle(g, w, h, 2400, .4, 60, 190);
  for (let i = 0; i < 14; i++) { g.fillStyle = 'rgba(40,35,30,.12)'; g.fillRect(0, trnd() * h, w, 2 + trnd() * 5); }
});
TEX.wood = mkTex(128, 128, (g, w, h) => {
  g.fillStyle = '#c99d66'; g.fillRect(0, 0, w, h);
  for (let i = 0; i < 4; i++) { g.fillStyle = 'rgba(' + (i % 2 ? '60,35,10' : '255,225,170') + ',.16)'; g.fillRect(0, i * 32, w, 31); g.fillStyle = 'rgba(60,35,10,.55)'; g.fillRect(0, i * 32, w, 2); }
  speckle(g, w, h, 600, .18, 60, 190);
  g.fillStyle = '#5d3d1b'; for (let i = 0; i < 4; i++) { g.fillRect(6, i * 32 + 14, 3, 3); g.fillRect(w - 9, i * 32 + 14, 3, 3); }
});
TEX.hazard = mkTex(128, 128, (g, w, h) => {
  g.fillStyle = '#f2c200'; g.fillRect(0, 0, w, h); g.fillStyle = '#1b1b1b';
  for (let i = -6; i < 12; i++) { g.beginPath(); g.moveTo(i * 24, 0); g.lineTo(i * 24 + 12, 0); g.lineTo(i * 24 + 12 + h, h); g.lineTo(i * 24 + h, h); g.fill(); }
  speckle(g, w, h, 300, .15, 60, 200);
});
export const TILE = { concrete: 4, roof: 6, facade: 8, brick: 3, metal: 2, beam: 2, crate: 1.2, mover: 4, plain: 4, surf: 4, rust: 3, container: 3, grate: 2, nfacade: 8, cloudp: 4, rock: 5, wood: 2, hazard: 2, neon: 4 };
export const MAT = {};
Object.keys(TILE).forEach(k => {
  if (k === 'neon') MAT[k] = new THREE.MeshBasicMaterial({ vertexColors: true });
  else if (k === 'nfacade') MAT[k] = new THREE.MeshLambertMaterial({ map: TEX.nfacade, emissiveMap: TEX.nfacadeE, emissive: 0xffffff, vertexColors: true });
  else MAT[k] = new THREE.MeshLambertMaterial({ map: TEX[k] || null, vertexColors: true });
});
const SHARED_MAT = new Set(Object.values(MAT)), SHARED_TEX = new Set(Object.values(TEX));

/* ---------- мир ---------- */
export const W = {
  group: null, cloudGroup: null, FINISH: null, START: { x: 0, y: 20, z: 3 }, cur: { x: 0, y: 20, zEdge: -8 },
  end: 0, groundY: -70, killDrop: 26, id: '', platform: null, padFn: null, anim: []
};
export const batches = {};
const getB = (st, k) => st[k] || (st[k] = { pos: [], nor: [], uv: [], col: [], idx: [], n: 0 });
const _c = new THREE.Color();
const cc = hex => { _c.set(hex); return [_c.r, _c.g, _c.b]; };
export const add = o => { W.group.add(o); return o; };

function disposeTree(o) {
  o.traverse(n => {
    if (n.geometry) n.geometry.dispose();
    const ms = n.material ? (Array.isArray(n.material) ? n.material : [n.material]) : [];
    ms.forEach(m => { if (SHARED_MAT.has(m)) return; if (m.map && !SHARED_TEX.has(m.map) && !m.map.isShared) m.map.dispose(); m.dispose(); });
  });
}
export function resetWorld() {
  if (W.group) { scene.remove(W.group); disposeTree(W.group); }
  W.group = new THREE.Group(); scene.add(W.group);
  clearColliders(); Object.keys(batches).forEach(k => delete batches[k]);
  W.FINISH = null; W.cloudGroup = null; W.platform = null; W.padFn = null; W.anim = []; W.killDrop = 26; W.groundY = -70;
}

function pushQuad(b, p0, p1, p2, p3, nx, ny, nz, mode, tile, col) {
  const base = b.n, ps = [p0, p1, p2, p3];
  for (let i = 0; i < 4; i++) {
    const p = ps[i];
    b.pos.push(p[0], p[1], p[2]); b.nor.push(nx, ny, nz);
    const u = mode === 1 ? p[2] : p[0], v = mode === 0 ? p[2] : p[1];
    b.uv.push(u / tile, v / tile); b.col.push(col[0], col[1], col[2]);
  }
  b.idx.push(base, base + 1, base + 2, base, base + 2, base + 3); b.n += 4;
}
export function box(x0, y0, z0, x1, y1, z1, side, top, tint, st, bottom) {
  st = st || batches; tint = tint === undefined ? 0xffffff : tint;
  const col = cc(tint), bs = getB(st, side), bt = getB(st, top), ts = TILE[side], tt = TILE[top];
  pushQuad(bt, [x0, y1, z1], [x1, y1, z1], [x1, y1, z0], [x0, y1, z0], 0, 1, 0, 0, tt, col);
  pushQuad(bs, [x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1], 0, 0, 1, 2, ts, col);
  pushQuad(bs, [x1, y0, z0], [x0, y0, z0], [x0, y1, z0], [x1, y1, z0], 0, 0, -1, 2, ts, col);
  pushQuad(bs, [x1, y0, z1], [x1, y0, z0], [x1, y1, z0], [x1, y1, z1], 1, 0, 0, 1, ts, col);
  pushQuad(bs, [x0, y0, z0], [x0, y0, z1], [x0, y1, z1], [x0, y1, z0], -1, 0, 0, 1, ts, col);
  if (bottom) pushQuad(bs, [x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1], 0, -1, 0, 0, ts, col);
}
export function addGeo(key, geo, tint) {
  const b = getB(batches, key), p = geo.attributes.position, n = geo.attributes.normal, u = geo.attributes.uv, col = cc(tint === undefined ? 0xffffff : tint), base = b.n;
  for (let i = 0; i < p.count; i++) { b.pos.push(p.getX(i), p.getY(i), p.getZ(i)); b.nor.push(n.getX(i), n.getY(i), n.getZ(i)); b.uv.push(u.getX(i), u.getY(i)); b.col.push(col[0], col[1], col[2]); }
  const ix = geo.index; for (let i = 0; i < ix.count; i++) b.idx.push(base + ix.getX(i));
  b.n += p.count; geo.dispose();
}
export function cyl(key, tint, cx, cy, cz, rt, rb, h, axis, seg) {
  const g = new THREE.CylinderGeometry(rt, rb, h, seg || 10, 1);
  if (axis === 'x') g.rotateZ(Math.PI / 2); else if (axis === 'z') g.rotateX(Math.PI / 2);
  g.translate(cx, cy, cz); addGeo(key, g, tint);
}
export function geoFromBatch(b) {
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(b.pos, 3));
  g.setAttribute('normal', new THREE.Float32BufferAttribute(b.nor, 3));
  g.setAttribute('uv', new THREE.Float32BufferAttribute(b.uv, 2));
  g.setAttribute('color', new THREE.Float32BufferAttribute(b.col, 3));
  g.setIndex(b.n > 65535 ? new THREE.Uint32BufferAttribute(b.idx, 1) : new THREE.Uint16BufferAttribute(b.idx, 1));
  g.computeBoundingSphere(); return g;
}
export function buildBatches() {
  Object.keys(batches).forEach(k => {
    const m = new THREE.Mesh(geoFromBatch(batches[k]), MAT[k]);
    const neon = k === 'neon';
    m.castShadow = !neon; m.receiveShadow = !neon; W.group.add(m);
    delete batches[k];
  });
}
export function solid(x0, y0, z0, x1, y1, z1, key, tint, top) { box(x0, y0, z0, x1, y1, z1, key, top || key, tint); return addCol(x0, y0, z0, x1, y1, z1); }

// Наклонная плита (OBB): визуал + коллайдер для серфа/рамп. Поворот Euler 'YXZ' (rx=pitch, ry=yaw, rz=roll)
const _m4 = new THREE.Matrix4(), _e = new THREE.Euler(), _q = new THREE.Quaternion(), _v = new THREE.Vector3(), _s1 = new THREE.Vector3(1, 1, 1);
export function obb(cx, cy, cz, hx, hy, hz, rx, ry, rz, key, tint, collide) {
  _e.set(rx, ry, rz, 'YXZ'); _q.setFromEuler(_e); _m4.compose(_v.set(cx, cy, cz), _q, _s1);
  const g = new THREE.BoxGeometry(hx * 2, hy * 2, hz * 2), uv = g.attributes.uv, t = TILE[key];
  const dims = [[hz * 2, hy * 2], [hz * 2, hy * 2], [hx * 2, hz * 2], [hx * 2, hz * 2], [hx * 2, hy * 2], [hx * 2, hy * 2]];
  for (let f = 0; f < 6; f++) for (let i = 0; i < 4; i++) { const k = f * 4 + i; uv.setXY(k, uv.getX(k) * dims[f][0] / t, uv.getY(k) * dims[f][1] / t); }
  g.applyMatrix4(_m4); addGeo(key, g, tint);
  return collide === false ? null : addObb(cx, cy, cz, hx, hy, hz, _m4.elements);
}

/* ---------- декор / пропсы ---------- */
export function crate(x, y, z, s, tint) { s = s || 1.1; solid(x - s / 2, y, z - s / 2, x + s / 2, y + s, z + s / 2, 'crate', tint); }
export function ac(x, y, z) {
  solid(x - .9, y, z - .7, x + .9, y + 1.2, z + .7, 'metal', 0xdfe5ea);
  cyl('plain', 0x2d3338, x - .4, y + 1.22, z, .38, .38, .06, 'y', 10);
  cyl('plain', 0x2d3338, x + .4, y + 1.22, z, .38, .38, .06, 'y', 10);
}
export function vent(x, y, z) {
  cyl('metal', 0xc9ced3, x, y + .6, z, .28, .28, 1.2, 'y', 8);
  cyl('metal', 0x9aa2a9, x, y + 1.28, z, .5, .1, .2, 'y', 8);
  addCol(x - .3, y, z - .3, x + .3, y + 1.3, z + .3);
}
export function tank(x, y, z) {
  [[-.8, -.8], [.8, -.8], [-.8, .8], [.8, .8]].forEach(l => box(x + l[0] - .08, y, z + l[1] - .08, x + l[0] + .08, y + 1.6, z + l[1] + .08, 'metal', 'metal', 0x6b4a32));
  cyl('plain', 0x8a6a4a, x, y + 2.6, z, 1.1, 1.1, 2.0, 'y', 12);
  cyl('plain', 0x4f4034, x, y + 3.9, z, 0.02, 1.18, .6, 'y', 12);
  addCol(x - 1.1, y, z - 1.1, x + 1.1, y + 3.6, z + 1.1);
}
export function antenna(x, y, z, h) { cyl('metal', 0x555b60, x, y + h / 2, z, .05, .08, h, 'y', 5); box(x - .3, y, z - .3, x + .3, y + .3, z + .3, 'concrete', 'concrete'); }
export function skylight(x, y, z, w, d) { solid(x - w / 2, y, z - d / 2, x + w / 2, y + .45, z + d / 2, 'plain', 0x86c5ea); }
export function shed(x, y, z, w, d, h) {
  solid(x - w / 2, y, z - d / 2, x + w / 2, y + h, z + d / 2, 'brick', 0xffffff, 'concrete');
  box(x - .6, y, z + d / 2, x + .6, y + 2, z + d / 2 + .06, 'plain', 'plain', 0x2b3138);
}
let billMatShared = null;
function getBillMat() {
  if (billMatShared) return billMatShared;
  const c = document.createElement('canvas'); c.width = 512; c.height = 256; const g = c.getContext('2d');
  const gr = g.createLinearGradient(0, 0, 512, 256); gr.addColorStop(0, '#ff8a3c'); gr.addColorStop(1, '#ff3c6a');
  g.fillStyle = gr; g.fillRect(0, 0, 512, 256); g.fillStyle = 'rgba(255,255,255,.12)'; g.fillRect(0, 170, 512, 86);
  g.fillStyle = '#fff'; g.font = 'italic 900 92px Arial'; g.textAlign = 'center'; g.fillText('PARKOUR', 256, 118);
  g.font = 'italic 900 70px Arial'; g.fillStyle = '#ffe3a0'; g.fillText('3D', 256, 200);
  g.strokeStyle = '#fff'; g.lineWidth = 8; g.strokeRect(4, 4, 504, 248);
  const t = new THREE.CanvasTexture(c); t.isShared = true;
  billMatShared = new THREE.MeshBasicMaterial({ map: t, side: THREE.DoubleSide }); SHARED_MAT.add(billMatShared);
  return billMatShared;
}
export function billboard(x, y, z, w, h) {
  box(x - w / 2 + .4, y, z - .12, x - w / 2 + .6, y + 4.4 + h, z + .12, 'metal', 'metal', 0x444b52);
  box(x + w / 2 - .6, y, z - .12, x + w / 2 - .4, y + 4.4 + h, z + .12, 'metal', 'metal', 0x444b52);
  addCol(x - w / 2 + .4, y, z - .12, x - w / 2 + .6, y + 4.4, z + .12);
  addCol(x + w / 2 - .6, y, z - .12, x + w / 2 - .4, y + 4.4, z + .12);
  const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), getBillMat()); m.position.set(x, y + 4.6 + h / 2, z + .14); add(m);
}
// Неоновая вывеска с текстом (визуал)
export function sign(x, y, z, w, h, text, color, rotY) {
  const c = document.createElement('canvas'); c.width = 512; c.height = Math.round(512 * h / w); const g = c.getContext('2d');
  g.fillStyle = 'rgba(6,8,22,.88)'; g.fillRect(0, 0, c.width, c.height);
  g.strokeStyle = color; g.lineWidth = 10; g.shadowColor = color; g.shadowBlur = 18; g.strokeRect(10, 10, c.width - 20, c.height - 20);
  g.fillStyle = color; g.font = '900 ' + Math.round(c.height * 0.46) + 'px Arial'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(text, c.width / 2, c.height / 2 + 4);
  const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ map: new THREE.CanvasTexture(c), side: THREE.DoubleSide, fog: true }));
  m.position.set(x, y, z); m.rotation.y = rotY || 0; add(m); return m;
}

/* ---------- подвижные платформы ---------- */
export function mover(ax, ay, az, w, d, bx, by, bz, period, phase, tint) {
  const st = {}; box(-w / 2, -.6, -d / 2, w / 2, 0, d / 2, 'mover', 'mover', tint === undefined ? 0xffffff : tint, st, true);
  const mesh = new THREE.Mesh(geoFromBatch(st.mover), MAT.mover); mesh.castShadow = true; mesh.receiveShadow = true; add(mesh);
  return makeMoverData(ax, ay, az, w, d, bx, by, bz, period, phase, mesh);
}

/* ---------- чекпоинты / финиш ---------- */
export function cp(r, zOff, xOff) {
  const x = r.x + (xOff || 0), y = r.y, z = r.z + (zOff || 0), idx = CPS.length + 1;
  const bm = new THREE.MeshBasicMaterial({ color: 0x35d0ff, transparent: true, opacity: .26, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide });
  const rm = new THREE.MeshBasicMaterial({ color: 0x35d0ff, transparent: true, opacity: .85, side: THREE.DoubleSide });
  const beamM = new THREE.Mesh(new THREE.CylinderGeometry(1.5, 1.5, 7, 18, 1, true), bm); beamM.position.set(x, y + 3.5, z); add(beamM);
  const ring = new THREE.Mesh(new THREE.RingGeometry(1.0, 1.6, 28), rm); ring.rotation.x = -Math.PI / 2; ring.position.set(x, y + .04, z); add(ring);
  box(x - 1.95, y, z - .1, x - 1.75, y + 3.4, z + .1, 'plain', 'plain', 0x2f3943); box(x + 1.75, y, z - .1, x + 1.95, y + 3.4, z + .1, 'plain', 'plain', 0x2f3943);
  box(x - 1.95, y + 3.2, z - .1, x + 1.95, y + 3.5, z + .1, 'plain', 'plain', 0x2f3943);
  CPS.push({ x, y, z, bm, rm, beamM, ring, idx });
}
export function buildFinish(r) {
  const x = r.x, y = r.y, z = r.z;
  const gm = new THREE.MeshBasicMaterial({ color: 0xffd34a, transparent: true, opacity: .3, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide });
  const b = new THREE.Mesh(new THREE.CylinderGeometry(3.2, 3.2, 16, 22, 1, true), gm); b.position.set(x, y + 8, z); add(b);
  const ring = new THREE.Mesh(new THREE.RingGeometry(3.2, 4.4, 40), new THREE.MeshBasicMaterial({ color: 0xffd34a, side: THREE.DoubleSide })); ring.rotation.x = -Math.PI / 2; ring.position.set(x, y + .05, z); add(ring);
  const zz = z - 5;
  box(x - 5.2, y, zz - .25, x - 4.7, y + 6, zz + .25, 'plain', 'plain', 0x2f3943); box(x + 4.7, y, zz - .25, x + 5.2, y + 6, zz + .25, 'plain', 'plain', 0x2f3943);
  const c = document.createElement('canvas'); c.width = 512; c.height = 128; const g = c.getContext('2d');
  for (let i = 0; i < 32; i++) for (let j = 0; j < 8; j++) { g.fillStyle = (i + j) % 2 ? '#fff' : '#111'; g.fillRect(i * 16, j * 16, 16, 16); }
  g.fillStyle = 'rgba(0,0,0,.55)'; g.fillRect(100, 30, 312, 68); g.fillStyle = '#ffd34a'; g.font = 'italic 900 64px Arial'; g.textAlign = 'center'; g.fillText('FINISH', 256, 85);
  const ban = new THREE.Mesh(new THREE.PlaneGeometry(10.4, 2.6), new THREE.MeshBasicMaterial({ map: new THREE.CanvasTexture(c), side: THREE.DoubleSide }));
  ban.position.set(x, y + 5.7, zz); add(ban);
  W.FINISH = { x, y, z, ring, beamM: b, col: r.col };
}

/* ---------- земля, облака ---------- */
export function makeGround(y, color, tex) {
  const mat = new THREE.MeshLambertMaterial({ color });
  if (tex) { const gt = TEX.roof.clone(); gt.repeat.set(400, 400); gt.needsUpdate = true; mat.map = gt; }
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(3000, 3000), mat);
  ground.rotation.x = -Math.PI / 2; ground.position.set(0, y - 0.2, W.end / 2); add(ground);
}
export function makeClouds(n, yLo, yHi, opacity, scale) {
  const g = new THREE.Group(); add(g); W.cloudGroup = g;
  const ct = radialTex(128, [[0, 'rgba(255,255,255,.95)'], [.5, 'rgba(255,255,255,.55)'], [1, 'rgba(255,255,255,0)']]); ct.isShared = false;
  const cm = new THREE.SpriteMaterial({ map: ct, transparent: true, depthWrite: false, fog: false, opacity: opacity === undefined ? .8 : opacity });
  for (let i = 0; i < n; i++) {
    const s = new THREE.Sprite(cm); const w = (110 + rnd() * 120) * (scale || 1); s.scale.set(w, w * (.28 + rnd() * .15), 1);
    s.position.set((rnd() - .5) * 700, yLo + rnd() * (yHi - yLo), 100 - rnd() * (200 - W.end + 200)); g.add(s);
  }
  g.visible = (QP[S.quality] || QP[1]).clouds;
}
export function skyline(o) {
  // o: {side, top, tints, far, near, hMax, rows}
  const tints = o.tints || [0xffffff], by = W.groundY;
  const pick = () => tints[(rnd() * tints.length) | 0];
  for (let z = 90; z > W.end - 180; z -= (o.step || 16) + rnd() * 20) {
    [-1, 1].forEach(side => {
      { const x = side * ((o.near || 31) + rnd() * 8), w = 9 + rnd() * 6, d = 12 + rnd() * 10, top = (o.nearMin || 4) + rnd() * (o.nearH || 34); box(x - w / 2, by, z - d / 2, x + w / 2, top + (o.lift || 0), z + d / 2, o.side, o.top, pick()); }
      for (let row = 0; row < 3; row++) {
        const x = side * (48 + row * 44 + rnd() * 22), w = 16 + rnd() * 22, d = 16 + rnd() * 22, top = 5 + Math.pow(rnd(), 1.8) * (row === 0 ? (o.hMax || 90) : (o.hMax || 90) * 1.2), zo = z + rnd() * 12;
        box(x - w / 2, by, zo - d / 2, x + w / 2, top + (o.lift || 0), zo + d / 2, o.side, o.top, pick());
        if (o.neon && rnd() < 0.35) { const c = o.neon[(rnd() * o.neon.length) | 0], y1 = top + (o.lift || 0); box(x - w / 2 - .1, y1 - 1.2, zo + d / 2 - .1, x + w / 2 + .1, y1, zo + d / 2 + .1, 'neon', 'neon', c); }
      }
    });
  }
}
