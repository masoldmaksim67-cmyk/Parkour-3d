import { S } from './state.js';
const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);

export const AU = {
  ctx: null, master: null, windG: null, windF: null, nb: null,
  init() {
    if (this.ctx) { if (this.ctx.state === 'suspended') this.ctx.resume(); return; }
    const C = window.AudioContext || window.webkitAudioContext; if (!C) return;
    try {
      const c = (this.ctx = new C()); this.master = c.createGain(); this.master.gain.value = S.volume; this.master.connect(c.destination);
      const len = c.sampleRate * 2, buf = c.createBuffer(1, len, c.sampleRate), d = buf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
      this.nb = buf;
      const src = c.createBufferSource(); src.buffer = buf; src.loop = true;
      const f = (this.windF = c.createBiquadFilter()); f.type = 'lowpass'; f.frequency.value = 500;
      const g = (this.windG = c.createGain()); g.gain.value = 0; src.connect(f); f.connect(g); g.connect(this.master); src.start();
    } catch (e) { this.ctx = null; }
  },
  setVol(v) { if (this.master) this.master.gain.value = v; },
  tone(f, d, type, v, f2) {
    if (!this.ctx) return; const c = this.ctx, t = c.currentTime, o = c.createOscillator(), g = c.createGain();
    o.type = type || 'sine'; o.frequency.setValueAtTime(f, t); if (f2) o.frequency.exponentialRampToValueAtTime(f2, t + d);
    g.gain.setValueAtTime(v, t); g.gain.exponentialRampToValueAtTime(0.0001, t + d); o.connect(g); g.connect(this.master); o.start(t); o.stop(t + d + 0.03);
  },
  noise(d, v, freq, hp) {
    if (!this.ctx) return; const c = this.ctx, t = c.currentTime, s = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
    s.buffer = this.nb; f.type = hp ? 'highpass' : 'lowpass'; f.frequency.value = freq; g.gain.setValueAtTime(v, t); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
    s.connect(f); f.connect(g); g.connect(this.master); s.start(t, Math.random()); s.stop(t + d + 0.03);
  },
  step() { this.noise(0.07, 0.1, 900); },
  jump() { this.tone(230, 0.16, 'sine', 0.1, 440); },
  land(i) { this.noise(0.18, Math.min(0.45, i * 0.028), 450); },
  slide() { this.noise(0.35, 0.12, 1800, true); },
  swing() { this.noise(0.22, 0.14, 2600, true); this.tone(900, 0.18, 'sine', 0.03, 300); },
  inspect() { this.tone(1400, 0.05, 'triangle', 0.03); },
  checkpoint() { this.tone(660, 0.2, 'triangle', 0.15); setTimeout(() => this.tone(990, 0.35, 'triangle', 0.15), 110); },
  fall() { this.tone(500, 0.7, 'sawtooth', 0.08, 70); },
  finish() { [523, 659, 784, 1047].forEach((f, i) => setTimeout(() => this.tone(f, 0.45, 'triangle', 0.16), i * 130)); },
  wind(speed, air) {
    if (!this.ctx || !this.windG) return; const t = this.ctx.currentTime;
    this.windG.gain.setTargetAtTime(0.015 + clamp(speed / 24, 0, 1) * 0.12 + (air ? 0.04 : 0), t, 0.15);
    this.windF.frequency.setTargetAtTime(350 + speed * 45, t, 0.2);
  }
};
export const buzz = p => { if (S.vibration && navigator.vibrate) { try { navigator.vibrate(p); } catch (e) { /* ignore */ } } };
