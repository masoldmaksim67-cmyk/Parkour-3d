// PARKOUR 3D — игра целиком живёт в src/game (Three.js + собственная физика).
// Модуль boot.js монтирует разметку меню/HUD, main.js запускает игровой цикл.
// @ts-ignore — игровые модули написаны на чистом JS
import "./game/main.js";

export default function App() {
  return null;
}
