import { addCol, addObb, clearColliders } from '../src/game/collision.js';
import { P, IN, K, gather, stepPhysics, resetPlayer } from '../src/game/physics.js';
import * as T from 'three';
let fails = 0; const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) fails++; };
const H = K.STEP;
function flat() { clearColliders(); addCol(-500, -5, -500, 500, 0, 500); resetPlayer(0, 0.01, 0, 0); }
function sim(t, fn) { const n = Math.round(t / H); for (let i = 0; i < n; i++) { fn && fn(i); gather(); stepPhysics(H); } }
const spd = () => Math.hypot(P.vx, P.vz);

// 1. обычный бег: разгон не мгновенный
flat(); IN.autoHop = false; IN.run = true; IN.jumpHeld = false;
let t10 = 0, tmax = 0;
for (let i = 0; i < 240; i++) { IN.x = 0; IN.y = 1; gather(); stepPhysics(H); if (!t10 && spd() >= 0.5 * K.RUN) t10 = i * H; if (!tmax && spd() >= 0.99 * K.RUN) tmax = i * H; }
console.log('  run: 50% at', t10.toFixed(2), 's, 99% at', tmax.toFixed(2), 's, final', spd().toFixed(2));
ok(tmax > 0.25 && spd() <= K.RUN + 0.01, 'бег: макс. скорость не мгновенная и не выше RUN (' + spd().toFixed(2) + ' м/с)');
const runMax = spd();

// бот bhop: в воздухе стрейф под оптимальным углом, чередуя стороны
function bhop(perfect, forwardOnly, hops) {
  flat(); IN.autoHop = true; IN.run = true; IN.jumpHeld = false; P.yaw = 0;
  sim(0.6, () => { IN.x = 0; IN.y = 1; }); IN.jumpHeld = true;
  let side = 1, lastAir = false, n = 0, speeds = [spd()];
  for (let i = 0; i < 120 * 40 && n < hops; i++) {
    const v = spd();
    if (P.onGround) { if (lastAir) { n++; speeds.push(v); side = -side; } lastAir = false; } else lastAir = true;
    if (forwardOnly) { IN.x = 0; IN.y = 1; }
    else if (!P.onGround) {
      IN.x = side; IN.y = 0;
      // повернуть камеру так, чтобы wishdir был под углом phi к вектору скорости
      const a = K.AIR_ACCEL * K.RUN * H, phi = perfect ? Math.acos(Math.max(-1, Math.min(1, (K.AIR_CAP - a) / Math.max(v, 1e-3)))) : Math.acos(Math.min(1, 0.2 / Math.max(v, 1)));
      const al = side * phi, c = Math.cos(al), sn = Math.sin(al), hx = P.vx / Math.max(v, 1e-6), hz = P.vz / Math.max(v, 1e-6);
      const wxd = hx * c - hz * sn, wzd = hx * sn + hz * c;
      P.yaw = Math.atan2(-side * wzd, side * wxd);
    } else { IN.x = 0; IN.y = 1; }
    gather(); stepPhysics(H);
  }
  return speeds;
}
const sp = bhop(true, false, 14); console.log('  bhop perfect: ', sp.map(v => v.toFixed(1)).join(' '));
ok(sp[sp.length - 1] > runMax * 1.8, 'bhop+strafe разгоняет игрока: ' + runMax.toFixed(1) + ' → ' + sp[sp.length - 1].toFixed(1) + ' м/с');
ok(sp.every(v => v <= K.HARD + 0.01), 'скорость не превышает жёсткий предел ' + K.HARD);
ok(sp[sp.length - 1] - sp[sp.length - 3] < 1.6, 'нет бесконечного ускорения (выход на плато)');
const sp2 = bhop(false, false, 14); console.log('  bhop sloppy:  ', sp2.map(v => v.toFixed(1)).join(' '));
ok(sp2[sp2.length - 1] < sp[sp.length - 1] && sp2[sp2.length - 1] >= runMax * 0.9, 'неточный стрейф даёт меньше, чем идеальный');
const sp3 = bhop(true, true, 10); console.log('  bhop fwd-only:', sp3.map(v => v.toFixed(1)).join(' '));
ok(sp3[sp3.length - 1] <= runMax * 1.05, 'прыжки без стрейфа (только W) скорость не увеличивают');

// сохранение скорости: правильный прыжок vs поздний
flat(); IN.autoHop = false; IN.run = true; P.vx = 0; P.vz = -12; P.y = 0; P.onGround = true;
sim(0.05, () => { IN.jumpHeld = false; });
let before = spd(); IN.jumpBuf = 0.13; sim(0.02, () => {}); 
ok(spd() > before * 0.99, 'своевременный прыжок на земле сохраняет скорость (' + before.toFixed(1) + '→' + spd().toFixed(1) + ')');
flat(); IN.autoHop = false; P.vx = 0; P.vz = -12; P.onGround = true; sim(0.3, () => { IN.x = 0; IN.y = 0; });
ok(spd() < 5, 'задержка на земле без прыжка гасит скорость трением (→' + spd().toFixed(1) + ')');

console.log(fails ? '\nFAILED ' + fails : '\nALL PASSED'); process.exit(fails ? 1 : 0);
