// Запускает РЕАЛЬНЫЕ построители карт в Node (WebGL/DOM заменены заглушками) и проверяет геометрию маршрутов.
import { build } from 'esbuild';
import fs from 'fs'; import path from 'path'; import { pathToFileURL } from 'url';
const root = path.resolve('.');
const shim = path.join(root, 'tests/three-shim.mjs');
fs.writeFileSync(shim, `export * from '${root}/node_modules/three/build/three.module.js';
const noop = () => {};
export class WebGLRenderer { constructor() { this.capabilities = { getMaxAnisotropy: () => 1, maxTextureSize: 4096 }; this.shadowMap = { enabled: false }; this.domElement = {}; this.info = {}; }
  setPixelRatio() {} setSize() {} setClearColor() {} render() {} clearDepth() {} getContext() { return {}; } }`);
const out = path.join(root, 'tests/.maps.bundle.mjs');
await build({ entryPoints: [path.join(root, 'tests/maps-entry.js')], bundle: true, format: 'esm', platform: 'node', outfile: out, logLevel: 'error',
  loader: { '.html': 'text', '.css': 'empty' },
  plugins: [{ name: 'x', setup(b) {
    b.onResolve({ filter: /\?raw$/ }, a => ({ path: path.resolve(a.resolveDir, a.path.replace('?raw', '')), namespace: 'file' }));
    b.onResolve({ filter: /^three$/ }, a => (a.importer.endsWith('three-shim.mjs') ? null : { path: shim }));
  } }] });
await import(pathToFileURL(out).href);
