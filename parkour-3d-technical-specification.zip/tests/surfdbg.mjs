import { addObb, clearColliders, RAMPS } from '../src/game/collision.js';
import { P, IN, K, gather, stepPhysics, resetPlayer } from '../src/game/physics.js';
import { troughSlabs } from '../src/game/surfgeo.js';
import * as T from 'three';
const H = 1/120; let fails = 0; const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) fails++; };
function add(s) { const m = new T.Matrix4().compose(new T.Vector3(s.cx, s.cy, s.cz), new T.Quaternion().setFromEuler(new T.Euler(s.rx, s.ry, s.rz, 'YXZ')), new T.Vector3(1,1,1)); addObb(s.cx, s.cy, s.cz, s.hx, s.hy, s.hz, m.elements); }
function buildCurve(yawStep, n, L, th, pitch) { clearColliders(); let p = [0, 60, 0], yaw = 0; const pts = [p.slice()];
  for (let i = 0; i < n; i++) { const t = troughSlabs(p[0], p[1], p[2], yaw, pitch, L, { th, w: 14 }); t.slabs.forEach(add); p = t.end; pts.push(p.slice()); yaw += yawStep; } return pts; }
function run(pts, label, steer, th, jumpAt) {
  resetPlayer(pts[0][0] + 2.5, pts[0][1] + 5, pts[0][2] - 2, 0); P.vz = -12; IN.run = true; IN.autoHop = false; IN.x = 0; IN.y = 0;
  let surfT = 0, maxV = 0, lastI = 0, alive = true;
  for (let i = 0; i < 120 * 14; i++) {
    // курсор камеры смотрит вдоль скорости; джойстик не нужен для удержания в жёлобе
    if (steer) P.yaw = Math.atan2(-P.vx, -P.vz);
    gather(); stepPhysics(H); if (P.surfT > 0) surfT += H; maxV = Math.max(maxV, Math.hypot(P.vx, P.vz));
    // ближайшая точка пути
    let bi = 0, bd = 1e9; pts.forEach((q, k) => { const d = Math.hypot(q[0] - P.x, q[2] - P.z); if (d < bd) { bd = d; bi = k; } }); lastI = Math.max(lastI, bi);
    if (bi < pts.length - 2 && P.y < pts[bi][1] - 12) { alive = false; break; } if (bi >= pts.length - 1) break;
  }
  console.log('  ' + label + ': прогресс сегмент', lastI, '/', pts.length - 1, 'surf', surfT.toFixed(1), 'c, vmax', maxV.toFixed(1), 'v', Math.hypot(P.vx,P.vz).toFixed(1), 'alive', alive);
  return { alive, lastI, surfT, maxV };
}
let pts = buildCurve(0, 10, 20, 55 * Math.PI / 180, -0.12);
ok(RAMPS.every(r => r.planes[2].ny < 0.6), 'нормаль рабочих плоскостей ny=' + RAMPS[0].planes[2].ny.toFixed(2) + ' < 0.7');
let r = run(pts, 'прямой жёлоб 55°', true); ok(r.alive && r.lastI >= 9 && r.surfT > 5, 'прямой жёлоб: игрок едет по рампам без проваливания и прилипания');
ok(r.maxV > 14, 'на спуске по рампе скорость растёт (до ' + r.maxV.toFixed(1) + ')');
pts = buildCurve(0.14, 14, 7, 55 * Math.PI / 180, -0.08); r = run(pts, 'изогнутый жёлоб (~110°)', true); ok(r.alive && r.lastI >= 12, 'изогнутый жёлоб: игрок проходит поворот (сегмент ' + r.lastI + ')');
pts = buildCurve(-0.1, 12, 8, 48 * Math.PI / 180, -0.1); r = run(pts, 'жёлоб 48° в другую сторону', true); ok(r.alive && r.lastI >= 10, 'поворот в обратную сторону');
// быстрый вход (туннелирование)
pts = buildCurve(0, 6, 20, 50 * Math.PI / 180, -0.1); resetPlayer(0, 70, 0, 0); P.vz = -25; P.vy = -30; IN.x = 0; let mn = 1e9; for (let i = 0; i < 120 * 3; i++) { gather(); stepPhysics(H); mn = Math.min(mn, P.y); }
ok(P.y > 40, 'падение на рампу на предельной скорости не проходит сквозь геометрию (y=' + P.y.toFixed(1) + ')');
// прыжок между отдельными жёлобами через промежуток
clearColliders(); let a = troughSlabs(0, 60, 0, 0, -0.12, 30, { th: 0.95, w: 14 }); a.slabs.forEach(add);
let b = troughSlabs(a.end[0], a.end[1] - 2.5, a.end[2] - 7, 0, -0.12, 30, { th: 0.95, w: 14 }); b.slabs.forEach(add);
resetPlayer(0, 61, 0, 0); P.vz = -18; P.vy = 0; IN.run = true; let land = false; 
for (let i = 0; i < 120 * 5; i++) { P.yaw = Math.atan2(-P.vx, -P.vz); gather(); stepPhysics(H); if (P.z < b.end[2] + 25 && P.y > b.end[1] - 2 && P.z < a.end[2] - 8) land = true; }
ok(land, 'переход между рампами с промежутком (z=' + P.z.toFixed(0) + ', y=' + P.y.toFixed(1) + ')');
// прыжок с рампы
resetPlayer(0, 61, 0, 0); P.vz = -14; IN.x = 0; let vy = -99, pj = 0; for (let i = 0; i < 120 * 3; i++) { gather(); if (i === 200) IN.jumpBuf = 0.13; stepPhysics(H); if (i > 200) vy = Math.max(vy, P.vy); }
ok(vy > 3.5, 'прыжок с рампы (vy ' + vy.toFixed(1) + ')');
console.log(fails ? 'FAILED ' + fails : 'ALL PASSED'); process.exit(fails ? 1 : 0);
