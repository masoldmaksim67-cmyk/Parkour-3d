const proxy = () => new Proxy(function () {}, { get: (t, k) => (k === 'width' || k === 'height' ? 64 : k === Symbol.toPrimitive ? () => 0 : proxy()), apply: () => proxy(), set: () => true });
const ctx = () => new Proxy({}, { get: (t, k) => (k === 'measureText' ? () => ({ width: 10 }) : k === 'createLinearGradient' || k === 'createRadialGradient' ? () => ({ addColorStop() {} }) : k === 'getImageData' ? () => ({ data: new Uint8ClampedArray(4) }) : () => {}), set: () => true });
const cv = () => ({ width: 64, height: 64, style: {}, getContext: ctx, addEventListener() {}, classList: { add() {}, remove() {}, toggle() {} } });
globalThis.window = globalThis; globalThis.devicePixelRatio = 1; globalThis.innerWidth = 800; globalThis.innerHeight = 400;
Object.defineProperty(globalThis, 'navigator', { value: { userAgent: 'node', maxTouchPoints: 0 }, configurable: true });
globalThis.screen = { width: 1000, height: 500 };
const store = {}; globalThis.localStorage = { getItem: k => (k in store ? store[k] : null), setItem: (k, v) => { store[k] = String(v); }, removeItem: k => { delete store[k]; } };
globalThis.document = { getElementById: id => (id === 'app' ? {} : cv()), createElement: () => cv(), body: { appendChild() {} }, addEventListener() {} };
globalThis.addEventListener = () => {};
const { MAPS, loadMap } = await import('../src/game/maps.js');
const { COL, RAMPS, CPS, PORTALS, MOV } = await import('../src/game/collision.js');
const { W } = await import('../src/game/core.js');
let bad = 0;
const { P, IN, gather, stepPhysics, resetPlayer, K } = await import('../src/game/physics.js');
async function surfBot(m) {
  // бот: бежит вперёд, камера смотрит по вектору скорости; на падении возрождается на последнем чекпоинте
  const st = W.START; let cpI = 0, falls = 0, vmax = 0, surf = 0, t = 0, fin = false; const H = 1 / 120;
  const spawn = () => { pi = 0; { let bd = 1e9; const p0 = cpI ? CPS[cpI - 1] : st; W.route.forEach((q, k) => { const d = Math.hypot(q.x - p0.x, q.z - p0.z); if (d < bd) { bd = d; pi = k; } }); }  const p = cpI ? CPS[cpI - 1] : st; resetPlayer(p.x, p.y + .02, p.z, -(p.yaw || 0) * Math.PI / 180); if (cpI) { P.yaw = cpHead[cpI - 1]; } IN.y = 1; IN.run = true; };
  const cpHead = []; resetPlayer(st.x, st.y + .02, st.z, 0); IN.run = true; IN.autoHop = true; IN.jumpHeld = false; IN.y = 1; IN.x = 0;
  let lastYaw = 0, pi = 0;
  for (let i = 0; i < 120 * 150 && !fin; i++) {
    const hs = Math.hypot(P.vx, P.vz); while (pi + 1 < W.route.length && Math.hypot(W.route[pi + 1].x - P.x, W.route[pi + 1].z - P.z) < 9 && Math.abs(W.route[pi + 1].y - P.y) < 14) pi++; if (P.onGround && P.ground && !P.ground.ramp && W.route.length) { while (pi + 1 < W.route.length && Math.hypot(W.route[pi + 1].x - P.x, W.route[pi + 1].z - P.z) < 9) pi++; const q = W.route[Math.min(pi + 1, W.route.length - 1)]; P.yaw = Math.atan2(-(q.x - P.x), -(q.z - P.z)); lastYaw = P.yaw; } else if (hs > 4) { P.yaw = Math.atan2(-P.vx, -P.vz); lastYaw = P.yaw; } if (i % (process.env.BOTLOG === '2' ? 12 : 600) === 0 && process.env.BOTLOG && (process.env.BOTLOG !== '2' || (t > 0 && t < 40 && i % 60 === 0))) console.log('  t', (i/120).toFixed(0), P.x.toFixed(0), P.y.toFixed(0), P.z.toFixed(0), 'v', hs.toFixed(1), 'vx', P.vx.toFixed(1), 'vy', P.vy.toFixed(1), 'gnd', P.onGround, 'surf', P.surfT > 0, 'yaw', P.yaw.toFixed(2));
    gather(); stepPhysics(H); t += H; vmax = Math.max(vmax, Math.hypot(P.vx, P.vz)); if (P.surfT > 0) surf += H;
    for (let k = cpI; k < CPS.length; k++) { const c = CPS[k]; if (Math.hypot(P.x - c.x, P.z - c.z) < 3 && Math.abs(P.y - c.y) < 2.6) { cpI = k + 1; cpHead[k] = lastYaw; } }
    const f = W.FINISH; if (P.onGround && f && Math.hypot(P.x - f.x, P.z - f.z) < 12 && Math.abs(P.y - f.y) < 1) fin = true; if (P.onGround && f && P.ground === f.col) fin = true;
    if (P.y < -300) { falls++; console.log('  FALL at', P.x.toFixed(0), P.y.toFixed(0), P.z.toFixed(0), 't', t.toFixed(1), 'v', hs.toFixed(1), 'vx', P.vx.toFixed(1), 'vy', P.vy.toFixed(1), 'gnd', P.onGround, 'surf', P.surfT > 0, 'yaw', P.yaw.toFixed(2)); if (falls > 6) break; spawn(); }
    if (P.y < (cpI ? CPS[cpI - 1].y : st.y) - 60) { falls++; console.log('  FALL at', P.x.toFixed(0), P.y.toFixed(0), P.z.toFixed(0), 't', t.toFixed(1), 'v', hs.toFixed(1), 'cp', cpI, 'vy', P.vy.toFixed(1)); if (falls > 6) break; spawn(); }
  }
  console.log('   finish', W.FINISH.x.toFixed(0), W.FINISH.y.toFixed(0), W.FINISH.z.toFixed(0), 'bot end: x', P.x.toFixed(1), 'y', P.y.toFixed(1), 'z', P.z.toFixed(1), 'cp', cpI, '/', CPS.length, 'v', Math.hypot(P.vx,P.vz).toFixed(1), 'gnd', P.onGround);
  return { fin, falls, vmax, surf, t };
}
const only = process.argv[2]; 
for (const m of MAPS) {
  void 0;
  if (only && m.id !== only) continue;
  const t0 = Date.now(); let err = null;
  try { loadMap(m.id); } catch (e) { err = e; }
  if (err) { console.log('FAIL', m.id, err.stack.split('\n').slice(0, 4).join(' | ')); bad++; continue; }
  const R = W.route, rep = []; if (process.env.DUMP === m.id) { R.forEach((q, k) => console.log(k, q.x.toFixed(1), q.y.toFixed(1), q.z.toFixed(1))); CPS.forEach(c => console.log('CP', c.x.toFixed(1), c.y.toFixed(1), c.z.toFixed(1))); }
  // зазоры между последовательными платформами основного маршрута (ближайшие края по осям)
  let maxGap = 0, worst = null;
  const gapOf = (a, b) => { if (a.w === undefined || b.w === undefined) return null; const gx = Math.max(0, Math.abs(a.x - b.x) - (a.w + b.w) / 2), gz = Math.max(0, Math.abs(a.z - b.z) - (a.d + b.d) / 2); return Math.hypot(gx, gz); };
  // платформы берём из коллайдеров верхних граней: у turtle в route только центры, поэтому оцениваем по COL
  const tops = COL.filter(c => c.maxX - c.minX < 70 && c.maxZ - c.minZ < 70).map(c => ({ x: (c.minX + c.maxX) / 2, y: c.maxY, z: (c.minZ + c.maxZ) / 2, w: c.maxX - c.minX, d: c.maxZ - c.minZ }));
  const hasFinish = !!W.FINISH, cps = CPS.length;
  // достижимость: от старта до финиша по графу платформ (ребро, если горизонтальный зазор ≤ G и подъём ≤ 1.5, спуск любой при G+...)
  const lim = m.cat === 'bhop' ? 9.6 : m.cat === 'surf' ? 30 : 5.0;
  const nodes = tops.concat(RAMPS.map(r => ({ x: (r.minX + r.maxX) / 2, y: r.maxY, z: (r.minZ + r.maxZ) / 2, w: r.maxX - r.minX, d: r.maxZ - r.minZ, ramp: true })));
  const movers = []; MOV.forEach(mv => { movers.push({ x: mv.ax, y: mv.ay, z: mv.az, w: mv.hw * 2, d: mv.hd * 2, mv }, { x: mv.bx, y: mv.by, z: mv.bz, w: mv.hw * 2, d: mv.hd * 2, mv }); });
  const all = nodes.concat(movers);
  const s = W.START, f = W.FINISH;
  if (m.cat === 'surf') { const r = await surfBot(m); console.log((r.fin ? 'OK  ' : 'WARN') + ' ' + m.id.padEnd(16), 'ramps=' + RAMPS.length, 'cps=' + CPS.length, 'bot: finished=' + r.fin, 'falls=' + r.falls, 'vmax=' + r.vmax.toFixed(1), 'maxSurfT=' + r.surf.toFixed(0) + 's', 'time=' + r.t.toFixed(0) + 's'); if (!r.fin) bad++; continue; }
  if (m.cat === 'free') { console.log('OK   ' + m.id.padEnd(16), 'col=' + COL.length, 'ramps=' + RAMPS.length, 'portals=' + PORTALS.length, 'finish=' + hasFinish); continue; }
  let startI = all.findIndex(n => Math.abs(s.x - n.x) < n.w / 2 && Math.abs(s.z - n.z) < n.d / 2 && Math.abs(s.y - n.y) < .5);
  let finI = f ? all.findIndex(n => Math.abs(f.x - n.x) < n.w / 2 && Math.abs(f.z - n.z) < n.d / 2 && Math.abs(f.y - n.y) < .5) : -1;
  const adj = (a, b) => { const g = gapOf(a, b); if (g === null) return false; const dy = b.y - a.y; if (a.ramp && b.ramp) return g < 12; if (a.mv && a.mv === b.mv) return true; if (m.id === 'pure' && Math.abs(dy) < .2 && g > 12 && g < 15.5) return true;
    const v = m.cat === 'bhop' ? 13 : 6.8, ap = 1.65; if (dy > 1.55) return false; const t = .38 + Math.sqrt(2 * Math.max(0.01, ap - dy) / 30); return g <= 0.9 * v * t + .3; };
  const seen = new Set([startI]), q = [startI];
  while (q.length) { const i = q.shift(); for (let j = 0; j < all.length; j++) if (!seen.has(j) && adj(all[i], all[j])) { seen.add(j); q.push(j); } }
  const reach = finI >= 0 ? seen.has(finI) : null;
  let portalOk = PORTALS.every(p => p.to && isFinite(p.to.x));
  console.log((reach === false ? 'WARN' : 'OK  ') + ' ' + m.id.padEnd(16), 'cat=' + m.cat, 'col=' + COL.length, 'ramps=' + RAMPS.length, 'mov=' + MOV.length, 'cps=' + CPS.length, 'portals=' + PORTALS.length, 'route=' + R.length, 'finish=' + hasFinish, 'reach=' + reach, (Date.now() - t0) + 'ms');
  if (reach === false) { bad++; let best = 0; const fr = [...seen].map(i => all[i]).sort((a, b) => a.z - b.z)[0]; const cand = all.filter(n => !seen.has(all.indexOf(n)) && Math.hypot(n.x - fr.x, n.z - fr.z) < 16).map(n => ({ n, g: gapOf(fr, n), dy: n.y - fr.y })).sort((a, b) => a.g - b.g).slice(0, 3); const rs = [...seen].map(i => all[i]); const bl = []; all.forEach((n, ni) => { if (seen.has(ni) || n.ramp) return; let mg = 1e9, from = null; rs.forEach(r => { const g = gapOf(r, n); if (g < mg) { mg = g; from = r; } }); if (from && mg > 0.3) bl.push({ g: mg, dy: n.y - from.y, n, from }); }); bl.sort((a, b) => a.g - b.g); console.log('   blockers:', bl.slice(0, 3).map(c => 'gap ' + c.g.toFixed(1) + ' dy ' + c.dy.toFixed(1) + ' from(' + c.from.x.toFixed(0) + ',' + c.from.y.toFixed(0) + ',' + c.from.z.toFixed(0) + ' w' + c.from.w.toFixed(0) + 'd' + c.from.d.toFixed(0) + ') to(' + c.n.x.toFixed(0) + ',' + c.n.y.toFixed(0) + ',' + c.n.z.toFixed(0) + ' w' + c.n.w.toFixed(0) + 'd' + c.n.d.toFixed(0) + ')').join('\n      ')); }
  if (!hasFinish) { console.log('   нет финиша!'); bad++; }
  if (m.cat !== 'free' && cps < 3) { console.log('   мало чекпоинтов'); bad++; }
  if (!portalOk) { bad++; console.log('   портал с некорректным выходом'); }
}
if (process.env.PROBE) {
  const [id, x, y, z] = process.env.PROBE.split(',');
  loadMap(id); resetPlayer(+x, +y, +z, 0); IN.run = true; IN.y = 0;
  for (let i = 0; i < 240; i++) { gather(); stepPhysics(1 / 120); if (i % 30 === 0) console.log('probe', i, P.x.toFixed(1), P.y.toFixed(1), P.z.toFixed(1), 'gnd', P.onGround, 'surf', P.surfT > 0); }
  const near = RAMPS.filter(r => Math.abs((r.minX + r.maxX) / 2 - (+x)) < 30 && Math.abs((r.minZ + r.maxZ) / 2 - (+z)) < 30 && Math.abs(r.maxY - (+y)) < 12); console.log('ramps near', near.length, near.slice(0,3).map(r => [r.minX.toFixed(0), r.maxX.toFixed(0), r.minY.toFixed(0), r.maxY.toFixed(0), r.minZ.toFixed(0), r.maxZ.toFixed(0)].join('/')).join(' ; '));
}

console.log(bad ? 'PROBLEMS: ' + bad : 'ALL MAPS OK'); process.exit(bad ? 1 : 0);
