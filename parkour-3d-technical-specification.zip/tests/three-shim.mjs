export * from '/tmp/pk/out/node_modules/three/build/three.module.js';
const noop = () => {};
export class WebGLRenderer { constructor() { this.capabilities = { getMaxAnisotropy: () => 1, maxTextureSize: 4096 }; this.shadowMap = { enabled: false }; this.domElement = {}; this.info = {}; }
  setPixelRatio() {} setSize() {} setClearColor() {} render() {} clearDepth() {} getContext() { return {}; } }