import { addObb, clearColliders, RAMPS } from '../src/game/collision.js';
import { P, IN, gather, stepPhysics, resetPlayer } from '../src/game/physics.js';
import { troughSlabs } from '../src/game/surfgeo.js';
import * as T from 'three';
function add(s) { const m = new T.Matrix4().compose(new T.Vector3(s.cx, s.cy, s.cz), new T.Quaternion().setFromEuler(new T.Euler(s.rx, s.ry, s.rz, 'YXZ')), new T.Vector3(1,1,1)); addObb(s.cx, s.cy, s.cz, s.hx, s.hy, s.hz, m.elements); }
clearColliders(); let p=[0,60,0], yaw=0; const pts=[p.slice()];
for (let i=0;i<14;i++){ const t=troughSlabs(p[0],p[1],p[2],yaw,-0.08,7,{th:0.96,w:14}); t.slabs.forEach(add); p=t.end; pts.push(p.slice()); yaw+=0.14; }
resetPlayer(2.5, 65, -2, 0); P.vz=-12; IN.run=true; IN.x=0; IN.y=0;
for (let i=0;i<120*6;i++){ P.yaw=Math.atan2(-P.vx,-P.vz); gather(); stepPhysics(1/120); if(i%60===0) console.log((i/120).toFixed(1),'pos',P.x.toFixed(2),P.y.toFixed(2),P.z.toFixed(2),'v',P.vx.toFixed(1),P.vy.toFixed(1),P.vz.toFixed(1),'surf',P.surfT>0); }
