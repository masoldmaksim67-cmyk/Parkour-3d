// Карты: геометрия, маршрут, чекпоинты, финиш и атмосфера для каждой локации.
import {
  THREE, W, box, solid, cyl, addCol, crate, ac, vent, tank, antenna, skylight, shed, billboard, sign, cp, buildFinish,
  makeGround, makeClouds, skyline, rnd, seed, resetWorld, buildBatches, applyAtmosphere, add, qualityParams
} from './core.js';
import { S } from './state.js';

import { CPS } from './collision.js';

const pick = a => a[(rnd() * a.length) | 0];

/* ======================================================================
   1. CITY ROOFTOPS
====================================================================== */
const PAL = [0xffffff, 0xf2e8da, 0xd9e5f2, 0xeadbd2, 0xdbe9de, 0xe8e2f0];
function cityRoof(x, y, z, w, d, o) {
  o = o || {};
  const tint = PAL[(rnd() * PAL.length) | 0];
  const x0 = x - w / 2, x1 = x + w / 2, z0 = z - d / 2, z1 = z + d / 2;
  box(x0, W.groundY, z0, x1, y, z1, 'facade', 'roof', tint);
  box(x0 - .2, y - .6, z0 - .2, x1 + .2, y - .02, z1 + .2, 'concrete', 'concrete', 0xe0ded8, null, true);
  const col = addCol(x0, y - 60, z0, x1, y, z1);
  const t = .22, hh = .14, lt = 0xe9e7e0;
  box(x0, y, z0, x1, y + hh, z0 + t, 'concrete', 'concrete', lt); box(x0, y, z1 - t, x1, y + hh, z1, 'concrete', 'concrete', lt);
  box(x0, y, z0, x0 + t, y + hh, z1, 'concrete', 'concrete', lt); box(x1 - t, y, z0, x1, y + hh, z1, 'concrete', 'concrete', lt);
  if (w >= 6.5) { solid(x0, y, z0, x0 + .3, y + .45, z1, 'concrete', 0xd6d6d0); solid(x1 - .3, y, z0, x1, y + .45, z1, 'concrete', 0xd6d6d0); }
  if (!o.noProps) {
    if (w >= 11) {
      [-1, 1].forEach(side => {
        if (rnd() < .8) {
          const px = x + side * (w / 2 - 1.4), pz = z + (rnd() - .5) * (d - 5), t2 = (rnd() * 5) | 0;
          if (t2 === 0) ac(px, y, pz); else if (t2 === 1) vent(px, y, pz); else if (t2 === 2 && d >= 12) tank(px, y, pz); else if (t2 === 3) skylight(px, y, pz, 2.4, 1.8); else antenna(px, y, pz, 4 + rnd() * 3);
        }
      });
    } else if (w >= 8 && rnd() < .6) vent(x + (rnd() < .5 ? -1 : 1) * (w / 2 - .9), y, z + d / 2 - 1.2);
  }
  return { x, y, z, w, d, col };
}


/* ======================================================================
   2. INDUSTRIAL ZONE
====================================================================== */
const CTN = [0xc0392b, 0x2e86c1, 0x229954, 0xd68910, 0x7d3c98, 0x839192];
function deck(x, y, z, w, d, o) {
  o = o || {};
  const x0 = x - w / 2, x1 = x + w / 2, z0 = z - d / 2, z1 = z + d / 2;
  if (o.ctn) {
    box(x0, y - 2.6, z0, x1, y, z1, 'container', 'container', pick(CTN));
    const col = addCol(x0, y - 2.6, z0, x1, y, z1);
    box(x0 + .3, W.groundY, z0 + .5, x0 + .8, y - 2.6, z0 + 1, 'metal', 'metal', 0x4a525a);
    return { x, y, z, w, d, col };
  }
  box(x0, y - 1.2, z0, x1, y, z1, 'rust', 'grate', 0xffffff, null, true);
  const col = addCol(x0, y - 1.2, z0, x1, y, z1);
  [[x0 + .6, z0 + .6], [x1 - .6, z0 + .6], [x0 + .6, z1 - .6], [x1 - .6, z1 - .6]].forEach(c => box(c[0] - .3, W.groundY, c[1] - .3, c[0] + .3, y - 1.2, c[1] + .3, 'metal', 'metal', 0x5d656c));
  if (w >= 6) { box(x0, y, z0, x1, y + .05, z0 + .3, 'hazard', 'hazard'); box(x0, y, z1 - .3, x1, y + .05, z1, 'hazard', 'hazard'); }
  if (!o.noProps && w >= 10 && d >= 10) {
    [-1, 1].forEach(side => {
      if (rnd() < .75) {
        const px = x + side * (w / 2 - 1.5), pz = z + (rnd() - .5) * (d - 5), t = (rnd() * 4) | 0;
        if (t === 0) { solid(px - 1.3, y, pz - 3, px + 1.3, y + 2.6, pz + 3, 'container', pick(CTN)); }
        else if (t === 1) tank(px, y, pz); else if (t === 2) vent(px, y, pz); else { crate(px, y, pz, 1.3); crate(px + 1.3, y, pz, 1.1); }
      }
    });
  }
  return { x, y, z, w, d, col };
}


/* ======================================================================
   3. NIGHT CITY
====================================================================== */
const NEON = [0x00e5ff, 0xff2fd0, 0xffe14a, 0x7dff6a];
let nIdx = 0;
function nightRoof(x, y, z, w, d, o) {
  o = o || {};
  const x0 = x - w / 2, x1 = x + w / 2, z0 = z - d / 2, z1 = z + d / 2;
  box(x0, W.groundY, z0, x1, y, z1, 'nfacade', 'roof', 0xffffff);
  box(x0 - .2, y - .6, z0 - .2, x1 + .2, y - .02, z1 + .2, 'concrete', 'concrete', 0x4a4f60, null, true);
  const col = addCol(x0, y - 60, z0, x1, y, z1);
  const nc = NEON[(nIdx++) % NEON.length], t = .2, hh = .1;
  box(x0, y, z0, x1, y + hh, z0 + t, 'neon', 'neon', nc); box(x0, y, z1 - t, x1, y + hh, z1, 'neon', 'neon', nc);
  box(x0, y, z0, x0 + t, y + hh, z1, 'neon', 'neon', nc); box(x1 - t, y, z0, x1, y + hh, z1, 'neon', 'neon', nc);
  if (w >= 8 && !o.pad) { solid(x0 + .2, y, z0, x0 + .5, y + .45, z1, 'concrete', 0x3a3f50); solid(x1 - .5, y, z0, x1 - .2, y + .45, z1, 'concrete', 0x3a3f50); }
  if (!o.noProps && !o.pad && w >= 11) {
    [-1, 1].forEach(side => {
      if (rnd() < .7) {
        const px = x + side * (w / 2 - 1.6), pz = z + (rnd() - .5) * (d - 5), t2 = (rnd() * 3) | 0;
        if (t2 === 0) ac(px, y, pz); else if (t2 === 1) vent(px, y, pz); else antenna(px, y, pz, 4 + rnd() * 3);
      }
    });
  }
  return { x, y, z, w, d, col };
}


/* ======================================================================
   4. SKY PARKOUR
====================================================================== */
function island(x, y, z, w, d, o) {
  const x0 = x - w / 2, x1 = x + w / 2, z0 = z - d / 2, z1 = z + d / 2, ins = Math.min(w, d) * .12;
  box(x0, y - 1.2, z0, x1, y, z1, 'cloudp', 'cloudp', 0xffffff);
  box(x0 + ins, y - 3.6, z0 + ins, x1 - ins, y - 1.2, z1 - ins, 'rock', 'rock', 0xbab2a2);
  box(x0 + ins * 2, y - 6.4, z0 + ins * 2, x1 - ins * 2, y - 3.6, z1 - ins * 2, 'rock', 'rock', 0x9d9586);
  box(x0 + ins * 3, y - 10, z0 + ins * 3, x1 - ins * 3, y - 6.4, z1 - ins * 3, 'rock', 'rock', 0x857d70);
  const col = addCol(x0, y - 1.2, z0, x1, y, z1);
  if (o && !o.pad && !o.noProps && w >= 12 && rnd() < .7) {
    const px = x + (rnd() < .5 ? -1 : 1) * (w / 2 - 1.6), pz = z + (rnd() - .5) * (d - 4);
    cyl('cloudp', 0xdde8f5, px, y + 1.2, pz, .35, .5, 2.4, 'y', 8); cyl('neon', 0x7fdcff, px, y + 2.6, pz, .6, .6, .25, 'y', 8);
  }
  return { x, y, z, w, d, col };
}
function skyRing(x, y, z, r, color) {
  const m = new THREE.Mesh(new THREE.TorusGeometry(r, .35, 8, 36), new THREE.MeshBasicMaterial({ color })); m.position.set(x, y, z); add(m);
}


/* ======================================================================
   5. CONSTRUCTION SITE
====================================================================== */
function slab(x, y, z, w, d, o) {
  o = o || {};
  const x0 = x - w / 2, x1 = x + w / 2, z0 = z - d / 2, z1 = z + d / 2;
  if (o.pad) {
    box(x0, y - .22, z0, x1, y, z1, 'wood', 'wood');
    const col = addCol(x0, y - .5, z0, x1, y, z1);
    [[x0 + .15, z0 + .15], [x1 - .15, z0 + .15], [x0 + .15, z1 - .15], [x1 - .15, z1 - .15]].forEach(c => box(c[0] - .06, W.groundY, c[1] - .06, c[0] + .06, y - .22, c[1] + .06, 'metal', 'metal', 0x59626b));
    for (let yy = y - 3; yy > y - 12; yy -= 3) { box(x0 + .1, yy, z0 + .1, x1 - .1, yy + .08, z0 + .18, 'metal', 'metal', 0x59626b); box(x0 + .1, yy, z1 - .18, x1 - .1, yy + .08, z1 - .1, 'metal', 'metal', 0x59626b); }
    return { x, y, z, w, d, col };
  }
  box(x0, y - .9, z0, x1, y, z1, 'concrete', 'concrete', 0xdad7d0, null, true);
  const col = addCol(x0, y - .9, z0, x1, y, z1);
  if (w >= 8) [[x0 + .7, z0 + .7], [x1 - .7, z0 + .7], [x0 + .7, z1 - .7], [x1 - .7, z1 - .7]].forEach(c => box(c[0] - .35, W.groundY, c[1] - .35, c[0] + .35, y - .9, c[1] + .35, 'concrete', 'concrete', 0xb9b6ae));
  box(x0, y, z0, x1, y + .05, z0 + .3, 'hazard', 'hazard'); box(x0, y, z1 - .3, x1, y + .05, z1, 'hazard', 'hazard');
  if (!o.noProps && w >= 10 && d >= 10) {
    [-1, 1].forEach(side => {
      if (rnd() < .75) {
        const px = x + side * (w / 2 - 1.5), pz = z + (rnd() - .5) * (d - 5), t = (rnd() * 3) | 0;
        if (t === 0) { crate(px, y, pz, 1.3); crate(px + 1.3, y, pz, 1.1); crate(px + .6, y + 1.1, pz, 1.0); }
        else if (t === 1) { cyl('metal', 0xd9852b, px, y + .5, pz, .45, .45, 1, 'y', 10); cyl('metal', 0xd9852b, px + 1.1, y + .5, pz, .45, .45, 1, 'y', 10); addCol(px - .5, y, pz - .5, px + 1.6, y + 1, pz + .5); }
        else { solid(px - 1.2, y, pz - .8, px + 1.2, y + .9, pz + .8, 'wood', 0xffffff); }
      }
    });
  }
  return { x, y, z, w, d, col };
}
function crane(x, y0, z, h, jib) {
  const yel = 0xe8b020;
  box(x - .7, y0, z - .7, x + .7, y0 + h, z + .7, 'beam', 'beam', yel);
  box(x - 1.2, y0 + h, z - 1.2, x + 1.2, y0 + h + 2.4, z + 1.2, 'beam', 'beam', 0xf2c230);
  box(x - .35, y0 + h + 2.4, z - jib, x + .35, y0 + h + 3.2, z + jib * .35, 'beam', 'beam', yel);
  box(x - 1.2, y0 + h + 1.2, z + jib * .35, x + 1.2, y0 + h + 3, z + jib * .35 + 3, 'concrete', 'concrete', 0x777c82);
  cyl('plain', 0x2b2f33, x, y0 + h + 1.6 - jib * .3, z - jib * .6, .05, .05, 3 + jib * .3, 'y', 4);
  box(x - .6, y0 + h - 5 - jib * .3, z - jib * .6 - .6, x + .6, y0 + h - 4 - jib * .3, z - jib * .6 + .6, 'hazard', 'hazard');
}


/* ======================================================================
   Реестр карт
====================================================================== */

export { cityRoof, deck, nightRoof, island, slab, skyRing, crane, CTN, NEON, PAL };

let pi = 0;
const NEON2 = NEON;
function tower(x, y, z, w, d, o) {
  o = o || {};
  const x0 = x - w / 2, x1 = x + w / 2, z0 = z - d / 2, z1 = z + d / 2;
  if (o.pad) {
    const c = NEON[pi++ % NEON.length];
    box(x0, y - .9, z0, x1, y, z1, 'metal', 'neon', c);
    const col = addCol(x0, y - 60, z0, x1, y, z1);
    return { x, y, z, w, d, col };
  }
  box(x0, W.groundY, z0, x1, y, z1, 'facade', 'roof', PAL[(rnd() * PAL.length) | 0]);
  box(x0 - .2, y - .6, z0 - .2, x1 + .2, y - .02, z1 + .2, 'concrete', 'concrete', 0xe0ded8, null, true);
  const col = addCol(x0, y - 60, z0, x1, y, z1);
  const t = .22, hh = .14, lt = 0xe9e7e0;
  box(x0, y, z0, x1, y + hh, z0 + t, 'concrete', 'concrete', lt); box(x0, y, z1 - t, x1, y + hh, z1, 'concrete', 'concrete', lt);
  box(x0, y, z0, x0 + t, y + hh, z1, 'concrete', 'concrete', lt); box(x1 - t, y, z0, x1, y + hh, z1, 'concrete', 'concrete', lt);
  if (!o.noProps && w >= 11 && rnd() < .6) { const px = x + (rnd() < .5 ? -1 : 1) * (w / 2 - 1.4); if (rnd() < .5) ac(px, y, z); else vent(px, y, z); }
  return { x, y, z, w, d, col };
}


export { tower };
