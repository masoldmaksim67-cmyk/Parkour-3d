// Данные коллизий: AABB-боксы, наклонные плоскости (OBB-плиты для серфа/рамп) и подвижные платформы.
// Модуль не зависит от DOM/Three — его можно тестировать отдельно.
const TAU = Math.PI * 2;
export const COL = [], RAMPS = [], MOV = [], CPS = [], PORTALS = [];

export function clearColliders() { COL.length = 0; RAMPS.length = 0; MOV.length = 0; CPS.length = 0; PORTALS.length = 0; }

export function addCol(x0, y0, z0, x1, y1, z1) {
  const c = { minX: x0, minY: y0, minZ: z0, maxX: x1, maxY: y1, maxZ: z1, mv: null };
  COL.push(c); return c;
}

// e — column-major матрица 4x4 (THREE.Matrix4.elements) с поворотом плиты
export function addObb(cx, cy, cz, hx, hy, hz, e) {
  const ax = [[e[0], e[1], e[2]], [e[4], e[5], e[6]], [e[8], e[9], e[10]]], h = [hx, hy, hz], planes = [];
  for (let i = 0; i < 3; i++) {
    const a = ax[i], c = a[0] * cx + a[1] * cy + a[2] * cz;
    planes.push({ nx: a[0], ny: a[1], nz: a[2], d: c + h[i] });
    planes.push({ nx: -a[0], ny: -a[1], nz: -a[2], d: -c + h[i] });
  }
  const ex = Math.abs(e[0]) * hx + Math.abs(e[4]) * hy + Math.abs(e[8]) * hz;
  const ey = Math.abs(e[1]) * hx + Math.abs(e[5]) * hy + Math.abs(e[9]) * hz;
  const ez = Math.abs(e[2]) * hx + Math.abs(e[6]) * hy + Math.abs(e[10]) * hz;
  const r = { minX: cx - ex, maxX: cx + ex, minY: cy - ey, maxY: cy + ey, minZ: cz - ez, maxZ: cz + ez, planes, ramp: true };
  RAMPS.push(r); return r;
}

// Подвижная платформа (синусоидальное движение между A и B)
export function makeMoverData(ax, ay, az, w, d, bx, by, bz, period, phase, mesh) {
  const col = addCol(0, 0, 0, 0, 0, 0);
  const s0 = 0.5 - 0.5 * Math.cos(phase);
  const m = {
    ax, ay, az, bx, by, bz, hw: w / 2, hd: d / 2, th: 0.6, w: TAU / period, ph: phase, col, mesh,
    x: ax + (bx - ax) * s0, y: ay + (by - ay) * s0, z: az + (bz - az) * s0, dx: 0, dy: 0, dz: 0, vx: 0, vy: 0, vz: 0
  };
  col.mv = m; MOV.push(m); updateMoverPos(m, 1, 0); m.dx = m.dy = m.dz = 0; m.vx = m.vy = m.vz = 0;
  return m;
}
export function updateMoverPos(m, h, t) {
  const s = 0.5 - 0.5 * Math.cos(t * m.w + m.ph);
  const nx = m.ax + (m.bx - m.ax) * s, ny = m.ay + (m.by - m.ay) * s, nz = m.az + (m.bz - m.az) * s;
  m.dx = nx - m.x; m.dy = ny - m.y; m.dz = nz - m.z; m.vx = m.dx / h; m.vy = m.dy / h; m.vz = m.dz / h; m.x = nx; m.y = ny; m.z = nz;
  const c = m.col; c.minX = nx - m.hw; c.maxX = nx + m.hw; c.minZ = nz - m.hd; c.maxZ = nz + m.hd; c.maxY = ny; c.minY = ny - m.th;
  if (m.mesh) m.mesh.position.set(nx, ny, nz);
}
