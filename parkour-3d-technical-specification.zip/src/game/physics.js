// Физика игрока: Source/CS-подобное движение в метрах.
//  • Ground Acceleration + Friction — бег набирает только базовую скорость (≈0.4 с разгона), без трения при «чистом» прыжке.
//  • Air Acceleration + Air Strafing — скорость растёт только за счёт стрейфа в воздухе (cap по проекции на wishdir).
//  • Bunny Hop — прыжок в первый тик контакта с землёй пропускает трение и сохраняет скорость.
//  • Surf — наклонные плоскости (normal.y < WALK_NY) не являются землёй: скорость клипуется по плоскости, гравитация скатывает игрока.
//  • Speed cap — мягкий предел с «сопротивлением» и жёсткий предел.
import { COL, RAMPS, MOV, updateMoverPos } from './collision.js';

export const HW = 0.3, EPS = 1e-4;
export const K = {
  STEP: 1 / 120,
  JUMP: 8.4, G_UP: 22, G_DN: 30,
  RUN: 6.8, WALK: 4.4,
  GROUND_ACCEL: 5, FRICTION: 4.2, STOP: 2.2,
  AIR_ACCEL: 4.5, AIR_CAP: 1.0,
  SOFT: 16, HARD: 23, SOFT_SURF: 24, HARD_SURF: 32,
  HOP_WINDOW: 0.09, // макс. время на земле, при котором прыжок считается bhop
  WALK_NY: 0.7, SNAP: 0.14, VAULT: 1.0,
  WALL_G: 0.12, WALL_MAX: 1.7
};

export const P = {
  x: 0, y: 20, z: 3, vx: 0, vy: 0, vz: 0, yaw: 0, pitch: 0,
  onGround: false, ground: null, coyote: 0, h: 1.8, eye: 1.62, hs: 0,
  groundT: 0, hopT: 9, hops: 0, surfT: 0, surfNx: 0, surfNy: 1, surfNz: 0, surfed: false, airT: 0, wallT: 0, wallNx: 0, wallNz: 0, wallUsed: 0, wallRun: false,
  bobPh: 0, bobAmp: 0, bobY: 0, bobR: 0, landY: 0, landV: 0, kick: 0, kickV: 0, roll: 0, fovX: 0,
  killY: -10, fallT: 0, stepIdx: 0
};
export const IN = { x: 0, y: 0, run: false, keyRun: false, jumpHeld: false, jumpBuf: 0, autoHop: true };
export const EV = { land: null, jump: null, bhop: null, surfJump: null, wallJump: null };

let simT = 0, gndNow = false;
const NEAR = [], NEARR = [];
const PEN = { depth: 0 };
export function resetSim() { simT = 0; }

export function gather() {
  NEAR.length = 0; NEARR.length = 0;
  for (let i = 0; i < COL.length; i++) {
    const c = COL[i];
    if (c.maxX > P.x - 8 && c.minX < P.x + 8 && c.maxZ > P.z - 8 && c.minZ < P.z + 8 && c.maxY > P.y - 5 && c.minY < P.y + P.h + 5) NEAR.push(c);
  }
  for (let i = 0; i < RAMPS.length; i++) {
    const r = RAMPS[i];
    if (r.maxX > P.x - 8 && r.minX < P.x + 8 && r.maxZ > P.z - 8 && r.minZ < P.z + 8 && r.maxY > P.y - 8 && r.minY < P.y + P.h + 8) NEARR.push(r);
  }
}

const ov = c => P.x + HW > c.minX && P.x - HW < c.maxX && P.z + HW > c.minZ && P.z - HW < c.maxZ && P.y + P.h > c.minY && P.y < c.maxY;

// Проникновение AABB игрока в выпуклую плиту: плоскость минимального проникновения (глубина — в PEN.depth)
function penetrate(r) {
  if (P.x + HW <= r.minX || P.x - HW >= r.maxX || P.z + HW <= r.minZ || P.z - HW >= r.maxZ || P.y + P.h <= r.minY || P.y >= r.maxY) return null;
  const cy = P.y + P.h * 0.5, hh = P.h * 0.5;
  let best = 1e9, bp = null, bi = 0, dTop = 0;
  for (let i = 0; i < 6; i++) {
    const pl = r.planes[i];
    const ext = Math.abs(pl.nx) * HW + Math.abs(pl.ny) * hh + Math.abs(pl.nz) * HW;
    const depth = pl.d - (pl.nx * P.x + pl.ny * cy + pl.nz * P.z - ext);
    if (depth <= 0) return null;
    if (i === 2) dTop = depth;
    if (depth < best) { best = depth; bp = pl; bi = i; }
  }
  // торцы плит (стыки рамп с разным курсом) — не стена, а ступенька: вылезаем по верхней плоскости
  if (bi >= 4 && dTop < 0.7) { bp = r.planes[2]; best = dTop; }
  PEN.depth = best; return bp;
}
function depen(c) {
  if (!ov(c)) return;
  const up = c.maxY - P.y, dn = P.y + P.h - c.minY, xp = c.maxX - (P.x - HW), xn = P.x + HW - c.minX, zp = c.maxZ - (P.z - HW), zn = P.z + HW - c.minZ;
  let m = up, k = 0; if (dn < m) { m = dn; k = 1; } if (xp < m) { m = xp; k = 2; } if (xn < m) { m = xn; k = 3; } if (zp < m) { m = zp; k = 4; } if (zn < m) { m = zn; k = 5; }
  switch (k) {
    case 0: P.y = c.maxY; if (P.vy < 0) P.vy = 0; break;
    case 1: P.y = c.minY - P.h - EPS; if (P.vy > 0) P.vy = 0; break;
    case 2: P.x = c.maxX + HW + EPS; break; case 3: P.x = c.minX - HW - EPS; break;
    case 4: P.z = c.maxZ + HW + EPS; break; default: P.z = c.minZ - HW - EPS;
  }
}
// горизонтальное перемещение по оси с автоподъёмом на невысокие ступеньки и скольжением вдоль стен
function moveH(axis, d) {
  if (d === 0) return;
  if (axis === 0) P.x += d; else P.z += d;
  for (let i = 0; i < NEAR.length; i++) {
    const c = NEAR[i]; if (!ov(c)) continue;
    const su = c.maxY - P.y;
    if (su > 0 && su <= (gndNow ? (Math.hypot(P.vx, P.vz) > 3.5 ? K.VAULT : 0.5) : 0.35) && P.vy <= 3) {
      const y0 = P.y; P.y = c.maxY + 0.002; let blk = false;
      for (let j = 0; j < NEAR.length; j++) if (NEAR[j] !== c && ov(NEAR[j])) { blk = true; break; }
      if (!blk) { P.y = c.maxY; continue; } P.y = y0;
    }
    if (c.maxY > P.y + P.h + 0.3) { P.wallT = 0.16; P.wallNx = axis === 0 ? (d > 0 ? -1 : 1) : 0; P.wallNz = axis === 1 ? (d > 0 ? -1 : 1) : 0; }
    if (axis === 0) { if (d > 0) P.x = c.minX - HW - EPS; else P.x = c.maxX + HW + EPS; P.vx = 0; }
    else { if (d > 0) P.z = c.minZ - HW - EPS; else P.z = c.maxZ + HW + EPS; P.vz = 0; }
  }
}
function onLand(imp, c) {
  if (c.mv) { P.vx -= c.mv.vx; P.vz -= c.mv.vz; }
  const pending = IN.jumpBuf > 0 || (IN.jumpHeld && IN.autoHop);
  if (imp > 17 && !pending) { P.vx *= 0.65; P.vz *= 0.65; } // жёсткое приземление без прыжка гасит скорость
  if (EV.land) EV.land(imp);
}

// ---- наклонные плоскости ----
function rampContact(r, pl, depth) {
  if (pl.ny >= K.WALK_NY) {
    // проходимый склон: вертикальный вынос, скорость параллельна склону
    const vn = P.vx * pl.nx + P.vy * pl.ny + P.vz * pl.nz;
    P.y += depth / pl.ny + 0.0003;
    if (vn <= 0.05) {
      const imp = -P.vy;
      P.vy = -(P.vx * pl.nx + P.vz * pl.nz) / pl.ny;
      P.onGround = true; P.ground = r;
      if (!gndNow && imp > 3) onLand(imp, r);
    }
  } else {
    // SURF / стена: вынос по нормали + клип скорости по плоскости (сохраняется вся тангенциальная скорость)
    const push = depth + EPS;
    P.x += pl.nx * push; P.y += pl.ny * push; P.z += pl.nz * push;
    const vn = P.vx * pl.nx + P.vy * pl.ny + P.vz * pl.nz;
    if (vn < 0) { P.vx -= pl.nx * vn; P.vy -= pl.ny * vn; P.vz -= pl.nz * vn; }
    if (pl.ny > 0.04) { P.surfT = 0.12; P.surfNx = pl.nx; P.surfNy = pl.ny; P.surfNz = pl.nz; P.surfed = true; }
  }
}
function resolveRamps() {
  for (let it = 0; it < 4; it++) {
    let any = false;
    for (let i = 0; i < NEARR.length; i++) {
      const r = NEARR[i], pl = penetrate(r);
      if (!pl) continue; any = true; rampContact(r, pl, PEN.depth);
    }
    if (!any) break;
  }
}
function snapToRamp() {
  P.y -= K.SNAP;
  for (let i = 0; i < NEARR.length; i++) {
    const r = NEARR[i], pl = penetrate(r);
    if (pl && pl.ny >= K.WALK_NY) {
      P.y += PEN.depth / pl.ny + 0.0003; P.vy = -(P.vx * pl.nx + P.vz * pl.nz) / pl.ny;
      P.onGround = true; P.ground = r; return;
    }
  }
  P.y += K.SNAP;
}

// ---- движение (Source) ----
function friction(h) {
  const sp = Math.hypot(P.vx, P.vz); if (sp < 0.001) return;
  const drop = Math.max(sp, K.STOP) * K.FRICTION * h, ns = Math.max(0, sp - drop) / sp;
  P.vx *= ns; P.vz *= ns;
}
function accelerate(dx, dz, wishspeed, accel, h) {
  const add = wishspeed - (P.vx * dx + P.vz * dz);
  if (add <= 0) return;
  const a = Math.min(add, accel * wishspeed * h);
  P.vx += dx * a; P.vz += dz * a;
}
// Air strafe: проекция скорости на wishdir ограничена AIR_CAP, поэтому прибавка возможна только при strafe под углом к вектору скорости
function airMove(h, wx, wz, m) {
  if (m <= 0.02) return;
  const dl = Math.hypot(wx, wz) || 1, dx = wx / dl, dz = wz / dl;
  const wishspeed = m * K.RUN;
  accelerate(dx, dz, Math.min(wishspeed, K.AIR_CAP), K.AIR_ACCEL * wishspeed / Math.min(wishspeed, K.AIR_CAP), h);
}
function groundMove(h, wx, wz, m, runOn) {
  friction(h);
  const base = runOn ? K.RUN : K.WALK, dl = Math.hypot(wx, wz);
  if (dl > 0.001) accelerate(wx / dl, wz / dl, Math.min(1, m) * base, K.GROUND_ACCEL, h);
}

export function stepPhysics(h) {
  simT += h;
  for (let i = 0; i < MOV.length; i++) updateMoverPos(MOV[i], h, simT);
  const prevG = P.ground, gnd = P.onGround; gndNow = gnd;
  if (gnd && prevG && prevG.mv) { P.x += prevG.mv.dx; P.y += prevG.mv.dy; P.z += prevG.mv.dz; }
  for (let i = 0; i < MOV.length; i++) depen(MOV[i].col);

  if (gnd) { P.coyote = 0.08; P.groundT += h; P.airT = 0; } else { P.coyote -= h; P.groundT = 0; P.airT += h; }
  P.hopT += h; IN.jumpBuf -= h; P.surfT -= h; P.wallT -= h; if (gnd) P.wallUsed = 0;

  const sy = Math.sin(P.yaw), cy = Math.cos(P.yaw);
  let ix = IN.x, iy = IN.y, m = Math.hypot(ix, iy); if (m > 1) { ix /= m; iy /= m; m = 1; }
  const wx = -sy * iy + cy * ix, wz = -cy * iy - sy * ix;

  // ---- прыжок: буфер + coyote + auto-hop ----
  let jumped = false;
  const wantJump = IN.jumpBuf > 0 || (IN.jumpHeld && IN.autoHop);
  if (wantJump && (gnd || P.coyote > 0)) {
    // bhop: прыжок в первые тики контакта — трение не применяется, скорость сохраняется; задержка на земле = потеря скорости
    if (P.groundT < K.HOP_WINDOW && P.hopT < 1.6) P.hops++; else P.hops = 1;
    P.hopT = 0;
    P.vy = K.JUMP + Math.max(0, P.vy); IN.jumpBuf = 0; P.coyote = 0; jumped = true;
    if (EV.jump) EV.jump();
    if (EV.bhop && P.hops >= 2) EV.bhop(P.hops);
  } else if (IN.jumpBuf > 0 && P.wallRun && !gnd) {
    // прыжок от стены (wall jump)
    P.vx += P.wallNx * 5.5; P.vz += P.wallNz * 5.5; P.vy = 7.4; P.wallUsed += 0.6; P.wallT = 0; IN.jumpBuf = 0; P.hopT = 0;
    if (EV.wallJump) EV.wallJump();
  } else if (IN.jumpBuf > 0 && P.surfT > 0 && !gnd) {
    // отскок от поверхности surf
    P.vx += P.surfNx * 3.0; P.vz += P.surfNz * 3.0; P.vy = Math.max(P.vy, 0) + P.surfNy * 5.5 + 2.5; P.surfT = 0; IN.jumpBuf = 0; P.hopT = 0;
    if (EV.surfJump) EV.surfJump();
  }

  const grounded = gnd && !jumped;
  const runOn = IN.run || IN.keyRun;
  if (grounded) groundMove(h, wx, wz, m, runOn); else airMove(h, wx, wz, m);

  // wall run: скольжение вдоль высокой стены при беге вперёд (ограничено по времени)
  let g = P.vy > 0 ? K.G_UP : K.G_DN;
  P.wallRun = !gnd && P.wallT > 0 && IN.y > 0.2 && Math.hypot(P.vx, P.vz) > 4 && P.wallUsed < K.WALL_MAX && P.vy < 5;
  if (P.wallRun) { P.wallUsed += h; g *= K.WALL_G; if (P.vy < -1.2) P.vy = -1.2; if (P.vy > 1.2) P.vy = 1.2; P.vx -= P.wallNx * 0.8 * h * 10; P.vz -= P.wallNz * 0.8 * h * 10; }
  P.vy -= g * h; if (P.vy < -45) P.vy = -45;

  // мягкий и жёсткий пределы горизонтальной скорости
  let hs = Math.hypot(P.vx, P.vz);
  const surf = P.surfT > 0, soft = surf ? K.SOFT_SURF : K.SOFT, hard = surf ? K.HARD_SURF : K.HARD;
  if (hs > soft) { const t = hs - (hs - soft) * 1.6 * h; P.vx *= t / hs; P.vz *= t / hs; hs = t; }
  if (hs > hard) { P.vx *= hard / hs; P.vz *= hard / hs; }

  moveH(0, P.vx * h); moveH(1, P.vz * h);
  P.onGround = false; P.ground = null; P.surfed = false;
  P.y += P.vy * h;
  for (let i = 0; i < NEAR.length; i++) {
    const c = NEAR[i]; if (!ov(c)) continue;
    if (P.vy <= 0) { const imp = -P.vy; P.y = c.maxY; P.vy = 0; P.onGround = true; P.ground = c; if (!gnd && imp > 3) onLand(imp, c); }
    else { P.y = c.minY - P.h - EPS; P.vy = 0; }
  }
  resolveRamps();
  if (gnd && !P.onGround && !jumped && prevG && prevG.ramp) snapToRamp();
  if (gnd && !P.onGround && prevG && prevG.mv) { P.vx += prevG.mv.vx; P.vz += prevG.mv.vz; if (prevG.mv.vy > 0) P.vy += prevG.mv.vy; }
}

export function resetPlayer(x, y, z, yaw) {
  P.x = x; P.y = y; P.z = z; P.vx = P.vy = P.vz = 0; P.yaw = yaw || 0; P.pitch = 0; P.onGround = false; P.ground = null;
  P.h = 1.8; P.landY = P.landV = P.kick = P.kickV = 0; P.coyote = 0; P.groundT = 0; P.hops = 0; P.hopT = 9; P.surfT = 0; P.airT = 0; P.wallT = 0; P.wallUsed = 0; P.wallRun = false;
  IN.jumpBuf = 0; IN.x = IN.y = 0;
}
