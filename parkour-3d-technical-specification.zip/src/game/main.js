// Главный модуль PARKOUR 3D: ввод, HUD, камера, игровой цикл, режимы, порталы, ранги, меню.
import './boot.js';
import { S, saveSettings, fmt, getRec, setRec, addStats, STATS, LS } from './state.js';
import { THREE, renderer, scene, camera, canvas, sky, sunSprite, lightDir, updateShadow, applyQuality as coreApplyQuality, W, clamp, qualityParams } from './core.js';
import { MAPS, loadMap, mapById } from './maps.js';
import { CPS, PORTALS } from './collision.js';
import { P, IN, K, EV, gather, stepPhysics, resetPlayer } from './physics.js';
import { AU, buzz } from './audio.js';
import { createKnife } from './knife.js';
import { MODE_BY_ID, modeMaps, supports } from './modes.js';
import { ACH_LIST, award, achCount } from './progress.js';
import { applyLayout, openEditor } from './controls.js';
import { awardRun, rankState } from './ranks.js';
import { SK } from './skins.js';
import * as UI from './screens.js';

const $ = id => document.getElementById(id);
const knife = createKnife(); knife.applySkin();
const SEL = UI.SEL;
let state = 'menu', curMap = null, runMode = SEL.mode, previewId = null, orbitT = 0;
const R = { time: 0, falls: 0, cp: 0, started: false, maxSpeed: 0, bhops: 0, bestStreak: 0, jumps: 0, travel: 0, penalty: 0, cd: 0, cdN: 0, splits: [], splitMsg: '', splitT: 0, pb: null, surfTime: 0, surfRun: 0, surfGap: 0, surfPend: 0, finTouch: 0, flush: 0, lx: 0, lz: 0, warpT: 0, warpP: null, warpCd: 0, cpYaw: [], prog: 0, killT: 0, wallT: 0 };
let acc = 0, px0 = 0, py0 = 0, pz0 = 0, rX = 0, rY = 0, rZ = 0, surfRoll = 0, routeCum = [], routeLen = 1;
const keys = {}, joy = { id: null, cx: 0, cy: 0, R: 60, size: 130, x: 0, y: 0, defX: 20, defY: 200 }, look = { id: null, x: 0, y: 0, ax: 0, ay: 0, t: 0 };
const mode = () => MODE_BY_ID[runMode];

/* ---------- статистика ---------- */
const pend = { attempts: 0, finishes: 0, falls: 0, bhops: 0, jumps: 0, distance: 0, playTime: 0, maxSpeed: 0, bestStreak: 0 };
function flush() { let any = false; Object.keys(pend).forEach(k => { if (pend[k]) any = true; }); if (!any || !curMap) return; addStats(pend, curMap.id, runMode); Object.keys(pend).forEach(k => { pend[k] = 0; }); }
window.addEventListener('beforeunload', flush);

/* ---------- достижения ---------- */
let achQ = [], achBusy = false; const achEl = document.createElement('div'); achEl.id = 'achPop'; $('toast').before(achEl);
function grant(id) { const a = award(id); if (!a) return; achQ.push(a); if (!achBusy) nextAch(); }
function nextAch() { const a = achQ.shift(); if (!a) { achBusy = false; return; } achBusy = true; achEl.innerHTML = a.icon + ' ДОСТИЖЕНИЕ: ' + a.name + '<small>' + a.desc + '</small>'; achEl.classList.add('show'); AU.ach(); setTimeout(() => { achEl.classList.remove('show'); setTimeout(nextAch, 450); }, 2800); }

/* ---------- карта ---------- */
function prepareRoute() {
  const pts = [W.START].concat(W.route || []); routeCum = [0]; for (let i = 1; i < pts.length; i++) routeCum.push(routeCum[i - 1] + Math.hypot(pts[i].x - pts[i - 1].x, pts[i].z - pts[i - 1].z) + Math.abs(pts[i].y - pts[i - 1].y) * .3);
  routeLen = Math.max(1, routeCum[routeCum.length - 1]); W.rp = pts;
}
function loadAndPrepare(id) { curMap = loadMap(id); prepareRoute(); $('hMap').textContent = curMap.name; applyQuality(); resetGame(); }
/* ---------- события физики ---------- */
EV.land = imp => { AU.land(imp); if (imp > 11) buzz(14); if (S.bob) { P.landV = -Math.min(imp * 0.2, 3.6); P.kickV = -Math.min(imp * 0.03, 0.5); } knife.landKick(imp); };
EV.jump = () => { AU.jump(); if (S.bob) { P.landV += 0.9; P.kickV += 0.45; } knife.jumpKick(); if (state !== 'play') return; R.jumps++; pend.jumps++; grant('first_jump'); if (STATS.total.jumps + pend.jumps >= 100) grant('jumps_100'); };
EV.surfJump = () => { AU.jump(); buzz(10); }; EV.wallJump = () => { AU.jump(); buzz(14); };
EV.bhop = n => { if (state !== 'play') return; R.bhops++; pend.bhops++; if (n > R.bestStreak) { R.bestStreak = n; if (n > pend.bestStreak) pend.bestStreak = n; } AU.bhop(n); grant('first_bhop'); if (n >= 10) grant('bhop_10'); };

/* ---------- HUD ---------- */
const E = {}; ['hTime', 'hFalls', 'hCp', 'hCpMax', 'hSpd', 'hSpBar', 'hTag', 'hMax', 'hBhop', 'hBigW', 'hBigL', 'hExtra', 'hModeN', 'hFallsL', 'hAir', 'countdown', 'hProg'].forEach(i => { E[i] = $(i); });
const fx = $('speedfx'), tcache = {};
const setT = (id, v) => { v = String(v); if (tcache[id] !== v) { tcache[id] = v; E[id].textContent = v; } };
function applyHudVis() {
  const set = new Set(mode().hud);
  document.querySelectorAll('#hud [data-h]').forEach(el => { const k = el.dataset.h; el.classList.toggle('off', !set.has(k) || S.hud[k] === false); });
  const cpOn = runMode !== 'freeroam' && CPS.length > 0; document.querySelector('[data-h="cp"]').classList.toggle('off', !cpOn || S.hud.cp === false);
  E.hBigW.classList.toggle('xl', runMode === 'timeattack'); setT('hModeN', mode().name); E.hCpMax.textContent = CPS.length; setT('hFallsL', runMode === 'speedrun' ? 'СБРОСЫ' : 'ПАДЕНИЯ');
  setT('hBigL', { parkour: 'ВРЕМЯ', bhop: 'ВРЕМЯ', surf: 'ВРЕМЯ', speedrun: 'SPEEDRUN', timeattack: 'TIME ATTACK' }[runMode] || '');
}
const total = () => R.time + R.penalty;
let lastFx = '', lastTag = '';
function updateHud() {
  const hs = P.hs, kmh = Math.round(hs * 3.6);
  setT('hSpd', kmh); setT('hMax', Math.round(R.maxSpeed * 3.6)); setT('hBhop', P.hopT < 1.3 && P.hops >= 2 ? P.hops : 0); setT('hFalls', R.falls);
  E.hSpBar.style.transform = 'scaleX(' + clamp(hs / 20, 0, 1).toFixed(3) + ')';
  E.hProg.style.transform = 'scaleX(' + clamp(R.prog, 0, 1).toFixed(3) + ')';
  const surfing = P.surfT > 0 && !P.onGround, air = P.wallRun ? 'WALL RUN' : surfing ? 'SURF' : P.onGround ? 'ЗЕМЛЯ' : 'В ВОЗДУХЕ'; setT('hAir', air);
  let big = '', extra = '';
  if (runMode === 'timeattack') { big = fmt(total()); extra = R.penalty ? 'ШТРАФ +' + R.penalty + ' с' : ''; } else if (runMode !== 'freeroam') big = fmt(R.time); else extra = 'FREE ROAM · без таймера';
  if (runMode === 'bhop') extra = 'ЛУЧШАЯ СЕРИЯ ' + R.bestStreak + ' · ВСЕГО BHOP ' + R.bhops;
  if (runMode === 'speedrun') extra = R.splitT > 0 ? R.splitMsg : 'ПОПЫТКА #' + (R.falls + 1);
  setT('hTime', big); setT('hExtra', extra); setT('hCp', R.cp);
  let tag = '', cls = ''; if (P.wallRun) { tag = 'WALL RUN'; cls = 'surf'; } else if (surfing) { tag = 'SURF'; cls = 'surf'; } else if (P.hops >= 3 && P.hopT < 1.3) tag = 'BHOP ×' + P.hops;
  if (tag !== lastTag) { E.hTag.textContent = tag; E.hTag.className = 'hTag' + (tag ? ' on ' + cls : ''); lastTag = tag; }
  const fq = qualityParams().fx, o = S.speedFx && fq > 0 ? (clamp((hs - 10) / 11, 0, 0.85) * (fq === 1 ? 0.6 : 1)).toFixed(2) : '0'; if (o !== lastFx) { fx.style.opacity = o; lastFx = o; }
}
let toastT = 0;
function toast(msg, ms) { const t = $('toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), ms || 2000); }
function showCountdown(txt) { const c = E.countdown; c.textContent = txt; c.classList.remove('pop'); void c.offsetWidth; c.classList.add('pop'); }

/* ---------- игровой процесс ---------- */
const startYaw = () => -(W.START.yaw || 0) * Math.PI / 180;
function paintCps() { CPS.forEach((c, i) => { const h = i < R.cp ? 0x45ff90 : 0x35d0ff; c.bm.color.setHex(h); c.rm.color.setHex(h); }); }
function respawn() {
  const sp = R.cp > 0 ? CPS[R.cp - 1] : W.START;
  resetPlayer(sp.x, sp.y + 0.02, sp.z, R.cp > 0 ? (R.cpYaw[R.cp - 1] || 0) : startYaw());
  P.fallT = 0; P.eye = 1.62; px0 = rX = P.x; py0 = rY = P.y; pz0 = rZ = P.z; acc = 0; surfRoll = 0; R.lx = P.x; R.lz = P.z; R.warpT = 0; R.warpCd = 0;
  look.ax = look.ay = 0; $('fade').classList.remove('on'); $('warpfx').classList.remove('on'); updateKillY(true);
}
function updateKillY(force) {
  const pts = (W.rp || []).concat(W.branches || []); if (!pts.length) { P.killY = P.y - 60; return; }
  let mn = 1e9, gmn = 1e9; for (let i = 0; i < pts.length; i++) { const q = pts[i]; if (q.y < gmn) gmn = q.y; if (Math.hypot(q.x - P.x, q.z - P.z) < 55 && q.y < mn) mn = q.y; }
  const ky = (mn < 1e8 ? mn : gmn) - W.killDrop; P.killY = force ? Math.min(ky, P.y - 12) : ky;
}
function resetGame() {
  Object.assign(R, { time: 0, falls: 0, cp: 0, started: false, maxSpeed: 0, bhops: 0, bestStreak: 0, jumps: 0, travel: 0, penalty: 0, cd: 0, cdN: 0, splits: [], splitMsg: '', splitT: 0, surfTime: 0, surfRun: 0, surfGap: 0, surfPend: 0, finTouch: 0, prog: 0, cpYaw: [] });
  R.pb = runMode === 'speedrun' && curMap ? LS.get('pk3d_splits_' + curMap.id, null) : null; if (!Array.isArray(R.pb)) R.pb = null;
  IN.run = true; $('bRun').classList.add('on'); paintCps(); respawn(); applyHudVis();
  if (runMode === 'timeattack') { R.cd = 3.6; R.cdN = 4; }
  Object.keys(tcache).forEach(k => delete tcache[k]); updateHud();
}
function doFall() {
  if (P.fallT > 0) return; P.fallT = 0.3; R.falls++; pend.falls++; R.surfPend = 0; R.surfRun = 0; AU.fall(); buzz(70);
  if (runMode === 'timeattack') R.penalty += 5;
  if (runMode === 'speedrun') { R.time = 0; R.started = false; R.cp = 0; R.splits = []; R.splitT = 0; paintCps(); toast('СБРОС — забег начинается заново', 1400); }
  const f = $('fade'); f.classList.remove('dark'); f.classList.add('on');
}
function finishRun() {
  if (state !== 'play') return;
  const t = total(), id = curMap.id, cat = curMap.cat; pend.finishes++;
  const prev = getRec(runMode, id), rec = setRec(runMode, id, t, true), pb = rec && prev !== null;
  if (runMode === 'speedrun' && rec) LS.set('pk3d_splits_' + id, R.splits);
  if (R.falls === 0) grant('perfect_run'); if (curMap.par && t < curMap.par * 0.8) grant('speedrunner');
  flush();
  const xp = awardRun({ mode: runMode, map: id, cat, diff: curMap.diff, par: curMap.par, time: t, falls: R.falls, pb, streak: R.bestStreak, maxSpeed: R.maxSpeed, surfTime: R.surfTime, cps: CPS.length });
  if (xp.up) grant('rankup');
  if (MAPS.filter(m => m.cat !== 'free').every(m => (STATS.maps[m.id] || {}).finishes > 0)) grant('all_maps');
  const stats = [['МАКС. СКОРОСТЬ', Math.round(R.maxSpeed * 3.6) + ' <small>км/ч</small>'], ['ПАДЕНИЯ', R.falls], ['УСПЕШНЫЕ BHOP', R.bhops], ['ЛУЧШАЯ СЕРИЯ', R.bestStreak], ['РЕКОРД', fmt(getRec(runMode, id))]];
  const list = []; if (runMode === 'timeattack') list.push(['Чистое время', fmt(R.time)], ['Штраф за падения', '+' + R.penalty + ' с']); if (runMode === 'speedrun') list.push(['Попыток (сбросов)', R.falls]);
  showResult({ title: runMode === 'speedrun' ? 'SPEEDRUN ЗАВЕРШЁН' : 'ФИНИШ!', big: fmt(t), rec, stats, list, xp });
}
function showResult(o) {
  state = 'result'; resetTouch(); AU.finish(); buzz([40, 40, 90]); setLayers(false, true);
  $('rTitle').textContent = o.title; $('rMap').textContent = mode().name + ' · ' + curMap.name; $('rBigL').textContent = 'ВРЕМЯ'; $('rTime').textContent = o.big; $('rBadge').classList.toggle('show', !!o.rec);
  $('rStats').innerHTML = o.stats.map(s => '<div>' + s[0] + '<b>' + s[1] + '</b></div>').join('');
  $('rXp').innerHTML = o.xp.lines.map(l => '<div class="l"><span>' + l[0] + '</span><b>+' + l[1] + ' XP</b></div>').join('') + '<div class="t">+' + o.xp.gain + ' XP</div>';
  $('rList').innerHTML = o.list.map(s => '<div><span>' + s[0] + '</span><b>' + s[1] + '</b></div>').join('');
  $('rNext').style.display = nextMap() ? '' : 'none';
  setTimeout(() => { if (state !== 'result') return; showScreen('result'); if (o.xp.up) setTimeout(() => { if (state !== 'result') return; UI.showRankUp(o.xp.newRank, () => { showScreen('result'); }); showScreen('rankup'); AU.finish(); }, 1400); }, 500);
}
function nextMap() { if (runMode === 'freeroam') return null; const l = modeMaps(runMode), i = l.findIndex(m => m.id === curMap.id); return l[i + 1] || null; }

/* ---------- порталы ---------- */
function checkPortals(dt) {
  if (R.warpCd > 0) { R.warpCd -= dt; return; }
  for (let i = 0; i < PORTALS.length; i++) {
    const p = PORTALS[i]; let hit;
    if (p.kind === 'ring') hit = Math.hypot(P.x - p.x, P.y + 0.9 - p.y, P.z - p.z) < p.r;
    else hit = Math.hypot(P.x - p.x, P.z - p.z) < p.r && Math.abs(P.y - p.fy) < 1.8;
    if (hit) { R.warpT = 0.16; R.warpP = p; $('warpfx').classList.add('on'); AU.beep(true); buzz(30); return; }
  }
}
function doTeleport(p) {
  const to = p.to, yaw = -to.yaw * Math.PI / 180, sp = Math.max(6, Math.min(P.hs, 24) * (p.keep ? 1 : 0.6));
  P.x = to.x; P.y = to.y + 0.05; P.z = to.z; P.vx = -Math.sin(yaw) * sp; P.vz = -Math.cos(yaw) * sp; P.vy = Math.max(0, P.vy * 0.2); P.yaw = yaw; P.onGround = false; P.ground = null; P.surfT = 0;
  px0 = rX = P.x; py0 = rY = P.y; pz0 = rZ = P.z; acc = 0; R.lx = P.x; R.lz = P.z; look.ax = look.ay = 0; R.warpCd = 1.2; updateKillY(true); grant('portal');
  if (p.name) toast('🌀 ' + p.name, 1600);
}

function updateGame(dt) {
  if (P.fallT > 0) { P.fallT -= dt; if (P.fallT <= 0) respawn(); updateCamera(dt); return; }
  if (R.warpT > 0) { R.warpT -= dt; if (R.warpT <= 0) { doTeleport(R.warpP); setTimeout(() => $('warpfx').classList.remove('on'), 60); } updateCamera(dt); return; }
  applyLook(dt);
  const kx = (keys.KeyD || keys.ArrowRight ? 1 : 0) - (keys.KeyA || keys.ArrowLeft ? 1 : 0), ky = (keys.KeyW || keys.ArrowUp ? 1 : 0) - (keys.KeyS || keys.ArrowDown ? 1 : 0);
  if (R.cd > 0) {
    R.cd -= dt; const n = Math.ceil(R.cd - 0.6);
    if (n !== R.cdN) { R.cdN = n; if (n >= 1) { showCountdown(String(n)); AU.beep(false); } else { showCountdown('GO!'); AU.beep(true); } }
    if (R.cd <= 0.6) { R.cd = 0; R.started = true; }
    IN.x = IN.y = 0; IN.jumpBuf = 0; P.hs = 0; updateCamera(dt); updateShadow(rX, rY, rZ); updateHud(); return;
  }
  const tx = joy.x + kx, ty = joy.y + ky, k = 1 - Math.exp(-dt * 40); IN.x += (tx - IN.x) * k; IN.y += (ty - IN.y) * k;
  if (Math.abs(IN.x) < 0.004) IN.x = 0; if (Math.abs(IN.y) < 0.004) IN.y = 0; IN.autoHop = S.autoHop;
  if (!R.started && runMode !== 'freeroam' && (Math.hypot(tx, ty) > 0.15 || IN.jumpBuf > 0 || IN.jumpHeld)) R.started = true;
  if (R.started) { R.time += dt; pend.playTime += dt; }
  gather(); acc += dt; let n = 0;
  while (acc >= K.STEP && n < 16) { px0 = P.x; py0 = P.y; pz0 = P.z; stepPhysics(K.STEP); acc -= K.STEP; n++; } if (n >= 16) acc = 0;
  const a = acc / K.STEP; rX = px0 + (P.x - px0) * a; rY = py0 + (P.y - py0) * a; rZ = pz0 + (P.z - pz0) * a;
  P.hs = Math.hypot(P.vx, P.vz);
  const moving = P.onGround && P.hs > 0.8; if (moving) P.bobPh += P.hs * dt * 1.55;
  const amp = moving && S.bob ? 0.042 * Math.min(1, P.hs / 6) : 0; P.bobAmp += (amp - P.bobAmp) * Math.min(1, dt * 9); P.bobY = Math.sin(P.bobPh * 2) * P.bobAmp; P.bobR = Math.sin(P.bobPh) * P.bobAmp * 0.14;
  const si = Math.floor(P.bobPh / Math.PI); if (si !== P.stepIdx) { P.stepIdx = si; if (moving) AU.step(); }
  P.landV += (-120 * P.landY - 14 * P.landV) * dt; P.landY += P.landV * dt; P.kickV += (-110 * P.kick - 11 * P.kickV) * dt; P.kick += P.kickV * dt; P.eye += (1.62 - P.eye) * Math.min(1, dt * 12);
  const step = Math.hypot(P.x - R.lx, P.z - R.lz); R.lx = P.x; R.lz = P.z; if (step < 3 && R.started) { R.travel += step; pend.distance += step; }
  if (P.hs > R.maxSpeed) { R.maxSpeed = P.hs; if (P.hs > pend.maxSpeed) pend.maxSpeed = P.hs; } if (P.hs * 3.6 >= 70) grant('speed_demon');
  if (STATS.total.distance + pend.distance >= 5000) grant('marathon'); if (P.wallRun) { R.wallT += dt; if (R.wallT > 0.6) grant('wallrun'); } else R.wallT = 0;
  R.flush += dt; if (R.flush > 8) { R.flush = 0; flush(); }
  // прогресс по маршруту
  if (W.rp) { let bi = 0, bd = 1e9; for (let i = 0; i < W.rp.length; i++) { const q = W.rp[i], d = Math.hypot(q.x - P.x, q.z - P.z) + Math.abs(q.y - P.y) * 0.5; if (d < bd) { bd = d; bi = i; } } if (bd < 40) R.prog = Math.max(R.prog, routeCum[bi] / routeLen); }
  // surf: учёт времени и достижение
  if (P.surfT > 0 && !P.onGround) { R.surfRun += dt; R.surfTime += dt; R.surfGap = 0; if (R.surfRun >= 3 && R.surfPend === 0) R.surfPend = 2; } else { R.surfGap += dt; if (R.surfGap > 0.6) R.surfRun = 0; }
  if (R.surfPend > 0) { R.surfPend -= dt; if (R.surfPend <= 0) { R.surfPend = -1; grant('surf_master'); } } if (R.splitT > 0) R.splitT -= dt;
  // чекпоинты
  for (let i = R.cp; i < CPS.length; i++) {
    const c = CPS[i], dx = P.x - c.x, dz = P.z - c.z;
    if (dx * dx + dz * dz < 9 && Math.abs(P.y - c.y) < 2.6) {
      R.cp = i + 1; R.cpYaw[i] = P.yaw; paintCps(); AU.checkpoint(); buzz(30);
      if (runMode === 'speedrun') { R.splits[i] = R.time; const pb = R.pb && R.pb[i]; if (typeof pb === 'number') { const d = R.time - pb; R.splitMsg = 'СПЛИТ ' + R.cp + ': ' + (d <= 0 ? '−' : '+') + Math.abs(d).toFixed(2) + ' с'; } else R.splitMsg = 'СПЛИТ ' + R.cp + ': ' + fmt(R.time); R.splitT = 4; } else toast('Чекпоинт ' + R.cp + ' / ' + CPS.length, 1400);
      break;
    }
  }
  checkPortals(dt);
  if (runMode === 'freeroam' && P.y > 20 && Math.hypot(P.x - 14, P.z + 26) < 8) grant('explorer');
  if (runMode !== 'freeroam' && P.onGround && W.FINISH && P.ground === W.FINISH.col) { finishRun(); return; }
  R.killT -= dt; if (R.killT <= 0) { R.killT = 0.3; updateKillY(false); } if (P.y < P.killY) doFall();
  AU.wind(P.hs + Math.abs(Math.min(0, P.vy)) * 0.5, !P.onGround);
  updateShadow(rX, rY, rZ); updateCamera(dt);
  knife.update(dt, { hs: P.hs, onGround: P.onGround, vy: P.vy, bobPh: P.bobPh, crouch: false, slide: false, surf: P.surfT > 0 && !P.onGround, bob: S.bob, dyaw: P.yaw - prevYaw, dpitch: P.pitch - prevPitch }); prevYaw = P.yaw; prevPitch = P.pitch;
  updateHud();
}
let prevYaw = 0, prevPitch = 0;
function updateCamera(dt) {
  let sr = 0; if (P.surfT > 0 && !P.onGround) { const nR = P.surfNx * Math.cos(P.yaw) - P.surfNz * Math.sin(P.yaw); sr = clamp(-nR * 0.22, -0.2, 0.2); }
  surfRoll += (sr - surfRoll) * Math.min(1, dt * 7);
  const targetRoll = (S.tilt ? -IN.x * 0.035 * Math.min(1, P.hs / 6) + surfRoll : 0) + (S.bob ? P.bobR : 0) + (P.wallRun ? -P.wallNx * 0.12 - P.wallNz * 0.12 : 0);
  P.roll += (targetRoll - P.roll) * Math.min(1, dt * 8);
  const fxOn = S.speedFx && qualityParams().fx > 0, fxv = fxOn ? clamp((P.hs - 5) * 0.7, 0, 12) + (P.vy < -14 ? Math.min(6, (-P.vy - 14) * 0.3) : 0) : 0;
  P.fovX += (fxv - P.fovX) * Math.min(1, dt * 4); const f = S.fov + P.fovX; if (Math.abs(camera.fov - f) > 0.03) { camera.fov = f; camera.updateProjectionMatrix(); }
  const ey = rY + P.eye + (S.bob ? P.bobY + P.landY : 0), pit = P.pitch + (S.bob ? P.kick : 0);
  camera.position.set(rX, ey, rZ); camera.rotation.set(pit, P.yaw, P.roll, 'YXZ');
}
/* ---------- меню-камера / превью карты ---------- */
function bounds() { const pts = (W.rp || [W.START]).concat(W.branches || []); let x0 = 1e9, x1 = -1e9, z0 = 1e9, z1 = -1e9, y0 = 1e9, y1 = -1e9; pts.forEach(p => { x0 = Math.min(x0, p.x); x1 = Math.max(x1, p.x); z0 = Math.min(z0, p.z); z1 = Math.max(z1, p.z); y0 = Math.min(y0, p.y); y1 = Math.max(y1, p.y); }); return { cx: (x0 + x1) / 2, cz: (z0 + z1) / 2, cy: (y0 + y1) / 2, r: Math.max(30, Math.hypot(x1 - x0, z1 - z0) / 2), h: y1 - y0 }; }
function overview(ang, k) { const b = bounds(); camera.fov = 50; camera.updateProjectionMatrix(); const d = b.r * (k || 1.25) + 20; camera.position.set(b.cx + Math.sin(ang) * d, b.cy + b.r * 0.55 + b.h * .3 + 14, b.cz + Math.cos(ang) * d); camera.lookAt(b.cx, b.cy, b.cz); }
function menuCamera(dt) { orbitT += dt * 0.08; overview(orbitT + 0.6, 1.05); }
const thumbs = {}, thumbQ = []; let thumbBusy = false;
function thumb(id, host) {
  const attach = c => { const ld = host.querySelector('.ld'); if (ld) ld.remove(); const cv = document.createElement('canvas'); cv.width = 400; cv.height = 225; cv.getContext('2d').drawImage(c, 0, 0, 400, 225); host.prepend(cv); };
  if (thumbs[id]) { attach(thumbs[id]); return; } thumbQ.push({ id, attach }); if (!thumbBusy) runThumbs();
}
function runThumbs() {
  thumbBusy = true; const job = thumbQ.shift(); if (!job) { thumbBusy = false; return; }
  setTimeout(() => {
    try {
      if (!thumbs[job.id] && state !== 'play') {
        loadMap(job.id); prepareRoute(); applyQuality(); resize(); overview(0.7, 0.95); sky.position.copy(camera.position); renderer.render(scene, camera);
        const c = document.createElement('canvas'); c.width = 400; c.height = 225; const sw = canvas.width, sh = canvas.height, ar = 16 / 9; let w = sw, h = sw / ar; if (h > sh) { h = sh; w = sh * ar; } c.getContext('2d').drawImage(canvas, (sw - w) / 2, (sh - h) / 2, w, h, 0, 0, 400, 225); thumbs[job.id] = c;
      }
      if (thumbs[job.id]) job.attach(thumbs[job.id]);
    } catch (e) { console.error(e); }
    runThumbs();
  }, 30);
}
function openPreview(id) { previewId = id; if (W.id !== id) { loadMap(id); prepareRoute(); applyQuality(); } $('pvName').textContent = mapById(id).name; document.body.classList.add('previewing'); state = 'preview'; }
function closePreview() { document.body.classList.remove('previewing'); state = 'menu'; }

/* ---------- ввод ---------- */
const touchEl = $('touch'), hudEl = $('hud'), joyZone = $('joyZone'), joyBase = $('joyBase'), joyStick = $('joyStick'), lookZone = $('lookZone'), probe = $('safe');
function getInsets() { const cs = getComputedStyle(probe); return { l: parseFloat(cs.paddingLeft) || 0, r: parseFloat(cs.paddingRight) || 0, t: parseFloat(cs.paddingTop) || 0, b: parseFloat(cs.paddingBottom) || 0 }; }
const setJoyPos = (x, y) => { joyBase.style.transform = 'translate3d(' + x + 'px,' + y + 'px,0)'; };
function layoutJoy() {
  const w = innerWidth, h = innerHeight, res = applyLayout(w, h, getInsets());
  joy.size = res.joy.size; joy.R = joy.size * 0.42; joyBase.style.width = joyBase.style.height = joy.size + 'px';
  const st = joy.size * 0.44; joyStick.style.width = joyStick.style.height = st + 'px'; joyStick.style.marginLeft = joyStick.style.marginTop = (-st / 2) + 'px';
  joy.defX = res.joy.cx - joy.size / 2; joy.defY = res.joy.cy - joy.size / 2; joyZone.style.top = Math.max(0, Math.min(h * 0.28, res.joy.cy - joy.size * 0.9)) + 'px'; if (joy.id === null) setJoyPos(joy.defX, joy.defY);
}
function moveJoy(e) {
  let dx = e.clientX - joy.cx, dy = e.clientY - joy.cy; const len = Math.hypot(dx, dy); if (len > joy.R) { dx *= joy.R / len; dy *= joy.R / len; }
  joyStick.style.transform = 'translate3d(' + dx + 'px,' + dy + 'px,0)'; const mag = Math.min(1, len / joy.R), m2 = mag < 0.08 ? 0 : (mag - 0.08) / 0.92, dl = Math.hypot(dx, dy);
  if (dl > 0) { joy.x = dx / dl * m2; joy.y = -dy / dl * m2; } else { joy.x = joy.y = 0; }
}
function releaseJoy() { joy.id = null; joy.x = joy.y = 0; joyBase.classList.remove('active'); joyStick.style.transform = 'translate3d(0,0,0)'; setJoyPos(joy.defX, joy.defY); }
joyZone.addEventListener('pointerdown', e => { if (joy.id !== null || state !== 'play') return; e.preventDefault(); joy.id = e.pointerId; try { joyZone.setPointerCapture(e.pointerId); } catch (_) { /* */ } const half = joy.size / 2, zr = joyZone.clientWidth || innerWidth * 0.55; joy.cx = clamp(e.clientX, half + 8, Math.max(half + 8, zr - half)); joy.cy = clamp(e.clientY, half + 8, innerHeight - half - 8); setJoyPos(joy.cx - half, joy.cy - half); joyBase.classList.add('active'); moveJoy(e); });
joyZone.addEventListener('pointermove', e => { if (e.pointerId === joy.id) { e.preventDefault(); moveJoy(e); } });
['pointerup', 'pointercancel', 'lostpointercapture'].forEach(ev => joyZone.addEventListener(ev, e => { if (e.pointerId === joy.id) releaseJoy(); }));
// камера: свайпы накапливаются и «стекают» с плавностью и ускорением поворота (S.smooth, S.lookAccel)
const LOOK_K = 0.0042;
lookZone.addEventListener('pointerdown', e => { if (look.id !== null || state !== 'play') return; e.preventDefault(); look.id = e.pointerId; look.x = e.clientX; look.y = e.clientY; try { lookZone.setPointerCapture(e.pointerId); } catch (_) { /* */ } if (e.pointerType === 'mouse' && lookZone.requestPointerLock) { try { lookZone.requestPointerLock(); } catch (_) { /* */ } } });
lookZone.addEventListener('pointermove', e => { if (e.pointerId !== look.id || state !== 'play' || document.pointerLockElement) return; e.preventDefault(); const dx = e.clientX - look.x, dy = e.clientY - look.y; look.x = e.clientX; look.y = e.clientY; look.ax += dx; look.ay += dy; });
['pointerup', 'pointercancel', 'lostpointercapture'].forEach(ev => lookZone.addEventListener(ev, e => { if (e.pointerId === look.id) look.id = null; }));
document.addEventListener('mousemove', e => { if (document.pointerLockElement !== lookZone || state !== 'play') return; look.ax += e.movementX * 0.6; look.ay += e.movementY * 0.6; });
document.addEventListener('pointerlockchange', () => { if (!document.pointerLockElement && state === 'play') pauseGame(); });
function applyLook(dt) {
  if (!look.ax && !look.ay) return; const tc = Math.max(0.001, S.smooth * 0.12), k = S.smooth <= 0.01 ? 1 : 1 - Math.exp(-dt / tc);
  const dx = look.ax * k, dy = look.ay * k; look.ax -= dx; look.ay -= dy; if (Math.abs(look.ax) < 0.05) look.ax = 0; if (Math.abs(look.ay) < 0.05) look.ay = 0;
  const sp = Math.hypot(dx, dy) / Math.max(dt, 0.004), mul = S.sens * (1 + S.lookAccel * clamp(sp / 1400, 0, 1.2));
  P.yaw -= dx * LOOK_K * mul; P.pitch = clamp(P.pitch - dy * LOOK_K * mul * 0.9, -S.pitchLimit, S.pitchLimit);
}
function bindBtn(el, down, up) { el.addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); try { el.setPointerCapture(e.pointerId); } catch (_) { /* */ } el.classList.add('press'); if (down) down(); }); const end = () => { el.classList.remove('press'); if (up) up(); }; el.addEventListener('pointerup', end); el.addEventListener('pointercancel', end); }
function doSlash() { if (state === 'play' && S.knife && knife.swing()) AU.swing(); } function doInspect() { if (state === 'play' && S.knife && knife.inspect()) AU.inspect(); }
const pressJump = () => { if (state === 'play') { IN.jumpBuf = 0.13; IN.jumpHeld = true; } };
bindBtn($('bJump'), pressJump, () => { IN.jumpHeld = false; });
bindBtn($('bRun'), () => { if (state !== 'play') return; IN.run = !IN.run; $('bRun').classList.toggle('on', IN.run); });
bindBtn($('bSlash'), doSlash); bindBtn($('bLook'), doInspect);
function resetTouch() { releaseJoy(); look.id = null; look.ax = look.ay = 0; IN.jumpBuf = 0; IN.jumpHeld = false; IN.x = IN.y = 0; ['bJump', 'bRun', 'bSlash', 'bLook'].forEach(i => $(i).classList.remove('press')); }
window.addEventListener('keydown', e => {
  keys[e.code] = true; if (e.code === 'Space') { e.preventDefault(); pressJump(); } if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') IN.keyRun = true;
  if (e.code === 'KeyE' && !e.repeat) doSlash(); if (e.code === 'KeyF' && !e.repeat) doInspect();
  if (e.code === 'KeyR' && !e.repeat && (state === 'play' || state === 'pause' || state === 'result')) restartGame(true);
  if ((e.code === 'Escape' || e.code === 'KeyP') && !e.repeat) { if (state === 'play') pauseGame(); else if (state === 'pause') resumeGame(); }
});
window.addEventListener('keyup', e => { keys[e.code] = false; if (e.code === 'Space') IN.jumpHeld = false; if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') IN.keyRun = false; });
document.addEventListener('touchmove', e => { if (!e.target.closest || !e.target.closest('.panel,.mode-rail,.map-grid,.skin-items,.skin-side,.ranks-wrap')) e.preventDefault(); }, { passive: false });
['gesturestart', 'gesturechange', 'gestureend', 'contextmenu', 'selectstart', 'dragstart'].forEach(ev => document.addEventListener(ev, e => e.preventDefault()));

/* ---------- экраны ---------- */
const screens = {}; ['Main', 'Modes', 'Maps', 'Skins', 'Ranks', 'Settings', 'Controls', 'Stats', 'Ach', 'Pause', 'Result', 'RankUp'].forEach(n => { screens[n.toLowerCase()] = $('s' + n); });
let ctlFrom = 'main', setFrom = 'main'; let skinPrev = null;
function showScreen(n) {
  if (n !== 'skins') stopSkinPrev();
  Object.keys(screens).forEach(k => screens[k].classList.toggle('active', k === n));
  if (n === 'main') { UI.renderProfile(); refreshMenu(); } if (n === 'modes') UI.renderModes(cb); if (n === 'maps') UI.renderMaps(cb); if (n === 'ranks') UI.renderRanks();
  if (n === 'skins') { UI.renderSkins(cb); startSkinPrev(); } if (n === 'stats') UI.renderStats(); if (n === 'ach') UI.renderAch(); if (n === 'settings') UI.renderSettings(cb);
  if (n === 'pause') $('pInfo').textContent = mode().name + ' · ' + curMap.name; if (n && n !== 'result' && n !== 'rankup') AU.click();
}
function setLayers(t, h) { touchEl.classList.toggle('hidden', !t); hudEl.classList.toggle('hidden', !h); }
function refreshMenu() { const m = MODE_BY_ID[SEL.mode], mp = mapById(SEL.map); $('mPlaySub').textContent = mp && modeMaps(SEL.mode).some(x => x.id === mp.id) ? m.name + ' · ' + mp.name : 'ВЫБЕРИТЕ РЕЖИМ'; }
function goFullscreen() { const el = document.documentElement, rq = el.requestFullscreen || el.webkitRequestFullscreen; if (!rq) { toast('iPhone: «Поделиться» → «На экран Домой»', 3800); return false; } try { const p = rq.call(el); if (p && p.then) p.then(() => { try { screen.orientation.lock('landscape').catch(() => {}); } catch (e) { /* */ } }).catch(() => {}); } catch (e) { /* */ } return true; }
const isFs = () => !!(document.fullscreenElement || document.webkitFullscreenElement);
function toggleFs() { if (isFs()) { try { (document.exitFullscreen || document.webkitExitFullscreen).call(document); } catch (e) { /* */ } S.fs = false; } else S.fs = goFullscreen(); saveSettings(); }
function beginPlay() { state = 'play'; resetGame(); pend.attempts++; prevYaw = P.yaw; prevPitch = P.pitch; showScreen(null); setLayers(true, true); closePreviewSilent(); if (innerHeight > innerWidth) toast('Лучше играть в горизонтальном режиме', 2600); }
function closePreviewSilent() { document.body.classList.remove('previewing'); }
function startRun(modeId, mapId) {
  if (state === 'loading') return; const mp = mapById(mapId), sp = supports(modeId, mp); if (!sp.ok) { toast('✕ ' + sp.why, 3200); return; }
  runMode = modeId; SEL.mode = modeId; SEL.map = mapId; UI.persistSel(); AU.init(); AU.apply(); if (S.fs && !isFs()) goFullscreen();
  const needs = W.id !== mapId || W.decor !== qualityParams().decor;
  if (!needs) { beginPlay(); return; }
  state = 'loading'; const f = $('fade'); f.classList.add('dark', 'on');
  setTimeout(() => { try { loadAndPrepare(mapId); } catch (err) { console.error(err); toast('Не удалось загрузить карту', 3000); state = 'menu'; f.classList.remove('on', 'dark'); return; } beginPlay(); f.classList.remove('on'); setTimeout(() => f.classList.remove('dark'), 260); }, 320);
}
function pauseGame() { if (state !== 'play') return; flush(); state = 'pause'; resetTouch(); setLayers(false, true); showScreen('pause'); if (document.pointerLockElement) { try { document.exitPointerLock(); } catch (e) { /* */ } } }
function resumeGame() { state = 'play'; showScreen(null); setLayers(true, true); }
function restartGame(quick) { if (state === 'loading') return; flush(); state = 'play'; resetTouch(); resetGame(); pend.attempts++; showScreen(null); setLayers(true, true); if (!quick) toast('Рестарт', 800); }
function toMenuState(name) { flush(); state = 'menu'; resetTouch(); setLayers(false, false); closePreviewSilent(); showScreen(name); }
const cb = {
  goto: n => showScreen(n), start: startRun, preview: id => openPreview(id), thumb,
  skinChanged: () => { knife.applySkin(); if (skinPrev) skinPrev.k.applySkin(); }, toast, audio: () => AU.apply(), quality: () => { applyQuality(); }, isFs, fs: toggleFs,
  fovChanged: () => { camera.fov = S.fov; camera.updateProjectionMatrix(); }, knifeVis: () => document.body.classList.toggle('noknife', !S.knife), controls: () => openEditorFrom('settings')
};
function openEditorFrom(from) { ctlFrom = from; state = 'editor'; showScreen(null); setLayers(true, false); openEditor({ relayout: layoutJoy, getInsets, onClose: () => { state = 'menu'; showScreen(ctlFrom === 'pause' ? 'pause' : ctlFrom); if (ctlFrom === 'pause') state = 'pause'; }, toast }); }
document.querySelectorAll('[data-back]').forEach(b => { b.onclick = () => { if (b.dataset.back === 'modes' || b.dataset.back === 'main') { if (state === 'pause') { showScreen('pause'); return; } } showScreen(b.dataset.back); }; });
$('mPlay').onclick = () => { const l = modeMaps(SEL.mode), mp = mapById(SEL.map); if (mp && l.some(x => x.id === mp.id) && state === 'menu' && false) { startRun(SEL.mode, SEL.map); return; } showScreen('modes'); };
$('mSkins').onclick = () => showScreen('skins'); $('mRanks').onclick = () => showScreen('ranks'); $('mStats').onclick = () => showScreen('stats'); $('mAch').onclick = () => showScreen('ach');
$('mSettings').onclick = () => { setFrom = 'main'; showScreen('settings'); }; $('mControls').onclick = () => showScreen('controls'); $('fsMenuBtn').onclick = toggleFs;
$('setBack').onclick = () => { if (setFrom === 'pause') { state = 'pause'; showScreen('pause'); } else showScreen('main'); };
$('ctlBack').onclick = () => { if (ctlFrom === 'pause') showScreen('pause'); else showScreen('main'); }; $('ctlEdit').onclick = () => openEditorFrom('controls');
$('stBack').onclick = () => showScreen('main'); $('achBack').onclick = () => showScreen('main');
$('pResume').onclick = resumeGame; $('pRestart').onclick = () => restartGame(false); $('pSettings').onclick = () => { setFrom = 'pause'; showScreen('settings'); }; $('pControls').onclick = () => { ctlFrom = 'pause'; showScreen('controls'); };
$('pMaps').onclick = () => toMenuState('modes'); $('pMenu').onclick = () => toMenuState('main');
$('rAgain').onclick = () => restartGame(false); $('rNext').onclick = () => { const n = nextMap(); if (n) startRun(runMode, n.id); }; $('rMaps').onclick = () => toMenuState('maps'); $('rMenu').onclick = () => toMenuState('main');
$('pvExit').onclick = () => { closePreview(); showScreen('maps'); }; $('pvPlay').onclick = () => startRun(SEL.mode, previewId);
$('btnPause').addEventListener('pointerdown', e => { e.preventDefault(); pauseGame(); }); $('btnRestart').addEventListener('pointerdown', e => { e.preventDefault(); restartGame(true); });
document.addEventListener('fullscreenchange', () => setTimeout(resize, 150));

/* ---------- предпросмотр скинов (отдельный лёгкий рендерер) ---------- */
function startSkinPrev() {
  stopSkinPrev(); const cv = $('skinCv'), r = new THREE.WebGLRenderer({ canvas: cv, antialias: true, alpha: true }); r.setPixelRatio(Math.min(2, devicePixelRatio || 1)); const k = createKnife(); k.applySkin();
  skinPrev = { r, k, raf: 0, t: 0 }; let last = performance.now();
  const loop = now => { if (!skinPrev) return; skinPrev.raf = requestAnimationFrame(loop); const dt = Math.min(0.05, (now - last) / 1000); last = now; skinPrev.t += dt; const w = cv.clientWidth || 300, h = cv.clientHeight || 300; if (cv.width !== Math.round(w * r.getPixelRatio())) { r.setSize(w, h, false); k.setAspect(w / h); }
    k.update(dt, { hs: 6, onGround: true, vy: 0, bobPh: skinPrev.t * 3, crouch: false, slide: false, surf: false, bob: true, dyaw: Math.sin(skinPrev.t) * 0.02, dpitch: 0 }); if (Math.floor(skinPrev.t) % 6 === 4 && !k.busy()) k.inspect(); r.setClearColor(0x000000, 0); r.clear(); k.render(r); };
  skinPrev.raf = requestAnimationFrame(loop);
}
function stopSkinPrev() { if (!skinPrev) return; cancelAnimationFrame(skinPrev.raf); try { skinPrev.r.dispose(); skinPrev.r.forceContextLoss(); } catch (e) { /* */ } skinPrev = null; }

/* ---------- качество / resize / цикл ---------- */
function applyQuality() { coreApplyQuality(resize); }
function resize() { const w = innerWidth, h = innerHeight; renderer.setSize(w, h, false); canvas.style.width = w + 'px'; canvas.style.height = h + 'px'; camera.aspect = w / h; camera.updateProjectionMatrix(); knife.setAspect(w / h); layoutJoy(); }
window.addEventListener('resize', resize); window.addEventListener('orientationchange', () => setTimeout(resize, 250)); if (window.visualViewport) window.visualViewport.addEventListener('resize', resize);
let last = performance.now();
function frame(now) {
  requestAnimationFrame(frame); const dt = Math.min(0.05, (now - last) / 1000); last = now;
  if (state === 'play') updateGame(dt); else if (state === 'preview') { orbitT += dt * 0.1; overview(orbitT, 1.0); } else if (state === 'menu' || state === 'pause' || state === 'result' || state === 'loading' || state === 'editor') { if (state === 'menu') menuCamera(dt); }
  sky.position.copy(camera.position); sunSprite.position.copy(camera.position).addScaledVector(lightDir, 500);
  if (W.group) { for (let i = 0; i < PORTALS.length; i++) { const p = PORTALS[i]; p.swirl.rotation.z += dt * 2.4; if (p.g.userData.inner) p.g.userData.inner.rotation.z -= dt * 3; p.ring.scale.setScalar(1 + Math.sin(now / 300 + i) * 0.03); } }
  renderer.render(scene, camera); if (state === 'play' && S.knife) knife.render(renderer);
}
document.addEventListener('visibilitychange', () => { if (document.hidden && state === 'play') pauseGame(); }); window.addEventListener('blur', () => { if (state === 'play') pauseGame(); });
['pointerdown', 'touchstart'].forEach(ev => document.addEventListener(ev, () => AU.init(), { once: true, passive: true }));

/* ---------- init ---------- */
document.body.classList.toggle('noknife', !S.knife);
try { loadMap((mapById(SEL.map) && modeMaps(SEL.mode).some(m => m.id === SEL.map)) ? SEL.map : modeMaps(SEL.mode)[0].id); prepareRoute(); } catch (e) { console.error(e); }
applyQuality(); resize(); resetPlayer(W.START.x, W.START.y, W.START.z, 0); UI.renderProfile(); refreshMenu(); camera.fov = S.fov;
setTimeout(() => { const l = $('loading'); if (l) { l.classList.add('off'); setTimeout(() => l.remove(), 500); } }, 450);
requestAnimationFrame(t => { last = t; requestAnimationFrame(frame); });
window.__pk3d = { get state() { return state; }, get runMode() { return runMode; }, R, P, IN, SEL, CPS, W, PORTALS, startRun, restartGame, pauseGame, resumeGame, finishRun, showScreen, joy, rankState };
