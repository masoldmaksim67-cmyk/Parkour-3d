// Конструктор нелинейных маршрутов («черепашка»): повороты, развилки, вертикаль, мосты, лифты, wall-run, SURF-жёлоба и порталы.
// Курс yaw — непрерывный угол (0 = −Z, +90° по часовой = +X). Платформы выравниваются по ближайшему кардинальному направлению.
import { THREE, W, box, solid, cyl, obb, addCol, mover, cp, rnd, add, crate, makeGround, makeClouds } from './core.js';
import { PORTALS } from './collision.js';
import { troughSlabs } from './surfgeo.js';

const HP = Math.PI / 2;
export class Turtle {
  constructor(x, y, z, yawDeg) {
    this.x = x; this.y = y; this.z = z; this.yaw = -(yawDeg || 0) * Math.PI / 180; this.stack = []; this.branch = 0; this.painter = null; this.last = null;
    W.route = []; W.branches = [];
  }
  get dx() { return -Math.sin(this.yaw); } get dz() { return -Math.cos(this.yaw); }
  get card() { return ((Math.round(-this.yaw / HP) % 4) + 4) % 4; }
  snap() { this.yaw = Math.round(this.yaw / HP) * HP; return this; }
  turn(n) { this.yaw -= n * HP; return this; }
  face(deg) { this.yaw = -deg * Math.PI / 180; return this; }
  at(x, y, z) { this.x = x; this.y = y; this.z = z; return this; }
  push() { this.stack.push({ x: this.x, y: this.y, z: this.z, yaw: this.yaw, last: this.last }); this.branch++; return this; }
  pop() { const s = this.stack.pop(); this.x = s.x; this.y = s.y; this.z = s.z; this.yaw = s.yaw; this.last = s.last; this.branch--; return this; }
  shift(s) { this.x += -this.dz * s; this.z += this.dx * s; return this; }
  fwd(d) { this.x += this.dx * d; this.z += this.dz * d; return this; }
  rec(r) { this.last = r; (this.branch ? W.branches : W.route).push({ x: r.x, y: r.y, z: r.z }); return r; }
  // платформа: gap — зазор от текущего края, dy — перепад, w — поперёк, d — вдоль, side — смещение вправо
  go(gap, dy, w, d, side, o) {
    this.snap();
    side = side || 0; const dx = this.dx, dz = this.dz, rx = -dz, rz = dx, hd = gap + d / 2;
    const cx = this.x + dx * hd + rx * side, cz = this.z + dz * hd + rz * side, cy = this.y + dy, ns = this.card % 2 === 0;
    const r = this.painter(cx, cy, cz, ns ? w : d, ns ? d : w, o || {});
    this.x = cx + dx * d / 2; this.z = cz + dz * d / 2; this.y = cy;
    return this.rec(r);
  }
  span(len, width, key, tint, o) {
    this.snap();
    o = o || {}; const ns = this.card % 2 === 0, dx = this.dx, dz = this.dz, y = this.y;
    const cx = this.x + dx * len / 2, cz = this.z + dz * len / 2, hw = (ns ? width : len) / 2, hd = (ns ? len : width) / 2, th = o.th || .5;
    box(cx - hw, y - th, cz - hd, cx + hw, y, cz + hd, key || 'beam', key || 'beam', tint);
    const col = addCol(cx - hw, y - th, cz - hd, cx + hw, y, cz + hd);
    if (o.rails) [-1, 1].forEach(s => { const ox = ns ? s * (width / 2 - .05) : 0, oz = ns ? 0 : s * (width / 2 - .05); box(cx + ox - (ns ? .05 : hw), y, cz + oz - (ns ? hd : .05), cx + ox + (ns ? .05 : hw), y + .9, cz + oz + (ns ? hd : .05), 'metal', 'metal', o.railTint || 0x4a525a); });
    if (o.ribs !== false) for (let t = 3; t < len - 1; t += 4) { const px = this.x + dx * t, pz = this.z + dz * t; box(px - (ns ? width / 2 + .1 : .1), y - th - .2, pz - (ns ? .1 : width / 2 + .1), px + (ns ? width / 2 + .1 : .1), y - th, pz + (ns ? .1 : width / 2 + .1), 'metal', 'metal', 0x555d65); }
    this.x += dx * len; this.z += dz * len; return this.rec({ x: cx, y, z: cz, w: hw * 2, d: hd * 2, col });
  }
  pipe(len, r, tint) {
    this.snap();
    const ns = this.card % 2 === 0, dx = this.dx, dz = this.dz, y = this.y, cx = this.x + dx * len / 2, cz = this.z + dz * len / 2;
    cyl('metal', tint || 0x8fa3b0, cx, y - r, cz, r, r, len, ns ? 'z' : 'x', 14);
    for (let t = 2; t < len - 1; t += 3.5) cyl('plain', 0x39424a, this.x + dx * t, y - r, this.z + dz * t, r + .06, r + .06, .14, ns ? 'z' : 'x', 14);
    const col = addCol(cx - (ns ? r * .85 : len / 2), y - 2 * r, cz - (ns ? len / 2 : r * .85), cx + (ns ? r * .85 : len / 2), y, cz + (ns ? len / 2 : r * .85));
    this.x += dx * len; this.z += dz * len; return this.rec({ x: cx, y, z: cz, w: 1, d: len, col });
  }
  // проходимый склон (угол < 45°)
  ramp(len, rise, w, key, tint) {
    const pitch = Math.atan2(rise, len), L = Math.hypot(len, rise), dx = this.dx, dz = this.dz, hy = .35;
    const cx = this.x + dx * len / 2, cz = this.z + dz * len / 2, cy = this.y + rise / 2 - hy * Math.cos(pitch);
    obb(cx, cy, cz, w / 2, hy, L / 2, pitch, this.yaw, 0, key || 'concrete', tint);
    this.x += dx * len; this.z += dz * len; this.y += rise; return { x: cx, y: this.y, z: cz };
  }
  movingBridge(gap, size, period, tint) {
    this.snap();
    const dx = this.dx, dz = this.dz, ns = this.card % 2 === 0, y = this.y, a = .3 + size / 2, b = gap - .3 - size / 2;
    mover(this.x + dx * a, y, this.z + dz * a, ns ? 5 : size, ns ? size : 5, this.x + dx * b, y, this.z + dz * b, period, 0, tint); return this;
  }
  movingChain(n, size, gap, amp, period, tint) {
    this.snap();
    const rx = -this.dz, rz = this.dx; let e = 0;
    for (let i = 0; i < n; i++) {
      const hd = e + gap + size / 2, cx = this.x + this.dx * hd, cz = this.z + this.dz * hd;
      mover(cx - rx * amp, this.y, cz - rz * amp, size, size, cx + rx * amp, this.y, cz + rz * amp, period, i % 2 ? Math.PI : 0, tint); e = hd + size / 2;
    }
    this.fwd(e); return this;
  }
  lift(rise, period, tint) {
    this.snap(); const gap = 4.6, cx = this.x + this.dx * gap / 2, cz = this.z + this.dz * gap / 2; mover(cx, this.y, cz, 4.4, 4.4, cx, this.y + rise, cz, period, 0, tint); return gap; }
  // коридор wall-run без пола: две высокие стены по бокам зазора
  wallRun(len, width, h, key, tint) {
    this.snap();
    const ns = this.card % 2 === 0, dx = this.dx, dz = this.dz, rx = -dz, rz = dx, y = this.y, cx = this.x + dx * len / 2, cz = this.z + dz * len / 2;
    [-1, 1].forEach(s => {
      const wx = cx + rx * s * (width / 2 + .4), wz = cz + rz * s * (width / 2 + .4), hw = ns ? .4 : len / 2, hd = ns ? len / 2 : .4;
      solid(wx - hw, y - 3, wz - hd, wx + hw, y + h, wz + hd, key || 'brick', tint === undefined ? 0xffffff : tint, key || 'brick');
    });
    this.x += dx * len; this.z += dz * len; return this.rec({ x: cx, y, z: cz, w: width, d: len, col: null });
  }
  // SURF: сегмент V-жёлоба; после сегмента yaw += dyaw (рад); pitch < 0 — спуск
  trough(L, dyaw, pitch, o) {
    o = Object.assign({ th: 0.95, w: 16, key: 'surf', tintL: 0x4fd8ff, tintR: 0xff8a3c, pillars: false }, o || {});
    const yw = this.yaw + (dyaw || 0) / 2, t = troughSlabs(this.x, this.y, this.z, yw, pitch, L, o);
    t.slabs.forEach(s => { obb(s.cx, s.cy, s.cz, s.hx, s.hy, s.hz, s.rx, s.ry, s.rz, o.key, s.side > 0 ? o.tintR : o.tintL); });
    if (o.pillars) { const n = Math.max(1, Math.round(L / 14)); for (let i = 0; i < n; i++) { const k = (i + .5) / n, px = this.x + (t.end[0] - this.x) * k, py = this.y + (t.end[1] - this.y) * k - 1.2, pz = this.z + (t.end[2] - this.z) * k; box(px - .6, W.groundY, pz - .6, px + .6, py, pz + .6, 'metal', 'metal', 0x5b646d); } }
    this.x = t.end[0]; this.y = t.end[1]; this.z = t.end[2]; this.yaw += dyaw || 0;
    (this.branch ? W.branches : W.route).push({ x: this.x, y: this.y, z: this.z }); return this;
  }
  // дуга из сегментов: angleDeg — суммарный поворот (+ вправо)
  arc(angleDeg, len, pitch, o) {
    const a = angleDeg * Math.PI / 180, n = Math.max(2, Math.ceil(Math.abs(angleDeg) / 7)), da = -a / n;
    for (let i = 0; i < n; i++) this.trough(len / n, da, pitch, o);
    return this;
  }
  // параллельная полоса: L — общая длина от края, specs: [w, d, dy, shift, opts]; зазоры распределяются поровну. keep=true — маршрут продолжается с конца полосы
  lane(L, specs, side, keep) {
    if (!keep) this.push();
    let sd = 0; specs.forEach(s => { sd += s[1]; }); const g = Math.max(1.5, (L - sd) / specs.length);
    specs.forEach((s, i) => { this.go(g, s[2] || 0, s[0], s[1], (i === 0 ? side || 0 : 0) + (s[3] || 0), s[4]); });
    if (!keep) this.pop(); return this;
  }
  get deg() { return -this.yaw * 180 / Math.PI; }
  cp(r, xo) { cp(r || this.last, 0, xo || 0); return this; }
}

/* ---------- декор ---------- */
export function ringMesh(x, y, z, r, color, rotY, tube) {
  const m = new THREE.Mesh(new THREE.TorusGeometry(r, tube || .35, 8, 36), new THREE.MeshBasicMaterial({ color })); m.position.set(x, y, z); m.rotation.y = rotY || 0; add(m); return m;
}
export function pillar(x, z, y0, y1, r, key, tint) { cyl(key || 'concrete', tint === undefined ? 0xdddddd : tint, x, (y0 + y1) / 2, z, r, r, y1 - y0, 'y', 10); }
export function lamp(x, y, z, color, h) { h = h || 3; cyl('metal', 0x333a40, x, y + h / 2, z, .08, .1, h, 'y', 6); box(x - .25, y + h, z - .25, x + .25, y + h + .15, z + .25, 'neon', 'neon', color); }
export function neonStrip(x0, y, z0, x1, z1, color, t) { t = t || .09; box(Math.min(x0, x1) - t, y, Math.min(z0, z1) - t, Math.max(x0, x1) + t, y + t * 2, Math.max(z0, z1) + t, 'neon', 'neon', color); }
export function railAround(r, h, tint) {
  const x0 = r.x - r.w / 2, x1 = r.x + r.w / 2, z0 = r.z - r.d / 2, z1 = r.z + r.d / 2, t = .06, y = r.y;
  box(x0, y + h, z0, x1, y + h + t, z0 + t, 'metal', 'metal', tint); box(x0, y + h, z1 - t, x1, y + h + t, z1, 'metal', 'metal', tint);
  box(x0, y + h, z0, x0 + t, y + h + t, z1, 'metal', 'metal', tint); box(x1 - t, y + h, z0, x1, y + h + t, z1, 'metal', 'metal', tint);
}
// фоновые здания/объекты вокруг маршрута (дальше minD от любой точки маршрута)
export function scatter(o) {
  const pts = W.route.concat(W.branches || []); if (!pts.length) return;
  let x0 = 1e9, x1 = -1e9, z0 = 1e9, z1 = -1e9; pts.forEach(p => { x0 = Math.min(x0, p.x); x1 = Math.max(x1, p.x); z0 = Math.min(z0, p.z); z1 = Math.max(z1, p.z); });
  const m = o.span || 90, n = Math.round((o.n || 60) * (W.decor === undefined ? 1 : W.decor));
  for (let i = 0, tries = 0; i < n && tries < n * 14; tries++) {
    const x = x0 - m + rnd() * (x1 - x0 + 2 * m), z = z0 - m + rnd() * (z1 - z0 + 2 * m);
    let ok = true; for (let k = 0; k < pts.length; k++) { if (Math.hypot(pts[k].x - x, pts[k].z - z) < (o.minD || 30)) { ok = false; break; } } if (!ok) continue;
    i++; const w = (o.w0 || 10) + rnd() * (o.w1 || 18), d = (o.w0 || 10) + rnd() * (o.w1 || 18), top = (o.hMin || 5) + Math.pow(rnd(), o.pow || 1.6) * ((o.hMax || 80) - (o.hMin || 5)), t = o.tints ? o.tints[(rnd() * o.tints.length) | 0] : 0xffffff;
    if (o.fn) { o.fn(x, z, w, d, top, t); continue; }
    box(x - w / 2, W.groundY, z - d / 2, x + w / 2, top, z + d / 2, o.side || 'facade', o.top || 'roof', t);
    if (o.neon && rnd() < .4) box(x - w / 2 - .1, top - 1.2, z + d / 2 - .1, x + w / 2 + .1, top, z + d / 2 + .1, 'neon', 'neon', o.neon[(rnd() * o.neon.length) | 0]);
    if (o.cap && rnd() < .5) cyl('metal', 0x555b60, x, top + 3, z, .1, .15, 6, 'y', 5);
  }
}
export function finishAndGround(y, color, tex, clouds) {
  let cz = 0; const pts = W.route; pts.forEach(p => { cz += p.z; }); W.end = pts.length ? cz / pts.length * 2 : 0;
  makeGround(y, color, tex); if (clouds) makeClouds.apply(null, clouds);
}
export { crate };

/* ---------- порталы ---------- */
// from: {x,y,z,yaw?} вход, to: {x,y,z,yaw} выход (градусы, 0 = −Z). kind: 'ring' | 'floor'
export function portal(from, to, o) {
  o = Object.assign({ kind: 'ring', color: 0x7a5cff, color2: 0x3de0ff, r: 2.1, keep: true, secret: false }, o || {});
  const g = new THREE.Group(); g.position.set(from.x, from.y, from.z); add(g);
  const mk = c => new THREE.MeshBasicMaterial({ color: c, transparent: true, opacity: .55, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide });
  let swirl, ring; const ry = -(from.yaw || 0) * Math.PI / 180;
  if (o.kind === 'ring') {
    ring = new THREE.Mesh(new THREE.TorusGeometry(o.r, .22, 10, 40), new THREE.MeshBasicMaterial({ color: o.color2 })); ring.position.y = o.r + .2; ring.rotation.y = ry; g.add(ring);
    swirl = new THREE.Mesh(new THREE.CircleGeometry(o.r - .1, 32), mk(o.color)); swirl.position.copy(ring.position); swirl.rotation.y = ry; g.add(swirl);
    const inner = new THREE.Mesh(new THREE.TorusGeometry(o.r * .6, .12, 8, 30), mk(o.color2)); inner.position.copy(ring.position); inner.rotation.y = ry; g.add(inner); g.userData.inner = inner;
    [-1, 1].forEach(s => cyl('metal', 0x2a3038, from.x + Math.cos(ry) * s * (o.r + .4), from.y + .6, from.z - Math.sin(ry) * s * (o.r + .4), .2, .26, 1.2, 'y', 8));
  } else {
    ring = new THREE.Mesh(new THREE.RingGeometry(o.r * .85, o.r, 40), new THREE.MeshBasicMaterial({ color: o.color2, side: THREE.DoubleSide })); ring.rotation.x = -Math.PI / 2; ring.position.y = .06; g.add(ring);
    swirl = new THREE.Mesh(new THREE.CircleGeometry(o.r * .85, 32), mk(o.color)); swirl.rotation.x = -Math.PI / 2; swirl.position.y = .07; g.add(swirl);
    const bm = new THREE.Mesh(new THREE.CylinderGeometry(o.r * .8, o.r * .8, 6, 24, 1, true), mk(o.color)); bm.position.y = 3; bm.material.opacity = .22; g.add(bm);
  }
  const p = { x: from.x, y: from.y + (o.kind === 'ring' ? o.r + .2 : .9), z: from.z, fy: from.y, r: o.kind === 'ring' ? o.r * .95 : o.r * .85, kind: o.kind, to, keep: o.keep, boost: o.boost || 0, g, swirl, ring, name: o.name || '', secret: o.secret, fromYaw: from.yaw || 0 };
  PORTALS.push(p);
  const ex = new THREE.Mesh(new THREE.RingGeometry(1.3, 1.7, 32), new THREE.MeshBasicMaterial({ color: o.color2, transparent: true, opacity: .8, side: THREE.DoubleSide })); ex.rotation.x = -Math.PI / 2; ex.position.set(to.x, to.y + .05, to.z); add(ex);
  return p;
}
