// BHOP-карты: серии площадок с растущими зазорами. Зазор считается из ожидаемой скорости (дальность прыжка ≈ 0.66·v), поэтому обычным бегом
// (6.8 м/с ≈ 4.5 м) их не пройти — нужен разгон Bunny Hop и Air Strafe.
import { W, box, solid, cyl, crate, ac, vent, tank, sign, buildFinish, rnd, add, addCol } from './core.js';
import { Turtle, portal, scatter, finishAndGround, ringMesh, pillar, lamp, neonStrip } from './track.js';
import { tower, deck, slab, NEON, PAL } from './painters.js';

// n площадок size×size, ожидаемая скорость растёт v0→v1, lat — боковые смещения (зигзаг), rise — подъём на площадку
function hops(T, n, size, v0, v1, lat, rise, o) {
  let r;
  for (let i = 0; i < n; i++) {
    const v = v0 + (v1 - v0) * (n > 1 ? i / (n - 1) : 0), l = lat[i % lat.length] || 0, up = typeof rise === 'function' ? rise(i) : (rise || 0);
    let g = 0.66 * v - size - Math.max(0, up) * 1.4 + Math.min(0, up) * .3; g = Math.max(2.2, Math.min(9.2, g));
    g = Math.sqrt(Math.max(1, g * g - l * l)); // боковое смещение входит в дальность
    r = T.go(g, up, size, size, l, Object.assign({ pad: true, noProps: true }, o));
  }
  return r;
}
export { hops };

/* ============================ BHOP CLASSIC ============================ */
export function buildBhop() {
  W.groundY = -70; W.START = { x: 0, y: 40, z: 3, yaw: 0 };
  tower(0, 40, 0, 16, 16, { noProps: true }); sign(0, 46.5, 7.6, 9, 3.4, 'BHOP CLASSIC', '#ff2fd0'); ac(-5.5, 40, -3.5); vent(5.8, 40, -4); tank(5.4, 40, 4.5);
  const T = new Turtle(0, 40, -8, 0); T.painter = tower; let r;
  r = T.go(3, 0, 9, 52, 0, { noProps: true }); T.cp(r);                       // длинный разгон
  r = hops(T, 8, 3.6, 7.5, 11, [0]); r = T.go(4, 0, 12, 12); T.cp(r);
  T.turn(1); T.go(3, 0, 8, 36, 0, { noProps: true });                          // поворот вправо и разгон
  r = hops(T, 10, 3.2, 8, 12.5, [2.6, -2.6]); r = T.go(4, 0, 12, 12); T.cp(r);
  T.turn(-1); r = T.go(3.2, 0, 8, 42, 0, { noProps: true });
  r = hops(T, 7, 3.2, 8.5, 12, [3, 3, -3, -3, 0]); r = T.go(4, -.5, 14, 14); T.cp(r);
  T.turn(-1); r = T.go(3, 0, 8, 46, 0, { noProps: true }); T.cp(r);
  r = hops(T, 12, 3, 9, 14, [2.4, -2.4, 0, -2.4, 2.4, 0], (i) => (i % 4 === 3 ? .6 : (i % 4 === 1 ? -.6 : 0)));
  r = T.go(4.5, 0, 12, 12); T.cp(r);
  T.turn(1); r = T.go(3, 0, 9, 30, 0, { noProps: true });
  r = hops(T, 9, 2.8, 10, 14.5, [2.2, -2.2, 0]); r = T.go(4.5, 0, 22, 24, 0, { noProps: true }); buildFinish(r);
  scatter({ side: 'nfacade', top: 'roof', tints: [0xffffff], hMax: 120, n: 70, minD: 28, neon: NEON, cap: true });
  finishAndGround(-70, 0x0b0d18, false);
}

/* ============================ BHOP TOWER (вертикальная) ============================ */
export function buildTowerBhop() {
  W.groundY = -60; W.killDrop = 30; W.START = { x: 0, y: 30, z: 3, yaw: 0 };
  tower(0, 30, 0, 14, 14, { noProps: true });
  const T = new Turtle(0, 30, -7, 0); T.painter = tower; let r; const lands = [];
  // подъём по спирали: стороны по 5 площадок, площадки лифтятся на 0.9 м; на углах — большие площадки с чекпоинтами
  for (let side = 0; side < 8; side++) {
    r = hops(T, 5, 3.4, 8, 9.5 + side * .6, [side % 2 ? 2 : -2, 0], .9);
    r = T.go(3.4, .6, 11, 11); if (side % 2) T.cp(r); lands.push(r); T.turn(1);
  }
  const top = T.last;
  // спуск с прыжками вниз: длинные зазоры
  T.turn(1);
  r = hops(T, 6, 3.4, 11, 13, [3, -3], -1.4); r = T.go(4, -1, 12, 12); T.cp(r);
  T.turn(1); r = hops(T, 6, 3.2, 11.5, 14, [-2.6, 2.6], -1.4); r = T.go(4, -1, 12, 12); T.cp(r);
  T.turn(1); r = hops(T, 5, 3, 12, 14.5, [2.4, -2.4], -1.2); r = T.go(4.5, -1, 22, 24, 0, { noProps: true }); buildFinish(r);
  // центральная колонна и кольца
  const mid = lands[3], cx = lands[0].x, cz = lands[1].z;
  void mid; const ytop = top.y + 6;
  cyl('concrete', 0xb8bcc4, cx + 8, (W.groundY + ytop) / 2, cz - 8, 5, 6, ytop - W.groundY, 'y', 16);
  for (let y = 30; y < ytop; y += 9) ringMesh(cx + 8, y, cz - 8, 6.4, NEON[((y / 9) | 0) % 4], 0, .12).rotation.x = Math.PI / 2;
  // портал-шорткат: с 3-й площадки спирали сразу на верхний ярус
  portal({ x: lands[2].x, y: lands[2].y, z: lands[2].z }, { x: lands[5].x, y: lands[5].y, z: lands[5].z, yaw: 90 * 6 }, { kind: 'floor', color: 0xff2fd0, color2: 0x00e5ff, name: 'БАШЕННЫЙ ПОРТАЛ' });
  scatter({ side: 'nfacade', top: 'roof', tints: [0xffffff], hMax: 100, n: 54, minD: 34, neon: NEON });
  finishAndGround(-60, 0x0b0d18, false, [14, 80, 140, .5, 1]);
}

/* ============================ BHOP INDUSTRIAL ============================ */
export function buildBhopIndustrial() {
  W.groundY = -50; W.START = { x: 0, y: 18, z: 3, yaw: 0 };
  deck(0, 18, 0, 18, 18, { noProps: true }); tank(6.2, 18, 5.2); solid(-7.4, 18, .5, -4.8, 20.6, 6.5, 'container', 0xd68910);
  const T = new Turtle(0, 18, -9, 0); T.painter = deck; let r;
  T.pipe(28, .7); r = T.go(0, 0, 10, 12, 0, { noProps: true }); T.cp(r);                            // трубопровод-разгон
  r = hops(T, 7, 3, 8, 11, [2.2, -2.2], 0, { pad: false }); r = T.go(4, 0, 12, 12, 0, { noProps: true }); T.cp(r);
  T.turn(1); T.span(24, 1.8, 'rust', 0xffffff, { rails: true }); r = T.go(0, 0, 8, 8);
  r = hops(T, 8, 2.8, 9, 12.5, [-2.6, 2.6], 0, { pad: false }); r = T.go(4, 0, 14, 14, 0, { noProps: true }); T.cp(r);
  T.turn(-1); T.movingChain(3, 3.6, 3, 3.8, 4.2); r = T.go(3, 0, 8, 22, 0, { noProps: true });
  r = hops(T, 9, 2.8, 9.5, 13, [2.4, 0, -2.4, 0], (i) => (i === 3 ? .8 : i === 6 ? -.8 : 0), { pad: false }); r = T.go(4, 0, 12, 12); T.cp(r);
  T.turn(-1); T.pipe(22, .6); r = T.go(0, 0, 8, 8);
  r = hops(T, 10, 2.6, 10, 14, [2, -2, 2, -2, 0], 0, { pad: false });
  r = T.go(4.5, 0, 22, 24, 0, { noProps: true }); buildFinish(r); tank(r.x + 8, r.y, r.z + 8);
  scatter({ side: 'brick', top: 'roof', tints: [0xffffff, 0xe0cfc0, 0xc9c0b8], hMax: 45, n: 56, minD: 26, fn: (x, z, w, d, top, t) => {
    box(x - w / 2, W.groundY, z - d / 2, x + w / 2, top, z + d / 2, rnd() < .5 ? 'rust' : 'brick', 'roof', t);
    if (rnd() < .55) { const h = 25 + rnd() * 30; cyl('brick', 0xe6d6c6, x, top + h / 2, z, 1.6, 2.3, h, 'y', 10); }
  } });
  finishAndGround(-50, 0x3a3228, true, [14, 90, 150, .5, 1]);
}

/* ============================ BHOP NEON GRID ============================ */
export function buildBhopNeon() {
  W.groundY = -60; W.START = { x: 0, y: 24, z: 3, yaw: 0 };
  tower(0, 24, 0, 16, 16, { noProps: true }); sign(0, 30.5, 7.6, 10, 3.4, 'BHOP NEON', '#00e5ff');
  const T = new Turtle(0, 24, -8, 0); T.painter = tower; let r;
  // змейка: каждый отрезок — поворот на 90° через неоновую площадку
  const legs = [[8, 3.4, 8, 11, 2.4], [9, 3.2, 9, 12.4, 2.8], [10, 3, 9.5, 13.5, 3], [10, 3, 10, 14, 3.2], [11, 2.8, 10.5, 14.5, 3.4], [8, 2.8, 11, 14.8, 3.4]];
  legs.forEach((L, k) => {
    r = T.go(3.5, 0, 9, 22, 0, { noProps: true }); if (k % 2 === 0) T.cp(r);
    r = hops(T, L[0], L[1], L[2], L[3], [L[4], -L[4], 0, -L[4], L[4]], (i) => (k % 2 === 1 && i % 5 === 4 ? -.7 : 0));
    r = T.go(4, 0, 11, 11); T.turn(k % 2 ? -1 : 1);
    ringMesh(r.x, r.y + 7, r.z, 5, NEON[k % 4], 0, .18);
  });
  r = T.go(3.4, 0, 22, 24, 0, { noProps: true }); buildFinish(r);
  scatter({ side: 'nfacade', top: 'roof', tints: [0xffffff], hMax: 110, n: 80, minD: 26, neon: NEON, cap: true });
  finishAndGround(-60, 0x070914, false);
}
