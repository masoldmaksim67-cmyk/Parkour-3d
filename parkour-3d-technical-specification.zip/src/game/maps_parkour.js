// PARKOUR-карты: нелинейные маршруты с поворотами, развилками (параллельные полосы), вертикалью, мостами, подвижными платформами и порталами.
import { THREE, W, box, solid, cyl, crate, ac, vent, tank, antenna, skylight, shed, billboard, sign, buildFinish, rnd, add, addCol, obb } from './core.js';
import { Turtle, portal, scatter, finishAndGround, ringMesh, pillar, lamp, railAround, neonStrip } from './track.js';
import { cityRoof, deck, nightRoof, island, slab, skyRing, crane, CTN, NEON, PAL } from './painters.js';

const pick = a => a[(rnd() * a.length) | 0];
// арена для «чистого» паркура: бетонные плиты с цветной кромкой
function arena(x, y, z, w, d, o) {
  o = o || {}; const x0 = x - w / 2, x1 = x + w / 2, z0 = z - d / 2, z1 = z + d / 2, c = o.edge || 0xff9f1c;
  box(x0, y - 1.3, z0, x1, y, z1, 'concrete', 'concrete', o.tint || 0xd2d5d8);
  box(x0 - .1, y, z0 - .1, x1 + .1, y + .06, z0 + .3, 'neon', 'neon', c); box(x0 - .1, y, z1 - .3, x1 + .1, y + .06, z1 + .1, 'neon', 'neon', c);
  if (w > 7) { pillar(x0 + 1.2, z0 + 1.2, W.groundY, y - 1.3, .5, 'concrete', 0xb9bdc0); pillar(x1 - 1.2, z1 - 1.2, W.groundY, y - 1.3, .5, 'concrete', 0xb9bdc0); }
  return { x, y, z, w, d, col: addCol(x0, y - 1.3, z0, x1, y, z1) };
}
export { arena };

/* ============================ 1. CITY ROOFTOPS ============================ */
export function buildCity() {
  W.groundY = -70; W.START = { x: 0, y: 20, z: 3, yaw: 0 };
  cityRoof(0, 20, 0, 16, 16, { noProps: true }); shed(-5.2, 20, 5.2, 4, 4, 3); tank(5.4, 20, 5.2); ac(-5.6, 20, -3.5); vent(5.8, 20, -4); billboard(0, 20, 7.4, 6, 3);
  const T = new Turtle(0, 20, -8, 0); T.painter = cityRoof; let r;
  r = T.go(2.5, 0, 12, 14, 0, { noProps: true }); crate(r.x - 2.2, r.y, r.z, 1.2); crate(r.x + 2.4, r.y, r.z - 1, 1.3);
  r = T.go(3.2, .5, 10, 12, 2); r = T.go(3.5, 0, 12, 12, -2); T.cp(r);
  T.span(13, 1.6, 'beam'); r = T.go(0, 0, 10, 10);
  r = T.go(3, 0, 9, 8); T.pipe(13, .55); r = T.go(0, 0, 12, 12); T.cp(r);
  T.turn(1);
  r = T.go(3, 0, 12, 14, 0, { noProps: true }); solid(r.x - 1, r.y, r.z - 1, r.x + 1, r.y + .95, r.z + 1, 'crate', 0xffffff); // барьер для vault
  [[3, .9, 9, 9, 0], [3.2, .9, 8, 8, 2.4], [3.2, .9, 8, 8, -2.4], [3, .9, 12, 12, 0]].forEach(s => { r = T.go(s[0], s[1], s[2], s[3], s[4]); }); T.cp(r);
  T.turn(-1);
  r = T.go(3, 0, 30, 10, 0, { noProps: true }); ac(r.x - 12, r.y, r.z); tank(r.x + 12, r.y, r.z);
  T.lane(44, [[4, 4, .5], [4, 4, .5], [4, 4, -.5], [4, 4, -.5], [4, 4, 0], [4, 4, 0]], -11);
  T.lane(44, [[6, 5, 0], [6, 5, 1], [6, 5, -1], [6, 5, 1], [6, 5, -1]], 11);
  T.lane(44, [[10, 8], [8, 8], [10, 8], [8, 8]], 0, true);
  r = T.go(3, 0, 30, 14, 0, { noProps: true }); T.cp(r);
  T.turn(1);
  r = T.go(3.4, -.4, 10, 10); r = T.go(4, 0, 7, 7, 1.5); r = T.go(4.2, 0, 7, 7, -1.5); T.span(12, 1.0, 'beam'); r = T.go(0, 0, 10, 10); T.cp(r);
  T.turn(-1);
  r = T.go(3, .8, 12, 12); r = T.go(3.2, .8, 10, 10, 2); r = T.go(3.4, .6, 8, 8, -2); T.span(10, 1.4, 'beam'); r = T.go(0, 0, 22, 24, 0, { noProps: true }); buildFinish(r); tank(r.x + 8, r.y, r.z + 8); ac(r.x - 8.5, r.y, r.z + 7);
  scatter({ side: 'facade', top: 'roof', tints: PAL, hMax: 110, n: 70, minD: 26, cap: true });
  finishAndGround(-70, 0x5d636a, true, [18, 110, 180, .8, 1]);
}

/* ============================ 2. INDUSTRIAL ZONE ============================ */
export function buildIndustrial() {
  W.groundY = -50; W.START = { x: 0, y: 16, z: 3, yaw: 0 };
  deck(0, 16, 0, 18, 18, { noProps: true }); solid(-7.4, 16, .5, -4.8, 18.6, 6.5, 'container', 0xc0392b); tank(6.2, 16, 5.2); vent(6, 16, -4.5); crate(-6.4, 16, -5, 1.3);
  const T = new Turtle(0, 16, -9, 0); T.painter = deck; let r;
  r = T.go(2.5, 0, 10, 14, 0, { noProps: true }); solid(r.x - 3, r.y, r.z - 1, r.x - .5, r.y + 2.2, r.z + 1, 'container', 0x2e86c1);
  r = T.go(3.2, .6, 9, 10, 2); r = T.go(3.5, 0, 12, 12); T.cp(r);
  T.pipe(14, .6); r = T.go(0, 0, 10, 10); T.span(12, 1.4, 'beam'); r = T.go(0, 0, 12, 12); T.cp(r);
  T.turn(1);
  // конвейеры: цепочка подвижных платформ поперёк курса
  T.movingChain(3, 3.6, 2.6, 3.8, 5); r = T.go(2.6, 0, 10, 10, 0);
  const lg = T.lift(4.5, 9); r = T.go(lg, 4.5, 10, 10); T.cp(r);
  // верхний ярус: контейнерные штабели
  const up = r; T.turn(-1);
  r = T.go(3.2, 0, 9, 9); solid(r.x + 1, r.y, r.z - 2, r.x + 4, r.y + 1.0, r.z + 2, 'container', 0xd68910);
  r = T.go(3.4, 1, 6, 8, 1.5); r = T.go(3.4, 1, 6, 8, -1.5); T.cp(r);
  // развилка: верх по трубам / низ по ржавым платформам, затем общий цех
  r = T.go(3.2, 0, 30, 9, 0, { noProps: true }); tank(r.x - 10, r.y, r.z); vent(r.x + 11, r.y, r.z);
  const exitPad = { x: 0, y: 0, z: 0 };
  T.push(); T.lane(36, [[6, 6, 0, 0, { noProps: true }], [5, 5, 0, 0, { noProps: true }], [6, 6, 0, 0, { noProps: true }], [5, 5, 0]], -10); T.pop();
  T.lane(36, [[10, 9], [8, 8], [10, 9]], 0, true);
  const fork = T.go(3.2, 0, 30, 12, 0, { noProps: true }); T.cp(fork);
  // портал-шорткат в полу: ведёт через цех к последней секции
  const pf = { x: fork.x + 10, y: fork.y, z: fork.z };
  // последняя секция (поворот вправо) строится дальше, портал ведёт на её середину
  T.turn(1);
  r = T.go(3.5, .4, 8, 8); T.pipe(14, .55); r = T.go(0, 0, 12, 12); T.cp(r);
  const mid = r; T.turn(-1);
  solid(mid.x - 2, mid.y, mid.z - 8, mid.x + 2, mid.y + 6, mid.z - 6, 'container', 0x7d3c98);
  r = T.go(3.4, 0, 9, 9, 3); r = T.go(3.6, .5, 7, 7, -3); r = T.go(3.6, .5, 6, 6, 2);
  r = T.go(4, 0, 22, 24, 0, { noProps: true }); buildFinish(r); tank(r.x + 8, r.y, r.z + 8);
  portal({ x: pf.x, y: pf.y, z: pf.z }, { x: mid.x, y: mid.y, z: mid.z + 3, yaw: 0 }, { kind: 'floor', color: 0xff7a1a, color2: 0xffd24a, name: 'ЦЕХ-ШОРТКАТ' });
  scatter({ side: 'brick', top: 'roof', tints: [0xffffff, 0xe0cfc0, 0xc9c0b8], hMax: 50, n: 60, minD: 28, fn: (x, z, w, d, top, t) => {
    box(x - w / 2, W.groundY, z - d / 2, x + w / 2, top, z + d / 2, rnd() < .5 ? 'rust' : 'brick', 'roof', t);
    if (rnd() < .55) { const h = 25 + rnd() * 35; cyl('brick', 0xe6d6c6, x, top + h / 2, z, 1.6, 2.3, h, 'y', 10); cyl('hazard', 0xffffff, x, top + h - 2.5, z, 1.66, 1.7, 3, 'y', 10); }
  } });
  finishAndGround(-50, 0x4a4036, true, [14, 90, 150, .5, 1]);
}

/* ============================ 3. SKY PARKOUR ============================ */
export function buildSky() {
  W.groundY = -8; W.killDrop = 34; W.START = { x: 0, y: 40, z: 3, yaw: 0 };
  island(0, 40, 0, 14, 14, { noProps: true });
  const T = new Turtle(0, 40, -7, 0); T.painter = island; let r;
  for (let i = 0; i < 5; i++) r = T.go(3 + i * .25, .3, 4.2 - i * .1, 4.2, i % 2 ? 3 : -3, { pad: true });
  r = T.go(4, 0, 12, 12); T.cp(r);
  // узкий мост и поворот
  T.span(22, 1.6, 'cloudp', 0xdfeaf6, { rails: true, railTint: 0x8fb8e0, th: .4 }); r = T.go(0, 0, 10, 10);
  T.turn(1); r = T.go(3.4, 1, 8, 8); r = T.go(4, 0, 6, 6, 1); r = T.go(4.4, -.6, 6, 6, -2); T.cp(T.go(3.6, 0, 12, 12));
  // облачные платформы: большой разрыв = подвижный мост
  T.movingBridge(11, 4, 7, 0xe6f0ff); r = T.go(11, 0, 10, 10); T.cp(r);
  const portalFrom = r; T.turn(-1);
  T.movingChain(4, 3.8, 2.8, 3.6, 5, 0xe6f0ff); r = T.go(2.8, 0, 8, 8);
  // вертикальный подъём по островам
  [[3.3, 1.1, 5.5, 5.5, 2], [3.4, 1.1, 5, 5, -2.4], [3.5, 1.2, 5, 5, 2], [3.5, 1.2, 6, 6, -1]].forEach(s => { r = T.go(s[0], s[1], s[2], s[3], s[4], { pad: true }); }); T.cp(T.go(4, .8, 12, 12));
  const top = T.last; skyRing(top.x, top.y + 6, top.z, 6, 0x7fdcff);
  // длинная линия узких островов на высоте
  T.turn(1); for (let i = 0; i < 7; i++) r = T.go(3.2 + (i % 3) * .4, i % 2 ? -.4 : .4, 3.6, 3.6, i % 2 ? 2.4 : -2.4, { pad: true });
  r = T.go(4, 0, 12, 12); T.cp(r); skyRing(r.x, r.y + 6, r.z, 6, 0xff9ad0);
  const land = r; T.turn(-1);
  T.span(26, 1.2, 'cloudp', 0xdfeaf6, { th: .35, rails: true, railTint: 0xa8c8ee }); r = T.go(0, 0, 8, 8);
  r = T.go(3.8, -1, 14, 14, 2); r = T.go(4, 0, 22, 24, 0, { noProps: true }); buildFinish(r); skyRing(r.x, r.y + 7, r.z + 6, 7, 0xffd34a);
  // портал-шорткат: из середины маршрута сразу на высотную линию
  portal({ x: portalFrom.x + 3, y: portalFrom.y, z: portalFrom.z }, { x: land.x, y: land.y, z: land.z, yaw: 0 }, { kind: 'ring', color: 0x6bd0ff, color2: 0xffffff, name: 'ОБЛАЧНЫЙ ПОРТАЛ' });
  for (let i = 0; i < 46; i++) {
    const a = rnd() * 6.283, d = 40 + rnd() * 140, x = Math.cos(a) * d, z = -80 + Math.sin(a) * d * 1.2, y = 5 + rnd() * 80, s = 3 + rnd() * 9;
    cyl('rock', pick([0xb0a898, 0x9a9284, 0xc2bcae]), x, y, z, s, s * .18, s * 1.3, 'y', 9); cyl('cloudp', 0xffffff, x, y + s * .66, z, s * 1.02, s * 1.02, .5, 'y', 9);
  }
  finishAndGround(-8, 0xf3f8ff, false, [30, -14, 8, .9, 1.5]);
}

/* ============================ 4. NIGHT CITY ============================ */
export function buildNight() {
  W.groundY = -70; W.START = { x: 0, y: 24, z: 3, yaw: 0 };
  nightRoof(0, 24, 0, 16, 16, { noProps: true }); billboard(0, 24, 7.4, 7, 3.2);
  const T = new Turtle(0, 24, -8, 0); T.painter = nightRoof; let r;
  r = T.go(2.6, 0, 11, 12, 0, { noProps: true }); r = T.go(3.2, .8, 9, 9, 2.5); r = T.go(3.4, .8, 8, 8, -2.5); T.cp(r);
  sign(r.x, r.y + 6, r.z - 6, 9, 3, 'NIGHT CITY', '#ff2fd0');
  r = T.go(3.4, .8, 8, 8, 2); r = T.go(3.4, .8, 8, 8, -2); r = T.go(3.4, .8, 12, 12); T.cp(r);
  T.turn(1); r = T.go(3.6, 0, 6, 6); r = T.go(4, -.5, 4.6, 4.6, 1.5); r = T.go(4, -.5, 4.6, 4.6, -1.5); r = T.go(4, 0, 4.6, 4.6, 1.5); r = T.go(4, 0, 12, 12); T.cp(r);
  const secretFrom = r; T.turn(-1);
  r = T.go(3.2, 0, 30, 10, 0, { noProps: true });
  T.lane(40, [[5, 5, 1], [5, 5, 1], [5, 5, -1], [5, 5, -1], [5, 5, 0]], -11); T.lane(40, [[4, 4, 0], [4, 4, 0], [4, 4, 0], [4, 4, 0], [4, 4, 0], [4, 4, 0]], 11);
  T.lane(40, [[9, 8], [8, 7], [9, 8], [8, 7]], 0, true);
  r = T.go(3, 0, 30, 12, 0, { noProps: true }); T.cp(r);
  // тайный маршрут: кольцо-портал ведёт на крышу с бонус-неоном, оттуда прыжок к финишной секции
  T.turn(-1);
  r = T.go(3.2, 1, 8, 8); r = T.go(3.3, 1, 6, 6, 1.5); r = T.go(3.4, 1, 6, 6, -1.5); r = T.go(3.8, 0, 10, 10); T.cp(r);
  T.turn(1);
  r = T.go(3.4, -1, 8, 8); T.movingBridge(10, 4, 6.5, 0x00e5ff); r = T.go(10, 0, 8, 8);
  const sec = r; T.turn(-1);
  r = T.go(4, -.5, 14, 14, 0, { noProps: true }); r = T.go(4, 0, 22, 24, 0, { noProps: true }); buildFinish(r);
  // секретная площадка и порталы
  const sx = secretFrom.x + 14, sz = secretFrom.z - 6; const sp = nightRoof(sx, secretFrom.y + 6, sz, 8, 8, { noProps: true }); 
  for (let i = 0; i < 4; i++) { const px = sx + 4 + 3.6 * (i + 1), pz = sz - 4.4 * (i + 1); nightRoof(px, secretFrom.y + 6 + (i + 1) * 1.1, pz, 4, 4, { noProps: true, pad: true }); }
  portal({ x: secretFrom.x, y: secretFrom.y, z: secretFrom.z - 3 }, { x: sp.x, y: sp.y, z: sp.z, yaw: 0 }, { kind: 'ring', color: 0xff2fd0, color2: 0x00e5ff, name: 'СЕКРЕТНЫЙ ПОРТАЛ', secret: true });
  portal({ x: sx + 4 + 3.6 * 4, y: secretFrom.y + 6 + 4.4, z: sz - 4.4 * 4 }, { x: sec.x, y: sec.y, z: sec.z, yaw: -90 }, { kind: 'floor', color: 0x00e5ff, color2: 0xffe14a, r: 1.8, name: 'ВЫХОД', secret: true });
  scatter({ side: 'nfacade', top: 'roof', tints: [0xffffff], hMax: 130, n: 80, minD: 26, neon: NEON, cap: true });
  finishAndGround(-70, 0x0b0d18, false);
}

/* ============================ 5. PURE PARKOUR ============================ */
export function buildPure() {
  W.groundY = -40; W.START = { x: 0, y: 12, z: 3, yaw: 0 };
  arena(0, 12, 0, 14, 14, { noProps: true, edge: 0x35d0ff });
  const T = new Turtle(0, 12, -7, 0); T.painter = arena; let r;
  // 1. препятствия для vault: барьеры разной высоты
  r = T.go(2.2, 0, 10, 22); [[-6, .8], [-1, .95], [4, 1.0]].forEach(([dz, h]) => solid(r.x - 4.5, r.y, r.z + dz, r.x + 4.5, r.y + h, r.z + dz + .6, 'crate', 0xffffff, 'concrete')); T.cp(r);
  // 2. узкие балки
  T.span(14, .9, 'beam'); r = T.go(0, 0, 8, 8); T.turn(1); T.span(12, .8, 'beam'); r = T.go(0, 0, 8, 8, 0, { edge: 0xff4d6d }); T.cp(r);
  // 3. wall run: коридор без пола — только по стенам
  T.turn(-1); T.fwd(0); const wr0 = T.go(2.4, 0, 8, 6, 0, { edge: 0xa6ff3d }); T.wallRun(13, 3.4, 7, 'brick', 0xd8c8b8); r = T.go(0, 0, 8, 8, 0, { edge: 0xa6ff3d }); T.cp(r);
  // 4. вертикаль: лестница платформ вверх и стена
  [[3, 1.0, 6, 6, 2], [3.2, 1.0, 6, 6, -2], [3.2, 1.0, 6, 6, 2], [3.2, 1.0, 6, 6, -2]].forEach(s => { r = T.go(s[0], s[1], s[2], s[3], s[4]); }); r = T.go(3, 1, 12, 12); T.cp(r);
  // 5. развилка: низ — прыжки по малым плитам, верх — подвижные платформы
  T.turn(1); r = T.go(3, 0, 30, 8, 0, { edge: 0xffd34a });
  T.lane(36, [[4, 4, 0], [4, 4, 0], [4, 4, 0], [4, 4, 0], [4, 4, 0], [4, 4, 0]], -10); T.lane(36, [[9, 6], [8, 6], [9, 6], [8, 6]], 10);
  T.push(); T.pop();
  T.lane(36, [[5, 5, 0], [5, 5, 0], [5, 5, 0], [5, 5, 0], [5, 5, 0]], 0, true);
  r = T.go(3, 0, 30, 12); T.cp(r);
  // 6. подвижные платформы и спуск
  T.turn(-1); T.movingChain(3, 3.6, 2.6, 3.6, 5); r = T.go(2.6, 0, 10, 10, 0, { edge: 0xff4d6d });
  r = T.go(3.2, -.8, 8, 8, 2); r = T.go(3.4, -.8, 6, 6, -2); r = T.go(3.4, -.8, 6, 6, 2); T.cp(T.go(3.2, -.5, 12, 12));
  // 7. финишная секция: стены wall-run + барьеры
  T.wallRun(14, 3.2, 7, 'brick', 0xc9b8a8); r = T.go(0, 0, 10, 10, 0, { edge: 0xa6ff3d });
  r = T.go(3, 0, 8, 8, 2); r = T.go(3.4, .5, 6, 6, -2); r = T.go(3.6, .5, 5, 5, 0);
  r = T.go(3.6, 0, 22, 24); buildFinish(r);
  scatter({ side: 'concrete', top: 'concrete', tints: [0xffffff, 0xd0d4d8, 0xb8bcc0], hMax: 55, n: 46, minD: 26, w0: 8, w1: 14 });
  finishAndGround(-40, 0x4a5058, true, [12, 60, 120, .6, 1]);
}
