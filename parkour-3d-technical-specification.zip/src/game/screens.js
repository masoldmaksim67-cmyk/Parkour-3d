// Экраны меню: профиль, режимы (с картинками), карты (миниатюры из реальной геометрии), скины, ранги, настройки, статистика, достижения.
import { S, saveSettings, HUD_KEYS, getRec, fmt, STATS, recsForMode, ACHIEVED, resetAllProgress } from './state.js';
import { MAPS, mapById } from './maps.js';
import { MODES, MODE_BY_ID, modeMaps } from './modes.js';
import { ACH_LIST, achCount } from './progress.js';
import { RANKS, rankState, resetRank } from './ranks.js';
import { SKIN_GROUPS, SK, saveSkins, skinItem } from './skins.js';

const $ = id => document.getElementById(id);
export const SEL = { mode: MODE_BY_ID[S.mode] ? S.mode : 'parkour', map: S.map };
export const persistSel = () => { S.mode = SEL.mode; S.map = SEL.map; saveSettings(); };
const DIFF = ['', 'ЛЁГКАЯ', 'СРЕДНЯЯ', 'СЛОЖНАЯ'];
const stars = n => '★'.repeat(n) + '<i style="opacity:.25;font-style:normal">' + '★'.repeat(3 - n) + '</i>';
const css = document.createElement('style');
css.textContent = '.srow{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:9px 4px;border-bottom:1px solid rgba(255,255,255,.1);font-size:13px}.srow b{font-weight:700}.srow input[type=range]{flex:0 1 52%;accent-color:#35d0ff}.srow .v{min-width:44px;text-align:right;opacity:.8}.sgrp{display:flex;gap:6px;flex-wrap:wrap}.sgrp button{padding:7px 12px;border-radius:10px;border:1px solid rgba(255,255,255,.25);background:rgba(20,32,56,.8);color:#fff;font-weight:700;font-size:12px}.sgrp button.on{background:#35d0ff;color:#06121c}.tg2{width:50px;height:28px;border-radius:14px;border:0;background:#445;position:relative}.tg2::after{content:"";position:absolute;left:3px;top:3px;width:22px;height:22px;border-radius:50%;background:#fff;transition:.15s}.tg2.on{background:#35d0ff}.tg2.on::after{left:25px}.stg{display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:8px;margin:10px 0}.stg div{padding:10px;border-radius:12px 3px 12px 3px;background:rgba(20,32,56,.8);font-size:11px;opacity:.95}.stg b{display:block;font-size:19px;margin-top:3px;color:#7fdcff}';
document.head.appendChild(css);

/* ---------- профиль / ранги ---------- */
export function renderProfile() {
  const r = rankState();
  $('profile').innerHTML = '<div class="ricon" style="--rc:' + r.rank.color + '">' + r.rank.icon + '</div><h3 style="color:' + r.rank.color + '">' + r.rank.name + '</h3><div class="xpbar"><i style="width:' + (r.pct * 100).toFixed(0) + '%"></i></div><small>' + r.xp + ' XP' + (r.next ? ' · до «' + r.next.name + '» ' + (r.next.xp - r.xp) : ' · МАКС. РАНГ') + '</small>';
  $('mAchN').textContent = achCount() + '/' + ACH_LIST.length;
}
export function renderRanks() {
  const r = rankState();
  const hist = r.hist.length ? r.hist.map(h => '<div>' + new Date(h.t).toLocaleDateString() + ' — ранг <b>' + (RANKS.find(x => x.id === h.rank) || {}).name + '</b> (' + h.xp + ' XP)</div>').join('') : '<div style="opacity:.6">Истории повышений пока нет — проходите карты и улучшайте рекорды.</div>';
  $('ranksBody').innerHTML = '<div class="rk-cur"><div class="ricon" style="--rc:' + r.rank.color + '">' + r.rank.icon + '</div><h3 style="color:' + r.rank.color + '">' + r.rank.name + '</h3><div class="xpbar"><i style="width:' + (r.pct * 100).toFixed(0) + '%"></i></div><small>' + r.xp + ' XP' + (r.next ? ' · следующий: ' + r.next.name + ' (' + r.next.xp + ')' : ' · максимум') + '</small></div>' +
    '<div class="rk-list">' + RANKS.map((k, i) => '<div class="rk' + (i > r.i ? ' lock' : '') + '"><div class="ricon">' + k.icon + '</div><div><b style="color:' + k.color + '">' + k.name + '</b><small>' + k.xp + ' XP</small></div></div>').join('') + '</div><div class="rk-hist"><b>ИСТОРИЯ ПОВЫШЕНИЙ</b>' + hist + '</div>';
}
export function showRankUp(idx, done) {
  const k = RANKS[idx], el = $('rankUp'); el.style.setProperty('--rc', k.color);
  el.innerHTML = '<div class="ring"></div><div class="ring"></div><small>НОВЫЙ РАНГ</small><div class="ricon" style="--rc:' + k.color + '">' + k.icon + '</div><h2>' + k.name + '</h2><small style="opacity:.7">нажмите, чтобы продолжить</small>';
  $('sRankUp').onclick = done;
}

/* ---------- режимы ---------- */
export function renderModes(cb) {
  const rail = $('modeRail'); rail.innerHTML = '';
  MODES.forEach((m, i) => {
    const n = modeMaps(m.id).length, el = document.createElement('div'); el.className = 'mcd'; el.style.cssText = '--ac:' + m.color + ';animation-delay:' + (i * 70) + 'ms;background-image:url(./img/mode-' + m.img + '.jpg)';
    el.innerHTML = '<div class="mi-top"><span>' + m.icon + ' ' + (m.cat === 'timed' ? 'НА ВРЕМЯ' : m.cat === 'free' ? 'ОТКРЫТАЯ ЛОКАЦИЯ' : 'КАТЕГОРИЯ') + '</span><span>' + n + ' карт</span></div><div class="mi-body"><h3>' + m.name + '</h3><p>' + m.desc + '</p><span class="go">ВЫБРАТЬ КАРТУ ›</span></div>';
    el.onclick = () => { SEL.mode = m.id; const list = modeMaps(m.id); if (!list.some(x => x.id === SEL.map)) SEL.map = list[0].id; persistSel(); cb.goto('maps'); };
    rail.appendChild(el);
  });
}

/* ---------- карты (только карты выбранного режима) ---------- */
export function renderMaps(cb) {
  const m = MODE_BY_ID[SEL.mode], list = modeMaps(m.id), grid = $('mapGrid'); grid.innerHTML = '';
  $('mapsTitle').innerHTML = '<span style="color:' + m.color + '">' + m.name + '</span> · КАРТЫ'; $('mapsSub').textContent = list.length + ' карт';
  list.forEach((mp, i) => {
    const el = document.createElement('div'); el.className = 'mpc'; el.style.animationDelay = (i * 60) + 'ms';
    const rec = m.rec ? getRec(m.id, mp.id) : null;
    el.innerHTML = '<div class="th"><div class="ld">ЗАГРУЗКА ПРЕВЬЮ…</div><span class="dif">' + stars(mp.diff) + '</span></div><div class="bd"><h3>' + mp.name + '</h3><p>' + mp.desc + '</p><div class="rt">▸ ' + mp.route + ' · ' + DIFF[mp.diff] + (m.rec ? ' · рекорд: ' + (rec === null ? '--' : fmt(rec)) : '') + '</div><div class="tg">' + mp.tags.map(t => '<span>' + t + '</span>').join('') + '</div><div class="ac"><button class="mbtn sm" data-pv>ПРЕВЬЮ</button><button class="mbtn sm primary" data-go>ИГРАТЬ</button></div></div>';
    el.querySelector('[data-pv]').onclick = () => cb.preview(mp.id); el.querySelector('[data-go]').onclick = () => { SEL.map = mp.id; persistSel(); cb.start(SEL.mode, mp.id); };
    grid.appendChild(el); cb.thumb(mp.id, el.querySelector('.th'));
  });
}

/* ---------- скины ---------- */
let skTab = 'hand';
export function renderSkins(cb) {
  $('skTabs').innerHTML = SKIN_GROUPS.map(g => '<button data-g="' + g.id + '" class="' + (g.id === skTab ? 'on' : '') + '">' + g.name + '</button>').join('');
  $('skTabs').querySelectorAll('button').forEach(b => { b.onclick = () => { skTab = b.dataset.g; renderSkins(cb); }; });
  const g = SKIN_GROUPS.find(x => x.id === skTab);
  $('skItems').innerHTML = g.items.map(it => { const col = it.c !== undefined ? '#' + ('000000' + it.c.toString(16)).slice(-6) : (g.id === 'knife' ? '#9fb0c0' : '#35d0ff'); return '<div class="sk' + (SK[g.id] === it.id ? ' sel' : '') + '" data-i="' + it.id + '"><div class="sw2" style="background:' + col + '"></div>' + it.name + '</div>'; }).join('');
  $('skItems').querySelectorAll('.sk').forEach(el => { el.onclick = () => { SK[g.id] = el.dataset.i; saveSkins(); cb.skinChanged(); renderSkins(cb); }; });
  $('skinName').textContent = SKIN_GROUPS.map(x => skinItem(x.id, SK[x.id]).name).join(' · ');
}

/* ---------- настройки ---------- */
let setTab = 'sound';
export function renderSettings(cb) {
  document.querySelectorAll('#setTabs button').forEach(b => { b.classList.toggle('on', b.dataset.t === setTab); b.onclick = () => { setTab = b.dataset.t; renderSettings(cb); }; });
  const body = $('setBody'); body.innerHTML = '';
  const row = (label, el) => { const r = document.createElement('div'); r.className = 'srow'; r.innerHTML = '<b>' + label + '</b>'; r.appendChild(el); body.appendChild(r); };
  const slider = (label, key, a, b, st, f, after) => { const w = document.createElement('div'); w.style.cssText = 'display:flex;gap:8px;align-items:center;flex:1;justify-content:flex-end'; const i = document.createElement('input'); i.type = 'range'; i.min = a; i.max = b; i.step = st; i.value = S[key]; const v = document.createElement('span'); v.className = 'v'; v.textContent = f(S[key]); i.oninput = () => { S[key] = +i.value; v.textContent = f(S[key]); saveSettings(); if (after) after(); }; w.append(i, v); row(label, w); };
  const toggle = (label, key, after) => { const t = document.createElement('button'); t.className = 'tg2' + (S[key] ? ' on' : ''); t.onclick = () => { S[key] = !S[key]; t.classList.toggle('on', !!S[key]); saveSettings(); if (after) after(); }; row(label, t); };
  const seg = (label, key, opts, after) => { const g = document.createElement('div'); g.className = 'sgrp'; opts.forEach((o, i) => { const b = document.createElement('button'); b.textContent = o; b.className = S[key] === i ? 'on' : ''; b.onclick = () => { S[key] = i; saveSettings(); g.querySelectorAll('button').forEach((x, j) => x.classList.toggle('on', j === i)); if (after) after(); }; g.appendChild(b); }); row(label, g); };
  if (setTab === 'sound') { slider('Громкость', 'volume', 0, 1, 0.05, v => Math.round(v * 100) + '%', cb.audio); slider('Эффекты', 'sfx', 0, 1, 0.05, v => Math.round(v * 100) + '%', cb.audio); toggle('Звуки', 'sound', cb.audio); toggle('Музыка', 'music', cb.audio); }
  if (setTab === 'gfx') { seg('Качество графики', 'quality', ['LOW', 'MEDIUM', 'HIGH', 'ULTRA'], cb.quality); const fs = document.createElement('button'); fs.className = 'tg2' + (cb.isFs() ? ' on' : ''); fs.onclick = () => { cb.fs(); setTimeout(() => fs.classList.toggle('on', cb.isFs()), 300); }; row('Полноэкранный режим', fs); toggle('Вибрация', 'vibration'); toggle('Эффект скорости (FOV)', 'speedFx'); }
  if (setTab === 'cam') { slider('Чувствительность', 'sens', 0.3, 2.5, 0.05, v => v.toFixed(2)); slider('Плавность камеры', 'smooth', 0, 0.9, 0.05, v => Math.round(v * 100) + '%'); slider('Ускорение поворота', 'lookAccel', 0, 1, 0.05, v => Math.round(v * 100) + '%'); slider('Предел вертикального угла', 'pitchLimit', 0.8, 1.5, 0.05, v => Math.round(v * 57.3) + '°'); slider('Поле зрения (FOV)', 'fov', 60, 100, 1, v => v + '°', cb.fovChanged); toggle('Покачивание при беге', 'bob'); toggle('Наклон камеры', 'tilt'); }
  if (setTab === 'game') { toggle('Auto-Bhop (удержание прыжка)', 'autoHop'); toggle('Показывать нож и руки', 'knife', cb.knifeVis); const b = document.createElement('button'); b.className = 'mbtn sm'; b.textContent = 'РЕДАКТОР УПРАВЛЕНИЯ'; b.onclick = cb.controls; row('Мобильное управление', b); }
  if (setTab === 'hud') HUD_KEYS.forEach(k => { const t = document.createElement('button'); t.className = 'tg2' + (S.hud[k[0]] ? ' on' : ''); t.onclick = () => { S.hud[k[0]] = !S.hud[k[0]]; t.classList.toggle('on', S.hud[k[0]]); saveSettings(); }; row(k[1], t); });
}

/* ---------- статистика ---------- */
let stTab = 'all';
export function renderStats() {
  document.querySelectorAll('#stTabs button').forEach(b => { b.classList.toggle('on', b.dataset.t === stTab); b.onclick = () => { stTab = b.dataset.t; renderStats(); }; });
  const T = STATS.total, r = rankState(), box = (l, v) => '<div>' + l + '<b>' + v + '</b></div>';
  const route = MAPS.filter(m => m.cat !== 'free'), done = route.filter(m => (STATS.maps[m.id] || {}).finishes > 0).length;
  const best = cat => { let b = null; MAPS.filter(m => m.cat === cat).forEach(m => MODES.forEach(md => { if (md.id === cat) { const v = getRec(md.id, m.id); if (v !== null && (b === null || v < b)) b = v; } })); return b === null ? '--' : fmt(b); };
  const bestAny = () => { let b = null; MAPS.forEach(m => ['parkour', 'bhop', 'surf', 'speedrun', 'timeattack'].forEach(md => { const v = getRec(md, m.id); if (v !== null && (b === null || v < b)) b = v; })); return b === null ? '--' : fmt(b); };
  let h = '';
  if (stTab === 'all') {
    const bm = STATS.modes.bhop || {}, sm = STATS.modes.surf || {};
    h = '<div class="stg">' + box('Ранг', r.rank.name + ' · ' + r.xp + ' XP') + box('Общий прогресс', done + ' / ' + route.length + ' карт (' + Math.round(done / route.length * 100) + '%)') + box('Прохождений', T.finishes) + box('Попыток', T.attempts) + box('Лучшее время', bestAny()) + box('Макс. скорость', Math.round(T.maxSpeed * 3.6) + ' км/ч') +
      box('BHOP: лучшая серия', (bm.bestStreak || 0)) + box('BHOP: макс. скорость', Math.round((bm.maxSpeed || 0) * 3.6) + ' км/ч') + box('BHOP: лучшее время', best('bhop')) + box('SURF: макс. скорость', Math.round((sm.maxSpeed || 0) * 3.6) + ' км/ч') + box('SURF: лучшее время', best('surf')) + box('PARKOUR: лучшее время', best('parkour')) + box('Прыжков', T.jumps) + box('Падений', T.falls) + box('Дистанция', (T.distance / 1000).toFixed(2) + ' км') + box('Время в игре', Math.round(T.playTime / 60) + ' мин') + '</div>';
  } else if (stTab === 'maps') {
    h = '<div class="stg">' + MAPS.map(m => { const s = STATS.maps[m.id] || {}; return '<div>' + m.name + '<b>' + (s.finishes || 0) + ' ✓ · ' + Math.round((s.maxSpeed || 0) * 3.6) + ' км/ч</b>попыток ' + (s.attempts || 0) + ', падений ' + (s.falls || 0) + '</div>'; }).join('') + '</div>';
  } else {
    h = '<div class="stg">' + MODES.map(m => { const s = STATS.modes[m.id] || {}; const rc = recsForMode(m.id), vals = Object.keys(rc).map(k => rc[k]); return '<div>' + m.name + '<b>' + (s.finishes || 0) + ' ✓</b>попыток ' + (s.attempts || 0) + (m.rec && vals.length ? ' · лучшее ' + fmt(Math.min.apply(null, vals)) : '') + '</div>'; }).join('') + '</div>';
  }
  $('stBody').innerHTML = h;
  $('stReset').onclick = () => { if (confirm('Сбросить рекорды, статистику, ранг и достижения?')) { resetRank(); resetAllProgress(); } };
}
export function renderAch() {
  $('achCount').textContent = achCount() + ' / ' + ACH_LIST.length;
  $('achGrid').innerHTML = ACH_LIST.map(a => '<div class="ach' + (ACHIEVED[a.id] ? ' on' : '') + '"><i>' + a.icon + '</i><b>' + a.name + '</b><span>' + a.desc + '</span></div>').join('');
}
export { mapById };
