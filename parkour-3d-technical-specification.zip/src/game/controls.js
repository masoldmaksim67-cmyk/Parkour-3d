// Раскладка мобильного управления + редактор (перемещение, размер, прозрачность, зона камеры, пресеты).
// Раскладка хранится в localStorage ('pk3d_layout'); любые повреждённые данные заменяются пресетом CLASSIC.
import { LS, S, saveSettings } from './state.js';

const $ = id => document.getElementById(id);
const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
export const KEYS = ['joy', 'jump', 'run', 'slash', 'look'];
export const NAMES = { joy: 'ДЖОЙСТИК', jump: 'ПРЫЖОК', run: 'БЕГ', slash: 'ВЗМАХ НОЖОМ', look: 'ОСМОТР НОЖА', cam: 'ОБЛАСТЬ КАМЕРЫ' };
const DOM = { joy: 'joyBase', jump: 'bJump', run: 'bRun', slash: 'bSlash', look: 'bLook' };
const BASE = {
  joy: m => clamp(m * 0.3, 110, 180), jump: m => clamp(m * 0.22, 78, 128), run: m => clamp(m * 0.145, 54, 86),
  slash: m => clamp(m * 0.115, 44, 66), look: m => clamp(m * 0.115, 44, 66)
};
const PRESETS = ['classic', 'compact', 'large', 'bhop', 'custom'];

/* ---------- модель ---------- */
function sanitize(raw) {
  const m = { preset: 'classic', custom: null };
  if (!raw || typeof raw !== 'object') return m;
  if (PRESETS.includes(raw.preset)) m.preset = raw.preset;
  const c = raw.custom;
  if (c && typeof c === 'object' && c.el && typeof c.el === 'object' && c.cam && typeof c.cam === 'object') {
    const el = {}; let ok = true;
    KEYS.forEach(k => { const e = c.el[k]; if (e && [e.x, e.y, e.s, e.o].every(Number.isFinite)) el[k] = { x: clamp(e.x, 0, 1), y: clamp(e.y, 0, 1), s: clamp(e.s, 0.5, 2), o: clamp(e.o, 0.15, 1) }; else ok = false; });
    const cm = c.cam;
    if (ok && [cm.x, cm.y, cm.w, cm.h].every(Number.isFinite)) m.custom = { el, cam: { x: clamp(cm.x, 0, 0.85), y: clamp(cm.y, 0, 0.85), w: clamp(cm.w, 0.15, 1), h: clamp(cm.h, 0.2, 1) } };
  }
  if (m.preset === 'custom' && !m.custom) m.preset = 'classic';
  return m;
}
export let MODEL = sanitize(LS.get('pk3d_layout', null));
const clone = o => JSON.parse(JSON.stringify(o));

function presetModel(name, w, h, ins) {
  const m = Math.min(w, h), sc = name === 'compact' ? 0.8 : name === 'large' || name === 'bhop' ? 1.3 : 1, mg = name === 'compact' ? 0.8 : 1;
  const z = {}; KEYS.forEach(k => { z[k] = BASE[k](m) * sc; });
  const ri = ins.r + 0.035 * m * mg, bi = ins.b + 0.04 * m * mg, u = 0.02 * m * mg, bb = ins.b + 0.045 * m * mg, pos = {};
  pos.jump = [w - ri - z.jump / 2, h - bi - z.jump / 2];
  pos.run = [w - ri - z.jump - 1.2 * u - z.run / 2, h - bb - z.run / 2];
  pos.slash = [pos.run[0], h - bb - z.run - u - z.slash / 2];
  pos.look = [pos.run[0], pos.slash[1] - z.slash / 2 - 0.8 * u - z.look / 2];
  pos.joy = [ins.l + Math.max(18, 0.06 * m) + z.joy / 2, h - ins.b - Math.max(18, 0.07 * m) - z.joy / 2];
  if (name === 'bhop') { pos.jump = [pos.jump[0] - z.jump * 0.1, h - bi - z.jump * 0.62]; pos.run[1] = pos.jump[1] - z.jump * 0.75; }
  const el = {}; KEYS.forEach(k => { el[k] = { x: pos[k][0] / w, y: pos[k][1] / h, s: k === 'jump' && name === 'bhop' ? 1.5 : sc, o: 1 }; });
  return { el, cam: h > w ? { x: 0.5, y: 0, w: 0.5, h: 1 } : { x: 0.4, y: 0, w: 0.6, h: 1 } };
}
const source = (w, h, ins) => (MODEL.preset === 'custom' && MODEL.custom ? MODEL.custom : presetModel(MODEL.preset, w, h, ins));

// координаты элементов в пикселях (с ограничением по границам экрана)
export function resolve(w, h, ins) {
  const m = Math.min(w, h), src = source(w, h, ins), out = {};
  KEYS.forEach(k => {
    const e = src.el[k], size = BASE[k](m) * e.s, hs = size / 2;
    out[k] = { cx: clamp(e.x * w, ins.l + hs, Math.max(ins.l + hs, w - ins.r - hs)), cy: clamp(e.y * h, ins.t + hs, Math.max(ins.t + hs, h - ins.b - hs)), size, o: e.o, s: e.s };
  });
  const c = src.cam, cw = c.w * w, ch = c.h * h;
  out.cam = { l: clamp(c.x * w, 0, w - cw), t: clamp(c.y * h, 0, h - ch), w: cw, h: ch };
  return out;
}

// применяет раскладку к DOM; возвращает данные для джойстика
export function applyLayout(w, h, ins) {
  const r = resolve(w, h, ins);
  KEYS.forEach(k => {
    const el = $(DOM[k]), o = r[k]; if (!el) return;
    el.style.setProperty('--o', o.o);
    if (k === 'joy') return;
    el.style.left = (o.cx - o.size / 2) + 'px'; el.style.top = (o.cy - o.size / 2) + 'px'; el.style.right = 'auto'; el.style.bottom = 'auto';
    el.style.width = el.style.height = o.size + 'px'; el.style.fontSize = Math.max(7, o.size * 0.14) + 'px';
  });
  const lz = $('lookZone'), jz = $('joyZone');
  lz.style.left = r.cam.l + 'px'; lz.style.top = r.cam.t + 'px'; lz.style.width = r.cam.w + 'px'; lz.style.height = r.cam.h + 'px'; lz.style.right = 'auto'; lz.style.bottom = 'auto';
  // зона джойстика не заходит на зону камеры: её правая граница не дальше левого края зоны камеры
  const jw = clamp(r.cam.l, w * 0.25, w * 0.55);
  jz.style.width = jw + 'px'; r.joyZoneW = jw;
  return r;
}

/* ---------- редактор ---------- */
let ED = null;
export const isEditing = () => !!ED;

export function openEditor(api) {
  if (ED) return;
  ED = { api, snap: clone(MODEL), snapSens: S.sens, snapVib: S.vibration, sel: 'jump', drags: new Map(), preview: false, pv: new Map() };
  document.body.classList.add('editing');
  const root = $('ctlEditor'); root.classList.add('on'); root.classList.remove('previewing');
  buildPanel(); rebuildHandles(); select('jump');
  window.addEventListener('resize', onResize);
}
function onResize() { if (!ED) return; setTimeout(() => { ED.api.relayout(); rebuildHandles(); }, 60); }
function closeEditor(save) {
  if (!ED) return;
  if (save) { LS.set('pk3d_layout', MODEL); saveSettings(); }
  else { MODEL = ED.snap; S.sens = ED.snapSens; S.vibration = ED.snapVib; }
  endPreview();
  window.removeEventListener('resize', onResize);
  const api = ED.api; ED = null;
  document.body.classList.remove('editing');
  const root = $('ctlEditor'); root.classList.remove('on', 'previewing'); $('ceHandles').innerHTML = '';
  api.relayout(); api.onClose(save);
}
const ins = () => ED.api.getInsets();
const cur = () => resolve(innerWidth, innerHeight, ins());

function ensureCustom() {
  if (MODEL.preset === 'custom' && MODEL.custom) return;
  const base = presetModel(MODEL.preset, innerWidth, innerHeight, ins());
  MODEL.custom = base; MODEL.preset = 'custom'; syncPresetBtns();
}
function syncPresetBtns() { document.querySelectorAll('#cePresets button').forEach(b => b.classList.toggle('on', b.dataset.p === MODEL.preset)); }

function buildPanel() {
  const p = $('cePanel');
  p.innerHTML = '<div class="ce-row"><span class="ce-t">РЕДАКТОР УПРАВЛЕНИЯ</span><div class="seg" id="cePresets">' +
    PRESETS.map(x => '<button data-p="' + x + '">' + x.toUpperCase() + '</button>').join('') + '</div></div>' +
    '<div class="ce-row ce-sl"><b id="ceSel">—</b>' +
    '<label>РАЗМЕР <input type="range" id="ceSize" min="50" max="200" step="1"><i id="ceSizeV"></i></label>' +
    '<label>ПРОЗРАЧН. <input type="range" id="ceOp" min="20" max="100" step="1"><i id="ceOpV"></i></label>' +
    '<label>КАМЕРА <input type="range" id="ceSens" min="0.3" max="2.5" step="0.1"><i id="ceSensV"></i></label>' +
    '<label>ВИБРО <button class="sw" id="ceVib"></button></label></div>' +
    '<div class="ce-row ce-btns"><button class="mbtn primary sm" id="ceSave">SAVE</button><button class="mbtn sm" id="ceReset">RESET</button><button class="mbtn sm" id="ceCancel">CANCEL</button><button class="mbtn sm" id="cePrev">PREVIEW</button></div>' +
    '<div class="ce-hint">Перетаскивайте элементы пальцем (мультитач). Нажмите на элемент, чтобы выбрать и настроить его.</div>';
  syncPresetBtns();
  document.querySelectorAll('#cePresets button').forEach(b => {
    b.onclick = () => {
      const pr = b.dataset.p;
      if (pr === 'custom') { ensureCustom(); }
      else { MODEL.preset = pr; }
      syncPresetBtns(); ED.api.relayout(); rebuildHandles(); select(ED.sel);
    };
  });
  const size = $('ceSize'), op = $('ceOp'), sens = $('ceSens'), vib = $('ceVib');
  size.oninput = () => { setSize(+size.value / 100); };
  op.oninput = () => { if (ED.sel === 'cam') return; ensureCustom(); MODEL.custom.el[ED.sel].o = clamp(+op.value / 100, 0.15, 1); $('ceOpV').textContent = op.value + '%'; ED.api.relayout(); };
  sens.value = S.sens; $('ceSensV').textContent = S.sens.toFixed(1);
  sens.oninput = () => { S.sens = +sens.value; $('ceSensV').textContent = S.sens.toFixed(1); };
  const syncVib = () => vib.classList.toggle('on', !!S.vibration); syncVib();
  vib.onclick = () => { S.vibration = !S.vibration; syncVib(); if (S.vibration && navigator.vibrate) { try { navigator.vibrate(25); } catch (e) { /* ignore */ } } };
  $('ceSave').onclick = () => closeEditor(true);
  $('ceCancel').onclick = () => closeEditor(false);
  $('ceReset').onclick = () => { MODEL.preset = 'classic'; MODEL.custom = null; S.sens = 1; sens.value = 1; $('ceSensV').textContent = '1.0'; syncPresetBtns(); ED.api.relayout(); rebuildHandles(); select(ED.sel); };
  $('cePrev').onclick = startPreview;
  $('cePrevExit').onclick = endPreview;
}

function select(k) {
  ED.sel = k;
  document.querySelectorAll('.ce-h').forEach(h => h.classList.toggle('sel', h.dataset.k === k));
  $('ceSel').textContent = NAMES[k];
  const r = cur(), size = $('ceSize'), op = $('ceOp');
  if (k === 'cam') { size.value = Math.round(r.cam.w / (innerWidth * 0.6) * 100); $('ceSizeV').textContent = size.value + '%'; op.disabled = true; $('ceOpV').textContent = '—'; }
  else { size.value = Math.round(r[k].s * 100); $('ceSizeV').textContent = size.value + '%'; op.disabled = false; op.value = Math.round(r[k].o * 100); $('ceOpV').textContent = op.value + '%'; }
}

function setSize(v) {
  const k = ED.sel; ensureCustom();
  if (k === 'cam') {
    const c = MODEL.custom.cam, cx = c.x + c.w / 2, cy = c.y + c.h / 2;
    c.w = clamp(0.6 * v, 0.15, 1); c.h = clamp(v, 0.2, 1);
    c.x = clamp(cx - c.w / 2, 0, 1 - c.w); c.y = clamp(cy - c.h / 2, 0, 1 - c.h);
  } else {
    const e = MODEL.custom.el[k], prev = e.s; e.s = clamp(v, 0.5, 2);
    ED.api.relayout(); if (overlaps(k)) { const r = cur(); fix(k, r); }
    if (overlaps(k)) { e.s = prev; $('ceSize').value = Math.round(prev * 100); $('ceSizeV').textContent = 'нет места'; ED.api.relayout(); return; }
  }
  $('ceSizeV').textContent = Math.round(v * 100) + '%';
  ED.api.relayout(); rebuildHandles();
}

/* столкновения (круги) */
function circles(r) { return KEYS.map(k => ({ k, x: r[k].cx, y: r[k].cy, r: r[k].size / 2 })); }
function overlaps(k) {
  const cs = circles(cur()), a = cs.find(c => c.k === k);
  return cs.some(c => c.k !== k && Math.hypot(c.x - a.x, c.y - a.y) < c.r + a.r + 3);
}
// выталкивает элемент k из пересечений и возвращает его в пределы экрана; false — если не удалось
function fix(k, r0) {
  const w = innerWidth, h = innerHeight, I = ins(), e = MODEL.custom.el[k];
  for (let it = 0; it < 12; it++) {
    const r = r0 && it === 0 ? r0 : cur(), cs = circles(r), a = cs.find(c => c.k === k); let moved = false;
    cs.forEach(c => {
      if (c.k === k) return; const dx = a.x - c.x, dy = a.y - c.y, d = Math.hypot(dx, dy) || 0.01, need = c.r + a.r + 4;
      if (d < need) { a.x += dx / d * (need - d); a.y += dy / d * (need - d); moved = true; }
    });
    if (!moved) return true;
    const hs = a.r; a.x = clamp(a.x, I.l + hs, w - I.r - hs); a.y = clamp(a.y, I.t + hs, h - I.b - hs);
    e.x = a.x / w; e.y = a.y / h;
  }
  return !overlaps(k);
}

/* ручки (drag handles) */
function rebuildHandles() {
  if (!ED) return;
  const box = $('ceHandles'); box.innerHTML = ''; const r = cur();
  const mk = (k, l, t, w, h, round) => {
    const d = document.createElement('div'); d.className = 'ce-h' + (round ? ' round' : '') + (k === 'cam' ? ' cam' : '') + (k === ED.sel ? ' sel' : ''); d.dataset.k = k;
    d.style.cssText = 'left:' + l + 'px;top:' + t + 'px;width:' + w + 'px;height:' + h + 'px';
    d.innerHTML = '<span>' + NAMES[k] + '</span>';
    d.addEventListener('pointerdown', e => dragStart(e, k, d));
    d.addEventListener('pointermove', e => dragMove(e, k, d));
    ['pointerup', 'pointercancel'].forEach(ev => d.addEventListener(ev, e => dragEnd(e, k)));
    box.appendChild(d);
  };
  mk('cam', r.cam.l, r.cam.t, r.cam.w, r.cam.h, false);
  KEYS.forEach(k => mk(k, r[k].cx - r[k].size / 2, r[k].cy - r[k].size / 2, r[k].size, r[k].size, true));
}
function dragStart(e, k, d) {
  if (!ED || ED.preview) return; e.preventDefault(); e.stopPropagation();
  try { d.setPointerCapture(e.pointerId); } catch (_) { /* ignore */ }
  const r = cur(); select(k);
  const o = k === 'cam' ? { cx: r.cam.l + r.cam.w / 2, cy: r.cam.t + r.cam.h / 2 } : r[k];
  ED.drags.set(e.pointerId, { k, ox: e.clientX - o.cx, oy: e.clientY - o.cy, sx: o.cx, sy: o.cy, moved: false, start: clone(MODEL) });
}
function dragMove(e, k, d) {
  const g = ED && ED.drags.get(e.pointerId); if (!g) return; e.preventDefault();
  const w = innerWidth, h = innerHeight, I = ins();
  if (!g.moved && Math.hypot(e.clientX - g.ox - g.sx, e.clientY - g.oy - g.sy) < 4) return;
  if (!g.moved) { g.moved = true; ensureCustom(); }
  const nx = e.clientX - g.ox, ny = e.clientY - g.oy;
  if (k === 'cam') {
    const c = MODEL.custom.cam; c.x = clamp((nx - c.w * w / 2) / w, 0, 1 - c.w); c.y = clamp((ny - c.h * h / 2) / h, 0, 1 - c.h);
    d.style.left = c.x * w + 'px'; d.style.top = c.y * h + 'px';
  } else {
    const size = cur()[k].size, hs = size / 2, e2 = MODEL.custom.el[k];
    const x = clamp(nx, I.l + hs, w - I.r - hs), y = clamp(ny, I.t + hs, h - I.b - hs);
    e2.x = x / w; e2.y = y / h; d.style.left = (x - hs) + 'px'; d.style.top = (y - hs) + 'px';
  }
  ED.api.relayout();
}
function dragEnd(e, k) {
  const g = ED && ED.drags.get(e.pointerId); if (!g) return; ED.drags.delete(e.pointerId);
  if (g.moved && k !== 'cam') {
    if (!fix(k)) { MODEL = g.start; syncPresetBtns(); ED.api.relayout(); }
    else { ED.api.relayout(); }
  }
  rebuildHandles(); select(k);
}

/* предварительный просмотр: настоящие кнопки реагируют на нажатия, без игры */
function startPreview() {
  if (!ED || ED.preview) return; ED.preview = true;
  const root = $('ctlEditor'); root.classList.add('previewing');
  document.body.classList.add('previewing');
  const jz = $('joyZone'), lz = $('lookZone'), jb = $('joyBase'), js = $('joyStick');
  ED.pvH = [];
  const on = (el, ev, fn) => { el.addEventListener(ev, fn); ED.pvH.push([el, ev, fn]); };
  on(jz, 'pointerdown', e => {
    e.preventDefault(); try { jz.setPointerCapture(e.pointerId); } catch (_) { /* ignore */ }
    const r = cur().joy, half = r.size / 2; ED.pv.set(e.pointerId, { t: 'joy', cx: clamp(e.clientX, half + 8, jz.clientWidth - half), cy: clamp(e.clientY, half + 8, innerHeight - half - 8) });
    const p = ED.pv.get(e.pointerId); jb.style.transform = 'translate3d(' + (p.cx - half) + 'px,' + (p.cy - half) + 'px,0)'; jb.classList.add('active');
  });
  on(jz, 'pointermove', e => {
    const p = ED.pv.get(e.pointerId); if (!p || p.t !== 'joy') return; const R = cur().joy.size * 0.42;
    let dx = e.clientX - p.cx, dy = e.clientY - p.cy; const l = Math.hypot(dx, dy); if (l > R) { dx *= R / l; dy *= R / l; }
    js.style.transform = 'translate3d(' + dx + 'px,' + dy + 'px,0)';
  });
  ['pointerup', 'pointercancel'].forEach(ev => on(jz, ev, e => { if (ED.pv.get(e.pointerId)) { ED.pv.delete(e.pointerId); jb.classList.remove('active'); js.style.transform = 'translate3d(0,0,0)'; ED.api.relayout(); } }));
  const ping = $('cePing');
  on(lz, 'pointerdown', e => { e.preventDefault(); try { lz.setPointerCapture(e.pointerId); } catch (_) { /* ignore */ } ED.pv.set(e.pointerId, { t: 'look' }); ping.style.display = 'block'; ping.style.left = e.clientX + 'px'; ping.style.top = e.clientY + 'px'; });
  on(lz, 'pointermove', e => { const p = ED.pv.get(e.pointerId); if (p && p.t === 'look') { ping.style.left = e.clientX + 'px'; ping.style.top = e.clientY + 'px'; } });
  ['pointerup', 'pointercancel'].forEach(ev => on(lz, ev, e => { ED.pv.delete(e.pointerId); ping.style.display = 'none'; }));
}
function endPreview() {
  if (!ED || !ED.preview) return; ED.preview = false;
  (ED.pvH || []).forEach(a => a[0].removeEventListener(a[1], a[2])); ED.pvH = []; ED.pv.clear();
  $('cePing').style.display = 'none'; $('joyBase').classList.remove('active'); $('joyStick').style.transform = 'translate3d(0,0,0)';
  $('ctlEditor').classList.remove('previewing'); document.body.classList.remove('previewing');
  ED.api.relayout(); rebuildHandles();
}
