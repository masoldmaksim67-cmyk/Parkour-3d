import { S } from './state.js';
const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);

// Граф: источники -> sfxG -> master; музыка -> musG -> master.
export const AU = {
  ctx: null, master: null, sfxG: null, musG: null, windG: null, windF: null, nb: null, musTimer: 0, musStep: 0, musNext: 0,
  init() {
    if (this.ctx) { if (this.ctx.state === 'suspended') this.ctx.resume(); return; }
    const C = window.AudioContext || window.webkitAudioContext; if (!C) return;
    try {
      const c = (this.ctx = new C()); this.master = c.createGain(); this.master.connect(c.destination);
      this.sfxG = c.createGain(); this.sfxG.connect(this.master);
      this.musG = c.createGain(); this.musG.connect(this.master);
      const len = c.sampleRate * 2, buf = c.createBuffer(1, len, c.sampleRate), d = buf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
      this.nb = buf;
      const src = c.createBufferSource(); src.buffer = buf; src.loop = true;
      const f = (this.windF = c.createBiquadFilter()); f.type = 'lowpass'; f.frequency.value = 500;
      const g = (this.windG = c.createGain()); g.gain.value = 0; src.connect(f); f.connect(g); g.connect(this.sfxG); src.start();
      this.apply();
    } catch (e) { this.ctx = null; }
  },
  // применяет громкость / вкл-выкл звуков и музыки
  apply() {
    if (!this.ctx) return; const t = this.ctx.currentTime;
    this.master.gain.setTargetAtTime(S.volume, t, 0.05);
    this.sfxG.gain.setTargetAtTime(S.sound ? S.sfx : 0, t, 0.05);
    this.musG.gain.setTargetAtTime(S.music ? 0.3 : 0, t, 0.25);
    if (S.music) this.startMusic(); else this.stopMusic();
  },
  setVol() { this.apply(); },
  tone(f, d, type, v, f2) {
    if (!this.ctx || !S.sound) return; const c = this.ctx, t = c.currentTime, o = c.createOscillator(), g = c.createGain();
    o.type = type || 'sine'; o.frequency.setValueAtTime(f, t); if (f2) o.frequency.exponentialRampToValueAtTime(f2, t + d);
    g.gain.setValueAtTime(v, t); g.gain.exponentialRampToValueAtTime(0.0001, t + d); o.connect(g); g.connect(this.sfxG); o.start(t); o.stop(t + d + 0.03);
  },
  noise(d, v, freq, hp) {
    if (!this.ctx || !S.sound) return; const c = this.ctx, t = c.currentTime, s = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
    s.buffer = this.nb; f.type = hp ? 'highpass' : 'lowpass'; f.frequency.value = freq; g.gain.setValueAtTime(v, t); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
    s.connect(f); f.connect(g); g.connect(this.sfxG); s.start(t, Math.random()); s.stop(t + d + 0.03);
  },
  step() { this.noise(0.07, 0.1, 900); },
  jump() { this.tone(230, 0.16, 'sine', 0.1, 440); },
  land(i) { this.noise(0.18, Math.min(0.45, i * 0.028), 450); },
  slide() { this.noise(0.35, 0.12, 1800, true); },
  swing() { this.noise(0.22, 0.14, 2600, true); this.tone(900, 0.18, 'sine', 0.03, 300); },
  inspect() { this.tone(1400, 0.05, 'triangle', 0.03); },
  checkpoint() { this.tone(660, 0.2, 'triangle', 0.15); setTimeout(() => this.tone(990, 0.35, 'triangle', 0.15), 110); },
  fall() { this.tone(500, 0.7, 'sawtooth', 0.08, 70); },
  finish() { [523, 659, 784, 1047].forEach((f, i) => setTimeout(() => this.tone(f, 0.45, 'triangle', 0.16), i * 130)); },
  bhop(n) { this.tone(500 + Math.min(n, 12) * 55, 0.09, 'square', 0.025); },
  beep(go) { this.tone(go ? 880 : 520, go ? 0.35 : 0.12, 'square', 0.1); },
  ach() { [784, 988, 1319].forEach((f, i) => setTimeout(() => this.tone(f, 0.3, 'triangle', 0.13), i * 90)); },
  click() { this.tone(700, 0.04, 'triangle', 0.04); },
  wind(speed, air) {
    if (!this.ctx || !this.windG) return; const t = this.ctx.currentTime;
    this.windG.gain.setTargetAtTime(0.015 + clamp(speed / 24, 0, 1) * 0.12 + (air ? 0.04 : 0), t, 0.15);
    this.windF.frequency.setTargetAtTime(350 + speed * 45, t, 0.2);
  },
  /* ---- процедурная музыка: бас + арпеджио (Am F C G), 112 bpm ---- */
  startMusic() {
    if (!this.ctx || this.musTimer) return; this.musNext = this.ctx.currentTime + 0.1; this.musStep = 0;
    this.musTimer = setInterval(() => this.musTick(), 120);
  },
  stopMusic() { if (this.musTimer) { clearInterval(this.musTimer); this.musTimer = 0; } },
  musTick() {
    const c = this.ctx; if (!c || c.state !== 'running') { if (c) this.musNext = Math.max(this.musNext, c.currentTime); return; }
    const sp = 60 / 112 / 2, CH = [[57, 60, 64], [53, 57, 60], [48, 52, 55], [55, 59, 62]], f = m => 440 * Math.pow(2, (m - 69) / 12);
    while (this.musNext < c.currentTime + 0.4) {
      const st = this.musStep, bar = ((st / 8) | 0) % 4, ch = CH[bar], t = this.musNext;
      const note = (fr, d, type, v) => { const o = c.createOscillator(), g = c.createGain(); o.type = type; o.frequency.value = fr; g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(v, t + 0.015); g.gain.exponentialRampToValueAtTime(0.0001, t + d); o.connect(g); g.connect(this.musG); o.start(t); o.stop(t + d + 0.05); };
      if (st % 2 === 0) note(f(ch[0] - 24), sp * 1.8, 'triangle', 0.5);
      note(f(ch[(st % 3)] + (st % 8 > 3 ? 12 : 0)), sp * 0.9, 'square', 0.07);
      if (st % 8 === 0) note(f(ch[2] + 12), sp * 6, 'sine', 0.12);
      this.musStep++; this.musNext += sp;
    }
  }
};
export const buzz = p => { if (S.vibration && navigator.vibrate) { try { navigator.vibrate(p); } catch (e) { /* ignore */ } } };
