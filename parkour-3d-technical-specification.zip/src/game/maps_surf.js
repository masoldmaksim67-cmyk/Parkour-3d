// SURF-карты: V-образные жёлоба (треугольные рампы под 48–62°), дуги, прыжки между жёлобами, развилки на 3 полосы, трамплины-«launch».
import { THREE, W, box, cyl, buildFinish, rnd, add, addCol } from './core.js';
import { Turtle, portal, scatter, finishAndGround, ringMesh, pillar } from './track.js';
import { arena } from './maps_parkour.js';
import { NEON } from './painters.js';

const pick = a => a[(rnd() * a.length) | 0];
const padStyle = (edge, tint, pillars) => (x, y, z, w, d, o) => {
  o = o || {}; const r = arena(x, y, z, w, d, { edge, tint, noProps: true }); void pillars; return r;
};
// 3 параллельные полосы из общего зала: mk(T,k), k = -1/0/1; маршрут продолжается по центральной
function lanes3(T, gap, mk) {
  [-1, 1].forEach(k => { T.push(); T.shift(k * gap); mk(T, k); T.pop(); });
  mk(T, 0);
}
function stars(n, r, cols) {
  const g = new THREE.BufferGeometry(), pos = new Float32Array(n * 3), col = new Float32Array(n * 3), c = new THREE.Color();
  for (let i = 0; i < n; i++) { const u = rnd() * 2 - 1, a = rnd() * 6.283, s = Math.sqrt(1 - u * u); pos[i * 3] = Math.cos(a) * s * r; pos[i * 3 + 1] = Math.abs(u) * r * .9 - 40; pos[i * 3 + 2] = Math.sin(a) * s * r; c.set(pick(cols)); col[i * 3] = c.r; col[i * 3 + 1] = c.g; col[i * 3 + 2] = c.b; }
  g.setAttribute('position', new THREE.BufferAttribute(pos, 3)); g.setAttribute('color', new THREE.BufferAttribute(col, 3));
  const p = new THREE.Points(g, new THREE.PointsMaterial({ size: 2.2, vertexColors: true, sizeAttenuation: false, fog: false, depthWrite: false })); p.frustumCulled = false; add(p);
}
function planet(x, y, z, r, c1, ring) {
  const m = new THREE.Mesh(new THREE.SphereGeometry(r, 24, 16), new THREE.MeshBasicMaterial({ color: c1, fog: false })); m.position.set(x, y, z); add(m);
  if (ring) { const t = new THREE.Mesh(new THREE.RingGeometry(r * 1.4, r * 2.1, 48), new THREE.MeshBasicMaterial({ color: ring, side: THREE.DoubleSide, transparent: true, opacity: .55, fog: false })); t.position.set(x, y, z); t.rotation.x = 1.2; t.rotation.y = .3; add(t); }
}

/* ============================ SURF CLASSIC ============================ */
export function buildSurfClassic() {
  W.groundY = -40; W.killDrop = 40; W.START = { x: 0, y: 70, z: 3, yaw: 0 };
  const A = 0x4fd8ff, pad = padStyle(A, 0xd5dde4); pad(0, 70, 0, 16, 16);
  const T = new Turtle(0, 70, -8, 0); T.painter = pad; let r; T.y -= 5.5;
  const o = { th: .95, w: 16, tintL: A, tintR: 0xff8a3c, pillars: true }, o2 = Object.assign({}, o, { th: 1.04 });
  T.trough(28, 0, -.10, o); T.arc(90, 60, -.10, o); T.trough(20, 0, -.11, o);
  T.fwd(7); T.y -= 3.6; T.trough(26, 0, -.12, o2);                   // прыжок между рампами
  T.arc(-90, 64, -.11, Object.assign({}, o, { th: 1.0 })); T.trough(18, 0, -.10, o);
  r = T.go(6, -4.5, 66, 30, 0, { edge: 0xffd34a }); T.cp(r);                               T.y -= 5.5; // зал: развилка из трёх путей
  lanes3(T, 22, (t, k) => {
    if (k === 0) { t.trough(30, 0, -.13, { th: 1.06, w: 14, tintL: 0xff5d8f, tintR: 0xffd34a, pillars: true }); t.trough(30, 0, -.13, { th: 1.06, w: 14, tintL: 0xff5d8f, tintR: 0xffd34a }); }
    else { t.arc(k * 20, 30, -.11, o); t.arc(-k * 20, 30, -.11, o); }
  });
  r = T.go(5, -5, 78, 30, 0, { edge: 0xffd34a }); T.cp(r); T.y -= 5.5;
  T.trough(40, 0, -.12, { th: 1.05, w: 18, tintL: 0x7dff6a, tintR: 0xff8a3c, pillars: true }); T.arc(-130, 96, -.11, { th: .98, w: 16, tintL: 0x7dff6a, tintR: 0x4fd8ff, pillars: true });
  T.fwd(8.5); T.y -= 4.2; T.trough(32, 0, -.11, o2); T.arc(55, 44, -.10, { th: .92, w: 13, tintL: A, tintR: 0xff8a3c });
  r = T.go(6, -5, 28, 30, 0, { edge: 0xff8a3c }); T.cp(r); T.y -= 5.5;
  T.trough(24, 0, -.10, { th: 1.0, w: 12, tintL: A, tintR: A }); T.trough(22, 0, -.12, { th: 1.04, w: 12, tintL: 0xff8a3c, tintR: 0xff8a3c });
  r = T.go(6, -4.5, 26, 40, 0, { edge: 0xffd34a }); buildFinish(r);
  scatter({ side: 'facade', top: 'roof', tints: [0xffffff, 0xd9e5f2], hMax: 120, n: 40, minD: 60, span: 150, cap: true });
  finishAndGround(-40, 0x5d636a, true, [20, 30, 120, .8, 1.4]);
}

/* ============================ SURF SPACE ============================ */
export function buildSurfSpace() {
  W.groundY = -400; W.killDrop = 60; W.START = { x: 0, y: 90, z: 3, yaw: 0 };
  const pad = (x, y, z, w, d, o) => { const r = arena(x, y, z, w, d, { edge: 0xb06bff, tint: 0x2a2f45, noProps: true }); return r; };
  pad(0, 90, 0, 18, 18);
  const T = new Turtle(0, 90, -9, 0); T.painter = pad; let r; T.y -= 9;
  const o = { th: .98, w: 24, tintL: 0x9b6bff, tintR: 0x35e0ff }, o2 = Object.assign({}, o, { th: 1.1, w: 28, tintL: 0xff6bd5, tintR: 0x7dffd0 });
  T.trough(30, 0, -.10, o); T.arc(-80, 70, -.10, o); T.trough(26, 0, -.11, o);
  // launch: уклон вверх и огромный прыжок на следующий жёлоб
  T.trough(30, 0, -.12, o2);
  T.arc(100, 90, -.10, o2); T.trough(22, 0, -.12, o);
  r = T.go(6, -5, 70, 30, 0, { edge: 0x35e0ff }); T.cp(r); T.y -= 9;
  lanes3(T, 28, (t, k) => {
    if (k === 0) { t.trough(26, 0, -.12, o2); t.trough(26, 0, -.12, o2); }
    else { t.arc(k * 35, 40, -.11, o); t.arc(-k * 35, 40, -.11, o); }
  });
  r = T.go(6, -6, 92, 30, 0, { edge: 0xff6bd5 }); T.cp(r); T.y -= 9;
  T.arc(-120, 110, -.10, o2); T.trough(34, 0, -.13, { th: 1.12, w: 30, tintL: 0xffe14a, tintR: 0xff6bd5 });
  T.trough(28, 0, -.12, o); T.arc(70, 70, -.1, o2);
  r = T.go(7, -6, 30, 40, 0, { edge: 0xb06bff }); T.cp(r); T.y -= 9;
  T.trough(40, 0, -.1, o2);
  r = T.go(7, -6, 30, 44, 0, { edge: 0xffd34a }); buildFinish(r);
  // портал-шорткат: ring на зале ведёт на финальную платформу
  const hub = T.last;
  stars(900, 420, [0xffffff, 0xbfd8ff, 0xffd8f0, 0xffffff]);
  planet(-220, 60, -260, 70, 0x5a3fa0, 0xc8a0ff); planet(260, 140, -420, 110, 0xd05a3a, 0xffd0a0); planet(40, -60, 160, 36, 0x3fb0a8);
  for (let i = 0; i < 60; i++) { const a = rnd() * 6.283, d = 70 + rnd() * 240, s = 2 + rnd() * 9; cyl('rock', pick([0x6a6078, 0x4f4a60, 0x8a7a90]), Math.cos(a) * d, 20 + rnd() * 120, -150 + Math.sin(a) * d, s, s * .6, s * 1.2, 'y', 7); }
  void hub; void pillar;
  finishAndGround(-400, 0x000000, false);
}

/* ============================ SURF NEON ============================ */
export function buildSurfNeon() {
  W.groundY = -60; W.killDrop = 50; W.START = { x: 0, y: 80, z: 3, yaw: 0 };
  const pad = (x, y, z, w, d, o) => arena(x, y, z, w, d, { edge: 0xff2fd0, tint: 0x1a1d33, noProps: true });
  pad(0, 80, 0, 16, 16);
  const T = new Turtle(0, 80, -8, 0); T.painter = pad; let r, n = 0; T.y -= 4.5;
  const NO = (th, w) => { n++; const a = n % 2 ? 0x00e5ff : 0xff2fd0, b = n % 2 ? 0xff2fd0 : 0xffe14a; return { th, w, key: 'neon', tintL: a, tintR: b, pillars: true }; };
  T.trough(24, 0, -.10, NO(.9, 14)); T.arc(60, 40, -.10, NO(.95, 14)); T.arc(-60, 40, -.11, NO(.95, 14)); T.trough(20, 0, -.1, NO(1, 14));
  T.fwd(7); T.y -= 3.4; T.arc(-100, 70, -.11, NO(1.02, 15)); T.arc(100, 70, -.11, NO(1.02, 15));
  r = T.go(6, -5, 60, 26, 0, { edge: 0x00e5ff }); T.cp(r); T.y -= 4.5;
  lanes3(T, 20, (t, k) => {
    if (k === 0) { t.trough(24, 0, -.12, NO(1.08, 12)); t.fwd(6.5); t.y -= 3.2; t.trough(24, 0, -.12, NO(1.08, 12)); }
    else { t.arc(k * 60, 34, -.11, NO(.95, 13)); t.arc(-k * 60, 34, -.11, NO(.95, 13)); }
  });
  r = T.go(5, -5, 76, 26, 0, { edge: 0xffe14a }); T.cp(r); T.y -= 4.5;
  T.arc(180, 120, -.10, NO(1.0, 15)); T.trough(20, 0, -.12, NO(1.05, 14)); T.fwd(8); T.y -= 4; T.arc(-90, 64, -.11, NO(1.0, 13)); T.trough(26, 0, -.12, NO(1.08, 12));
  r = T.go(6, -5, 28, 30, 0, { edge: 0xff2fd0 }); T.cp(r); T.y -= 4.5;
  T.arc(90, 56, -.1, NO(.95, 13)); T.arc(-90, 56, -.1, NO(.95, 13)); T.trough(20, 0, -.1, NO(1, 12));
  r = T.go(6, -5, 28, 40, 0, { edge: 0xffe14a }); buildFinish(r);
  scatter({ side: 'nfacade', top: 'roof', tints: [0xffffff], hMax: 150, n: 70, minD: 50, span: 140, neon: NEON, cap: true });
  finishAndGround(-60, 0x05060f, false);
}

/* ============================ SURF CANYON ============================ */
export function buildSurfCanyon() {
  W.groundY = -80; W.killDrop = 50; W.START = { x: 0, y: 75, z: 3, yaw: 0 };
  const pad = (x, y, z, w, d, o) => arena(x, y, z, w, d, { edge: 0xff8a3c, tint: 0xd8b48a, noProps: true });
  pad(0, 75, 0, 16, 16);
  const T = new Turtle(0, 75, -8, 0); T.painter = pad; let r; T.y -= 5.5;
  const o = { th: .95, w: 16, key: 'rock', tintL: 0xe0a070, tintR: 0xc87850, pillars: true }, o2 = Object.assign({}, o, { th: 1.05, tintL: 0xf0c090, tintR: 0xd08850 });
  T.trough(30, 0, -.09, o); T.arc(90, 70, -.10, o); T.trough(22, 0, -.1, o);
  T.fwd(7); T.y -= 3.4; T.arc(360, 170, -.10, o2);                                          // спираль-воронка
  T.trough(20, 0, -.11, o);
  r = T.go(6, -5, 56, 28, 0, { edge: 0xffd34a }); T.cp(r); T.y -= 5.5;
  lanes3(T, 22, (t, k) => {
    if (k === 0) { t.trough(26, 0, -.13, o2); t.fwd(7); t.y -= 3.2; t.trough(26, 0, -.12, o2); }
    else { t.arc(k * 25, 28, -.11, o); t.arc(-k * 25, 28, -.11, o); }
  });
  r = T.go(5, -5, 76, 28, 0, { edge: 0xffd34a }); T.cp(r); T.y -= 5.5;
  T.arc(-110, 90, -.1, o2); T.trough(24, 0, -.12, o); T.fwd(8); T.y -= 4; T.arc(150, 110, -.11, o2); T.trough(22, 0, -.11, o);
  r = T.go(6, -5, 26, 30, 0, { edge: 0xff8a3c }); T.cp(r); T.y -= 5.5;
  T.arc(-70, 50, -.1, o); T.trough(18, 0, -.12, o2);
  r = T.go(6, -5, 28, 40, 0, { edge: 0xffd34a }); buildFinish(r);
  scatter({ n: 56, minD: 45, span: 160, hMin: 20, hMax: 130, w0: 10, w1: 14, fn: (x, z, w, d, top, t) => { const s = w * .6; cyl('rock', pick([0xd8a878, 0xc89060, 0xe0b890]), x, (W.groundY + top) / 2, z, s * .8, s * 1.15, top - W.groundY, 'y', 9); } });
  finishAndGround(-80, 0xb88a60, true, [12, 20, 120, .6, 1.4]);
}
