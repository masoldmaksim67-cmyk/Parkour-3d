// Игровые режимы. Challenge-режимы удалены. Карты режима берутся из ДАННЫХ карт (map.modes) — см. maps.js.
import { mapsForMode } from './maps.js';
export const MODES = [
  { id: 'parkour', name: 'PARKOUR', cat: 'parkour', rec: 'time', color: '#ffb02e', icon: '🏙', img: 'parkour',
    desc: 'Прыжки между зданиями, балки, трубы, wall run и vault. Несколько маршрутов и развилки.',
    rules: ['Таймер стартует при первом движении', 'Падение → возрождение на чекпоинте', 'Рекорд сохраняется для каждой карты'],
    hud: ['mode', 'main', 'falls', 'cp', 'prog', 'speed', 'max', 'air'] },
  { id: 'bhop', name: 'BHOP', cat: 'bhop', rec: 'time', color: '#ff2fd0', icon: '🐇', img: 'bhop',
    desc: 'Bunny Hop и Air Strafing: скорость растёт только от правильных прыжков и стрейфов в воздухе.',
    rules: ['Обычный бег даёт лишь стартовую скорость', 'Прыжок в момент приземления сохраняет скорость', 'Стрейф в воздухе плавно ускоряет'],
    hud: ['mode', 'main', 'falls', 'cp', 'prog', 'speed', 'max', 'bhop', 'air'] },
  { id: 'surf', name: 'SURF', cat: 'surf', rec: 'time', color: '#35d0ff', icon: '🌊', img: 'surf',
    desc: 'Скольжение по наклонным треугольным рампам: дуги, повороты, прыжки между рампами, развилки.',
    rules: ['Держите направление в сторону рампы', 'Скорость растёт на спусках и дугах', 'Прыгайте между жёлобами'],
    hud: ['mode', 'main', 'falls', 'cp', 'prog', 'speed', 'max', 'air'] },
  { id: 'speedrun', name: 'SPEEDRUN', cat: 'timed', rec: 'time', color: '#a6ff3d', icon: '⚡', img: 'speedrun',
    desc: 'Скоростное прохождение: падение сбрасывает забег на старт. Сплиты на чекпоинтах сравниваются с рекордом.',
    rules: ['Падение сбрасывает забег', 'Сплиты относительно личного рекорда', 'Быстрый рестарт: R или кнопка ⟲'],
    hud: ['mode', 'main', 'falls', 'cp', 'prog', 'speed', 'max', 'air'] },
  { id: 'timeattack', name: 'TIME ATTACK', cat: 'timed', rec: 'time', color: '#ff5d5d', icon: '⏱', img: 'timeattack',
    desc: 'Гонка со временем: отсчёт 3-2-1, каждое падение добавляет штраф +5 секунд.',
    rules: ['Отсчёт 3-2-1 и автостарт', 'Падение = штраф +5 с', 'Результат сохраняется как рекорд'],
    hud: ['mode', 'main', 'falls', 'cp', 'prog', 'speed', 'max', 'air'] },
  { id: 'freeroam', name: 'FREE ROAM', cat: 'free', rec: null, color: '#6bd68a', icon: '🧭', img: 'freeroam',
    desc: 'Свободное исследование больших локаций: парк, BHOP-аллея, SURF-спуск и порталы. Без таймера.',
    rules: ['Нет таймера и финиша', 'Кнопка ⟲ — возврат на старт', 'Порталы соединяют зоны'],
    hud: ['mode', 'speed', 'max', 'bhop', 'falls', 'air'] }
];
export const MODE_BY_ID = Object.fromEntries(MODES.map(m => [m.id, m]));
export const modeMaps = id => mapsForMode(id);
export const firstMap = id => modeMaps(id)[0] || null;
export function supports(modeId, map) { return !!map && map.modes.indexOf(modeId) >= 0 ? { ok: true } : { ok: false, why: 'Карта не относится к этому режиму' }; }
