// Скины: руки, перчатки, ножи, цвета клинка, одежда персонажа. Все бесплатны; выбор хранится в localStorage и реально меняет модели/текстуры в игре.
import { LS } from './state.js';
export const SKIN_GROUPS = [
  { id: 'hand', name: 'РУКИ', items: [{ id: 'standard', name: 'Стандарт' }, { id: 'tactical', name: 'Тактические' }, { id: 'cyber', name: 'Кибер' }, { id: 'ghost', name: 'Призрак' }] },
  { id: 'glove', name: 'ПЕРЧАТКИ', items: [
    { id: 'black', name: 'Чёрные', c: 0x2b3038, c2: 0x3a414b }, { id: 'carbon', name: 'Карбон', c: 0x1a1d22, c2: 0x4a5560 }, { id: 'orange', name: 'Оранж', c: 0xe5702b, c2: 0xff9a52 },
    { id: 'camo', name: 'Камуфляж', c: 0x4d5a36, c2: 0x6f7d4c }, { id: 'gold', name: 'Золото', c: 0xc89b3c, c2: 0xf0c868 }, { id: 'neon', name: 'Неон', c: 0x00c8e0, c2: 0x6af2ff }, { id: 'white', name: 'Белые', c: 0xe6eaee, c2: 0xffffff }, { id: 'crimson', name: 'Багровые', c: 0x9a1f3a, c2: 0xd2425e }] },
  { id: 'knife', name: 'НОЖИ', items: [{ id: 'classic', name: 'Классик' }, { id: 'karambit', name: 'Керамбит' }, { id: 'tanto', name: 'Танто' }, { id: 'dagger', name: 'Кинжал' }] },
  { id: 'blade', name: 'ЦВЕТ НОЖА', items: [
    { id: 'steel', name: 'Сталь', c: 0xd9e3ea, e: 0 }, { id: 'obsidian', name: 'Обсидиан', c: 0x1b1e26, e: 0 }, { id: 'gold', name: 'Золото', c: 0xe3b84a, e: 0 }, { id: 'crimson', name: 'Рубин', c: 0xc0213f, e: 0x30040e },
    { id: 'ice', name: 'Лёд', c: 0x9fe4ff, e: 0x0a3a50 }, { id: 'neon', name: 'Неон', c: 0x35ff9a, e: 0x0a5a30 }, { id: 'violet', name: 'Аметист', c: 0xa56bff, e: 0x25104a }] },
  { id: 'outfit', name: 'ОДЕЖДА', items: [
    { id: 'orange', name: 'Оранжевая', c: 0xe5702b, c2: 0xb8531a }, { id: 'navy', name: 'Тёмно-синяя', c: 0x233a63, c2: 0x15233f }, { id: 'forest', name: 'Лесная', c: 0x35603a, c2: 0x20401f },
    { id: 'crimson', name: 'Красная', c: 0xb02a3a, c2: 0x7c1a28 }, { id: 'snow', name: 'Белая', c: 0xe8edf2, c2: 0xaab4bf }, { id: 'violet', name: 'Фиолетовая', c: 0x6a3fc0, c2: 0x45258a }, { id: 'night', name: 'Чёрная', c: 0x20242b, c2: 0x101317 }] }
];
const DEF = { hand: 'standard', glove: 'black', knife: 'classic', blade: 'steel', outfit: 'orange' };
export const SK = Object.assign({}, DEF);
(() => { const raw = LS.get('pk3d_skins', {}); SKIN_GROUPS.forEach(g => { if (raw && typeof raw[g.id] === 'string' && g.items.some(i => i.id === raw[g.id])) SK[g.id] = raw[g.id]; }); })();
export const saveSkins = () => LS.set('pk3d_skins', SK);
export const skinItem = (g, id) => SKIN_GROUPS.find(x => x.id === g).items.find(i => i.id === id);
