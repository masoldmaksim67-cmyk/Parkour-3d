// Нож и рука от первого лица: отдельная сцена/камера, рендерится поверх мира (без клиппинга в стены).
import * as THREE from 'three';
import { SK, skinItem } from './skins.js';

const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
const TAU = Math.PI * 2;
const ss = t => t * t * (3 - 2 * t);

const INSPECT = [
  [0, 0, 0, 0, 0, 0, 0, 0],
  [0.45, -0.11, 0.06, 0.07, 0.35, -0.45, 0.30, 0],
  [1.1, -0.11, 0.06, 0.07, 0.45, -0.9, 0.35, 3.1],
  [1.7, -0.11, 0.05, 0.06, 0.30, 0.35, 0.20, 5.2],
  [2.3, 0, 0, 0, 0, 0, 0, TAU]
];
const SWING = [
  [0, 0, 0, 0, 0, 0, 0, 0],
  [0.12, 0.05, -0.01, 0.06, 0.35, 0.2, -0.45, 0],
  [0.26, -0.16, -0.07, -0.17, -0.55, -0.15, 0.95, 0],
  [0.36, -0.19, -0.09, -0.19, -0.7, -0.2, 1.15, 0],
  [0.6, 0, 0, 0, 0, 0, 0, 0]
];
const pose = [0, 0, 0, 0, 0, 0, 0];
function sample(frames, t) {
  let i = 0; while (i < frames.length - 2 && t > frames[i + 1][0]) i++;
  const a = frames[i], b = frames[i + 1], u = ss(clamp((t - a[0]) / (b[0] - a[0]), 0, 1));
  for (let k = 0; k < 7; k++) pose[k] = a[k + 1] + (b[k + 1] - a[k + 1]) * u;
  return pose;
}

export function createKnife() {
  const scene = new THREE.Scene();
  const cam = new THREE.PerspectiveCamera(58, 1, 0.01, 10);
  scene.add(new THREE.HemisphereLight(0xffffff, 0x4a5568, 0.95));
  const dl = new THREE.DirectionalLight(0xffffff, 0.9); dl.position.set(0.6, 1, 0.7); scene.add(dl);

  const root = new THREE.Group(); scene.add(root);
  const knife = new THREE.Group(); root.add(knife);
  const spin = new THREE.Group(); knife.add(spin);
  const P3 = (c, sh, sp) => new THREE.MeshPhongMaterial({ color: c, specular: sp || 0xffffff, shininess: sh || 60 });

  function bladeShape(model) {
    const sh = new THREE.Shape();
    if (model === 'karambit') { sh.moveTo(-0.012, 0); sh.lineTo(0.012, 0); sh.quadraticCurveTo(0.03, 0.12, 0.0, 0.2); sh.quadraticCurveTo(-0.04, 0.26, -0.085, 0.2); sh.quadraticCurveTo(-0.03, 0.2, -0.026, 0.1); sh.lineTo(-0.012, 0); }
    else if (model === 'tanto') { sh.moveTo(-0.004, 0); sh.lineTo(0.021, 0); sh.lineTo(0.021, 0.2); sh.lineTo(0.0, 0.29); sh.lineTo(-0.02, 0.22); sh.lineTo(-0.02, 0); sh.lineTo(-0.004, 0); }
    else if (model === 'dagger') { sh.moveTo(0, 0); sh.lineTo(0.026, 0.02); sh.lineTo(0.022, 0.2); sh.lineTo(0, 0.31); sh.lineTo(-0.022, 0.2); sh.lineTo(-0.026, 0.02); sh.lineTo(0, 0); }
    else { sh.moveTo(-0.004, 0); sh.lineTo(0.021, 0); sh.lineTo(0.021, 0.19); sh.quadraticCurveTo(0.02, 0.27, 0.0, 0.318); sh.quadraticCurveTo(-0.02, 0.12, -0.02, 0.06); sh.lineTo(-0.02, 0); sh.lineTo(-0.004, 0); }
    return sh;
  }
  function build() {
    while (spin.children.length) { const o = spin.children.pop(); if (o.geometry) o.geometry.dispose(); }
    const gl = skinItem('glove', SK.glove), bl = skinItem('blade', SK.blade), ou = skinItem('outfit', SK.outfit), hand = SK.hand, model = SK.knife;
    const mBlade = P3(bl.c, 95); if (bl.e) mBlade.emissive = new THREE.Color(bl.e);
    const mEdge = P3(new THREE.Color(bl.c).lerp(new THREE.Color(0xffffff), 0.55), 120); if (bl.e) mEdge.emissive = new THREE.Color(bl.e);
    const mHandle = P3(model === 'tanto' ? 0x5a3a22 : 0x22272d, 20, 0x333b44), mBrass = P3(bl.id === 'gold' ? 0xffe08a : 0xc89b3c, 60, 0xffe9a8);
    let mGlove = new THREE.MeshLambertMaterial({ color: gl.c }), mGloveHi = new THREE.MeshLambertMaterial({ color: gl.c2 });
    if (hand === 'cyber') { mGlove = P3(0x4a525c, 90); mGloveHi = P3(0x7a8896, 110); }
    if (hand === 'ghost') { mGlove = new THREE.MeshLambertMaterial({ color: gl.c, transparent: true, opacity: 0.62, emissive: 0x103050 }); mGloveHi = new THREE.MeshLambertMaterial({ color: gl.c2, transparent: true, opacity: 0.62, emissive: 0x103050 }); }
    const mSleeve = new THREE.MeshLambertMaterial({ color: ou.c }), mSleeveDk = new THREE.MeshLambertMaterial({ color: ou.c2 });
    const add = (g, m, x, y, z, rx, rz) => { const o = new THREE.Mesh(g, m); o.position.set(x, y, z); if (rx) o.rotation.x = rx; if (rz) o.rotation.z = rz; spin.add(o); return o; };
    const bg = new THREE.ExtrudeGeometry(bladeShape(model), { depth: 0.0065, bevelEnabled: true, bevelSize: 0.0012, bevelThickness: 0.0015, bevelSegments: 1 }); bg.translate(0, 0, -0.00325);
    spin.add(new THREE.Mesh(bg, mBlade));
    if (model !== 'karambit') { const e = add(new THREE.BoxGeometry(0.0035, 0.2, 0.0085), mEdge, -0.0195, 0.13, 0); e.rotation.z = 0.04; add(new THREE.BoxGeometry(0.006, 0.15, 0.0072), P3(0x9aa7b2, 40), 0.004, 0.11, 0); }
    add(new THREE.BoxGeometry(model === 'karambit' ? 0.04 : 0.075, 0.012, 0.024), mBrass, 0, -0.002, 0);
    add(new THREE.CylinderGeometry(0.0165, 0.0185, 0.125, 12), mHandle, 0, -0.0675, 0);
    for (let i = 0; i < 3; i++) add(new THREE.TorusGeometry(0.0178, 0.0022, 6, 14), mBrass, 0, -0.035 - i * 0.03, 0, Math.PI / 2);
    if (model === 'karambit') add(new THREE.TorusGeometry(0.03, 0.006, 8, 20), mBrass, 0, -0.15, 0, 0).rotation.y = Math.PI / 2; else add(new THREE.SphereGeometry(0.0205, 12, 10), mBrass, 0, -0.136, 0);
    add(new THREE.BoxGeometry(0.066, 0.078, 0.05), mGlove, 0.012, -0.075, 0.012);
    for (let i = 0; i < 4; i++) { const f = add(new THREE.TorusGeometry(0.027, 0.0125, 8, 16), i % 2 ? mGlove : mGloveHi, 0, -0.04 - i * 0.0205, 0, Math.PI / 2); f.scale.set(1, 1, 1.05); }
    add(new THREE.CylinderGeometry(0.0125, 0.011, 0.075, 8), mGloveHi, -0.026, -0.03, 0.012, 0, -0.35); add(new THREE.SphereGeometry(0.0125, 8, 6), mGloveHi, -0.0185, 0.007, 0.012);
    add(new THREE.CylinderGeometry(0.036, 0.04, 0.07, 12), mGlove, 0.012, -0.14, 0.012);
    if (hand === 'tactical') { add(new THREE.BoxGeometry(0.07, 0.016, 0.054), P3(0x15181c, 30), 0.012, -0.045, 0.014); add(new THREE.CylinderGeometry(0.043, 0.043, 0.02, 12), P3(0x15181c, 30), 0.012, -0.165, 0.012); add(new THREE.BoxGeometry(0.03, 0.01, 0.056), P3(0x15181c, 30), 0.012, -0.108, 0.014); }
    if (hand === 'cyber') for (let i = 0; i < 3; i++) add(new THREE.TorusGeometry(0.0285, 0.003, 6, 16), new THREE.MeshBasicMaterial({ color: 0x35e0ff }), 0, -0.05 - i * 0.0205, 0, Math.PI / 2);
    add(new THREE.CylinderGeometry(0.048, 0.05, 0.05, 14), mSleeveDk, 0.012, -0.19, 0.012);
    add(new THREE.CylinderGeometry(0.052, 0.068, 0.6, 14), mSleeve, 0.012, -0.5, 0.012);
    if (hand === 'cyber' || hand === 'tactical') add(new THREE.CylinderGeometry(0.0535, 0.0535, 0.012, 14), new THREE.MeshBasicMaterial({ color: hand === 'cyber' ? 0x35e0ff : 0xffb02e }), 0.012, -0.24, 0.012);
  }
  build();
  const BASE = { x: 0.2, y: -0.18, z: -0.46, rx: -1.2, ry: 0, rz: 0.34 };
  root.scale.setScalar(0.82);
  knife.rotation.set(BASE.rx, BASE.ry, BASE.rz);
  root.position.set(BASE.x, BASE.y, BASE.z);

  let t = 0, swayX = 0, swayY = 0, rf = 0, airF = 0, slideF = 0, crF = 0;
  let landY = 0, landV = 0, anim = null, animT = 0, spinAng = 0, spinTarget = 0;

  return {
    scene, cam, applySkin() { build(); },
    setAspect(a) { cam.aspect = a; cam.updateProjectionMatrix(); },
    setLight(c) { scene.children[0].color.set(c); },
    busy() { return !!anim; },
    inspect() { if (anim) return false; anim = INSPECT; animT = 0; return true; },
    swing() { if (anim === SWING) return false; anim = SWING; animT = 0; return true; },
    cancel() { anim = null; },
    landKick(imp) { landV -= Math.min(imp * 0.03, 0.6); },
    jumpKick() { landV += 0.28; },
    update(dt, c) {
      t += dt;
      const k = 1 - Math.exp(-dt * 12);
      swayX += (clamp(c.dyaw * 1.2, -0.07, 0.07) - swayX) * k;
      swayY += (clamp(-c.dpitch * 1.2, -0.06, 0.06) - swayY) * k;
      const kb = Math.min(1, dt * 8);
      rf += ((c.onGround ? clamp(c.hs / 8, 0, 1.3) : 0) * (c.bob ? 1 : 0.35) - rf) * kb;
      airF += ((c.onGround ? 0 : 1) - airF) * kb;
      slideF += ((c.slide ? 1 : 0) - slideF) * Math.min(1, dt * 9);
      crF += ((c.crouch ? 1 : 0) - crF) * kb;
      landV += (-140 * landY - 12 * landV) * dt; landY += landV * dt;

      let px = BASE.x + swayX + Math.sin(c.bobPh) * 0.012 * rf;
      let py = BASE.y + swayY + Math.sin(c.bobPh * 2) * 0.008 * rf + Math.sin(t * 1.6) * 0.0028;
      let pz = BASE.z - clamp(c.hs / 22, 0, 1) * 0.02;
      let rx = BASE.rx, ry = BASE.ry, rz = BASE.rz + Math.sin(c.bobPh) * 0.03 * rf;

      py += airF * clamp(c.vy * 0.0035, -0.035, 0.03) + landY;
      rx += airF * clamp(-c.vy * 0.006, -0.12, 0.15) + swayY * 1.5;
      ry += swayX * 2.2;
      rz += slideF * 0.32 + (c.surf ? 0.12 : 0);
      py -= slideF * 0.04 + crF * 0.015; px += slideF * 0.02;

      if (anim) {
        animT += dt;
        const end = anim[anim.length - 1][0];
        if (animT >= end) { anim = null; spinAng = 0; }
        else {
          const p = sample(anim, animT);
          px += p[0]; py += p[1]; pz += p[2]; rx += p[3]; ry += p[4]; rz += p[5]; spinAng = p[6];
        }
      }
      root.position.set(px, py, pz);
      knife.rotation.set(rx, ry, rz);
      spin.rotation.y = spinAng;
    },
    render(renderer) {
      const ac = renderer.autoClear; renderer.autoClear = false; renderer.clearDepth();
      renderer.render(scene, cam); renderer.autoClear = ac;
    }
  };
}
