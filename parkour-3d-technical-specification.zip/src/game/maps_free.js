// FREE ROAM: открытые локации для исследования — парковый сад, BHOP-аллея, SURF-спуск и порталы между зонами.
import { THREE, W, box, solid, cyl, crate, billboard, sign, buildFinish, rnd, add, addCol, tank, vent, ac } from './core.js';
import { Turtle, portal, scatter, finishAndGround, ringMesh, pillar, lamp } from './track.js';
import { hops } from './maps_bhop.js';
import { NEON, PAL, nightRoof } from './painters.js';

const pick = a => a[(rnd() * a.length) | 0];
function freeWorld(st) {
  W.groundY = st.gy; W.killDrop = 70;
  const G = (x, y, z, w, d, o) => {
    o = o || {}; const x0 = x - w / 2, x1 = x + w / 2, z0 = z - d / 2, z1 = z + d / 2;
    if (o.pad && st.night) return nightRoof(x, y, z, w, d, o);
    box(x0, y - 3, z0, x1, y, z1, st.side, st.top, st.tint); box(x0 + w * .08, y - 9, z0 + d * .08, x1 - w * .08, y - 3, z1 - d * .08, 'rock', 'rock', st.under);
    return { x, y, z, w, d, col: addCol(x0, y - 9, z0, x1, y, z1) };
  };
  // главный остров 120×120
  const main = G(0, 10, 0, 120, 120, {}); W.START = { x: 0, y: 10, z: 46, yaw: 0 };
  const T = new Turtle(0, 10, -60, 0); T.painter = G;
  // --- парковый сад (запад-центр): ящики, барьеры, балки, платформы разной высоты
  for (let i = 0; i < 9; i++) { const x = -34 + (i % 3) * 9, z = 8 - ((i / 3) | 0) * 9, h = 1 + (i % 4) * .75; solid(x - 1.8, 10, z - 1.8, x + 1.8, 10 + h, z + 1.8, i % 2 ? 'crate' : 'concrete', i % 2 ? 0xffffff : 0xcfd2d6, i % 2 ? 'crate' : 'concrete'); }
  solid(-40, 10, -20, -10, 11, -19, 'brick', 0xddccbb, 'concrete');
  for (let i = 0; i < 6; i++) G(-14 + i * 3.4, 10 + 2 + i * 1.6, -26 - (i % 2) * 3, 3.4, 3.4, { pad: true });
  const tw = G(14, 10 + 12, -26, 11, 11, {}); pillar(14, -26, 10, 22, 2.2, 'concrete', 0xb8bcc4); void tw;
  for (let i = 0; i < 4; i++) { const x = -52 + i * 8; solid(x - 1, 10, 36, x + 1, 10 + 2.6 + i * 2.2, 38, 'concrete', 0xc9ccd0); }
  // --- BHOP-аллея: цепочка площадок за восточным краем
  const be = new Turtle(60, 10, 30, 90); be.painter = G; be.go(3, 0, 8, 26, 0, { noProps: true });
  let r = hops(be, 10, 3.2, 8, 14, [2.2, -2.2, 0]); const bend = be.go(4, 0, 14, 14);
  // --- SURF-спуск с западной башни на отдельную посадочную площадку
  const st0 = G(-75, 28, 40, 14, 14, {}); const S = new Turtle(-75, 28, 33, 0); S.painter = G;
  const o = { th: .98, w: 16, tintL: st.t1, tintR: st.t2, key: st.surfKey, pillars: false };
  S.trough(24, 0, -.12, o); S.arc(100, 56, -.12, o); S.arc(-60, 40, -.12, o); S.trough(16, 0, -.12, o);
  const sland = S.go(6, -3.5, 26, 26, 0, {});
  // --- порталы
  portal({ x: sland.x, y: sland.y, z: sland.z }, { x: 0, y: 10, z: 40, yaw: 0 }, { kind: 'ring', color: st.pc, color2: st.pc2, name: 'К СТАРТУ' });
  portal({ x: bend.x, y: bend.y, z: bend.z }, { x: 0, y: 10, z: 40, yaw: 0 }, { kind: 'floor', color: st.pc, color2: st.pc2, name: 'К СТАРТУ' });
  portal({ x: 0, y: 10, z: 30 }, { x: 14, y: 22, z: -26, yaw: 0 }, { kind: 'ring', color: st.pc, color2: st.pc2, name: 'НА БАШНЮ' });
  portal({ x: 14 + 3.4, y: 22, z: -26 }, { x: st0.x, y: st0.y, z: st0.z, yaw: 0 }, { kind: 'floor', color: st.pc2, color2: st.pc, name: 'К SURF-СПУСКУ', r: 1.8 });
  portal({ x: -52, y: 10, z: 20 }, { x: 60, y: 10, z: 30, yaw: 90 }, { kind: 'floor', color: st.pc, color2: st.pc2, name: 'К BHOP-АЛЛЕЕ' });
  // ориентир: финиш-арка на башне (в FREE ROAM забег не завершается)
  buildFinish({ x: 14, y: 22, z: -30, col: tw.col });
  // деревья/фонари
  for (let i = 0; i < 46; i++) {
    const x = (rnd() - .5) * 112, z = (rnd() - .5) * 112; if (Math.abs(x) < 12 && z > 20) continue; if (Math.hypot(x + 20, z + 5) < 24 && z < 12 && z > -25) continue;
    if (st.night) lamp(x, 10, z, pick(NEON), 3 + rnd() * 2);
    else { const h = 3 + rnd() * 3; cyl('wood', 0x7a5a3a, x, 10 + h / 2, z, .25, .35, h, 'y', 6); cyl('plain', pick([0x4e9a3a, 0x5fae4a, 0x3f8a3a]), x, 10 + h + 1.4, z, 0, 1.9, 3.6, 'y', 8); }
  }
  if (st.night) { scatter({ side: 'nfacade', top: 'roof', tints: [0xffffff], hMax: 120, n: 60, minD: 80, span: 130, neon: NEON }); }
  else { scatter({ minD: 70, span: 140, n: 34, hMin: 8, hMax: 60, fn: (x, z, w, d, top) => { cyl('rock', pick([0xb0a898, 0x9a9284, 0xc2bcae]), x, (W.groundY + top) / 2, z, w * .5, w * .8, top - W.groundY, 'y', 8); } }); }
  W.route.push({ x: 0, y: 10, z: 46 }, { x: 14, y: 22, z: -30 }); W.end = -20;
  return { main };
}
export function buildFreeIsland() {
  freeWorld({ gy: -60, side: 'concrete', top: 'plain', tint: 0x6ab04c, under: 0xa09078, surfKey: 'surf', t1: 0x4fd8ff, t2: 0xff8a3c, pc: 0x7a5cff, pc2: 0x3de0ff, night: false });
  finishAndGround(-60, 0xcfe8ff, false, [24, -20, 20, .9, 1.4]);
}
export function buildFreeNight() {
  freeWorld({ gy: -70, side: 'concrete', top: 'concrete', tint: 0x2d3350, under: 0x1b1f33, surfKey: 'neon', t1: 0x00e5ff, t2: 0xff2fd0, pc: 0xff2fd0, pc2: 0x00e5ff, night: true });
  finishAndGround(-70, 0x070914, false);
}
