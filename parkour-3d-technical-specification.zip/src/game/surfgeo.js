// Геометрия SURF-жёлоба (V-образного): чистая математика без Three/DOM — используется и картами, и тестами.
// Жёлоб задаётся линией дна: старт (x,y,z), курс yaw, тангаж pitch (<0 — спуск по ходу), длина L.
// Возвращает параметры плит для core.obb(cx,cy,cz,hx,hy,hz,rx=pitch,ry=yaw,rz=roll,...).
export function troughSlabs(sx, sy, sz, yaw, pitch, L, o) {
  o = Object.assign({ th: 0.9, thL: null, thR: null, w: 12, hy: 0.5, ov: 0.3, sides: 'LR', ext: 0.12 }, o || {});
  const cy = Math.cos(yaw), sny = Math.sin(yaw), cp = Math.cos(pitch), sp = Math.sin(pitch);
  const f = [-sny * cp, sp, -cy * cp], ex = [cy, 0, -sny], ey = [sp * sny, cp, sp * cy];
  const out = [];
  [1, -1].forEach(side => {
    if (o.sides.indexOf(side > 0 ? 'R' : 'L') < 0) return;
    const th = side > 0 ? (o.thR || o.th) : (o.thL || o.th);
    const u = o.w / 2 - o.ov, ox = side * (u * Math.cos(th) + o.hy * Math.sin(th)), oy = u * Math.sin(th) - o.hy * Math.cos(th);
    out.push({
      cx: sx + f[0] * L / 2 + ex[0] * ox + ey[0] * oy, cy: sy + f[1] * L / 2 + ex[1] * ox + ey[1] * oy, cz: sz + f[2] * L / 2 + ex[2] * ox + ey[2] * oy,
      hx: o.w / 2, hy: o.hy, hz: L / 2 + o.ext, rx: pitch, ry: yaw, rz: side * th, side, th
    });
  });
  return { slabs: out, end: [sx + f[0] * L, sy + f[1] * L, sz + f[2] * L], f };
}
