// Настройки, рекорды, статистика и достижения (localStorage).
// Любое чтение защищено: повреждённые/отсутствующие данные заменяются значениями по умолчанию.
export const LS = {
  get(k, d) { try { const v = localStorage.getItem(k); if (v === null) return d; const j = JSON.parse(v); return j === null || j === undefined ? d : j; } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } },
  del(k) { try { localStorage.removeItem(k); } catch (e) { /* ignore */ } }
};
const isObj = v => v && typeof v === 'object' && !Array.isArray(v);
const num = (v, a, b, d) => (typeof v === 'number' && isFinite(v) ? Math.min(b, Math.max(a, v)) : d);

const isMobile = /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent || '') || (navigator.maxTouchPoints > 1 && Math.min(screen.width, screen.height) < 900);

export const HUD_KEYS = [
  ['main', 'Главный счётчик (время)'], ['falls', 'Падения'], ['cp', 'Контрольные точки'], ['prog', 'Прогресс'],
  ['speed', 'Скорость'], ['max', 'Макс. скорость'], ['bhop', 'Успешные BHOP подряд'], ['air', 'Состояние: земля / воздух / surf'], ['mode', 'Режим и карта']
];

const DEFAULTS = {
  sens: 1, volume: 0.7, sfx: 1, music: true, sound: true, quality: isMobile ? 1 : 2,
  vibration: true, bob: true, tilt: true, speedFx: true, knife: true, autoHop: isMobile, fs: false,
  smooth: 0.35, lookAccel: 0.3, pitchLimit: 1.35, fov: 72,
  map: 'city', mode: 'parkour'
};
export const S = Object.assign({}, DEFAULTS, { hud: { main: true, falls: true, cp: true, prog: true, speed: true, max: true, bhop: true, air: true, mode: true } });

function loadSettings() {
  const raw = LS.get('pk3d_settings', {});
  if (!isObj(raw)) return;
  Object.keys(DEFAULTS).forEach(k => { if (typeof raw[k] === typeof DEFAULTS[k]) S[k] = raw[k]; });
  S.sens = num(S.sens, 0.3, 2.5, 1); S.volume = num(S.volume, 0, 1, 0.7); S.sfx = num(S.sfx, 0, 1, 1);
  S.quality = Math.round(num(S.quality, 0, 3, DEFAULTS.quality)); S.smooth = num(S.smooth, 0, 0.9, 0.35); S.lookAccel = num(S.lookAccel, 0, 1, 0.3); S.pitchLimit = num(S.pitchLimit, 0.8, 1.5, 1.35); S.fov = num(S.fov, 60, 100, 72);
  if (isObj(raw.hud)) Object.keys(S.hud).forEach(k => { if (typeof raw.hud[k] === 'boolean') S.hud[k] = raw.hud[k]; });
}
loadSettings();
export const saveSettings = () => LS.set('pk3d_settings', S);

export const fmt = t => { if (!isFinite(t)) t = 0; const m = Math.floor(t / 60), s = t - m * 60; return (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s.toFixed(2); };

/* ---------- рекорды: ключ "режим|карта" ---------- */
let REC = LS.get('pk3d_rec2', {}); if (!isObj(REC)) REC = {};
const legacyKey = id => (id === 'city' ? 'pk3d_best' : 'pk3d_best_' + id);
export function getRec(mode, map) {
  const v = REC[mode + '|' + map];
  if (typeof v === 'number' && isFinite(v)) return v;
  if (mode === 'classic') { try { const o = parseFloat(localStorage.getItem(legacyKey(map))); if (isFinite(o)) return o; } catch (e) { /* ignore */ } }
  return null;
}
// lower=true: чем меньше, тем лучше (время). Возвращает true, если это новый рекорд.
export function setRec(mode, map, v, lower) {
  const old = getRec(mode, map);
  if (old === null || (lower ? v < old : v > old)) { REC[mode + '|' + map] = v; LS.set('pk3d_rec2', REC); return true; }
  return false;
}

/* ---------- статистика ---------- */
const ADD = ['attempts', 'finishes', 'falls', 'bhops', 'jumps', 'distance', 'playTime'];
const MAXK = ['maxSpeed', 'bestStreak'];
const blank = () => { const o = {}; ADD.concat(MAXK).forEach(k => { o[k] = 0; }); return o; };
let ST = LS.get('pk3d_stats2', null);
if (!isObj(ST) || !isObj(ST.total) || !isObj(ST.maps) || !isObj(ST.modes)) ST = { total: blank(), maps: {}, modes: {} };
export const STATS = ST;
function merge(dst, d) {
  ADD.forEach(k => { if (typeof d[k] === 'number' && isFinite(d[k])) dst[k] = (typeof dst[k] === 'number' ? dst[k] : 0) + d[k]; });
  MAXK.forEach(k => { if (typeof d[k] === 'number' && isFinite(d[k])) dst[k] = Math.max(typeof dst[k] === 'number' ? dst[k] : 0, d[k]); });
}
export function addStats(d, mapId, modeId) {
  merge(ST.total, d);
  if (mapId) merge(ST.maps[mapId] || (ST.maps[mapId] = blank()), d);
  if (modeId) merge(ST.modes[modeId] || (ST.modes[modeId] = blank()), d);
  LS.set('pk3d_stats2', ST);
}
// все рекорды карты по режимам: { режим: значение }
export function recsForMap(map) {
  const out = {}; Object.keys(REC).forEach(k => { const [m, id] = k.split('|'); if (id === map) out[m] = REC[k]; });
  if (out.classic === undefined) { const o = getRec('classic', map); if (o !== null) out.classic = o; }
  return out;
}
export function recsForMode(mode) {
  const out = {}; Object.keys(REC).forEach(k => { const [m, id] = k.split('|'); if (m === mode) out[id] = REC[k]; });
  return out;
}

/* ---------- достижения ---------- */
let ACH = LS.get('pk3d_ach', {}); if (!isObj(ACH)) ACH = {};
export const ACHIEVED = ACH;
export function unlockAch(id) { if (ACH[id]) return false; ACH[id] = Date.now(); LS.set('pk3d_ach', ACH); return true; }

export function resetAllProgress() {
  LS.del('pk3d_rec2'); LS.del('pk3d_stats2'); LS.del('pk3d_ach'); LS.del('pk3d_best'); LS.del('pk3d_rank'); location.reload();
}
