// Система рангов: 10 рангов с уникальными SVG-эмблемами, опыт за реальные результаты, история повышений (localStorage).
import { LS } from './state.js';
const G = (id, a, b) => '<linearGradient id="' + id + '" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="' + a + '"/><stop offset="1" stop-color="' + b + '"/></linearGradient>';
const svg = (inner, defs) => '<svg viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg"><defs>' + (defs || '') + '</defs>' + inner + '</svg>';
export const RANKS = [
  { id: 'rookie', name: 'ROOKIE', xp: 0, color: '#9aa7b2', icon: svg('<circle cx="32" cy="32" r="26" fill="url(#r1)" stroke="#d6dde3" stroke-width="3"/><path d="M18 36l14-12 14 12v7L32 31 18 43z" fill="#eef3f6"/>', G('r1', '#6b7782', '#3b434b')) },
  { id: 'beginner', name: 'BEGINNER', xp: 150, color: '#7bd66a', icon: svg('<path d="M32 6l22 10v20c0 12-9 20-22 24C19 56 10 48 10 36V16z" fill="url(#r2)" stroke="#d5f5c8" stroke-width="2.5"/><path d="M32 46V28M32 34c-8 0-11-5-11-10 7 0 11 4 11 10zM32 30c0-6 4-10 11-10 0 6-4 10-11 10z" fill="#f4ffe9" stroke="#f4ffe9" stroke-width="1.5" stroke-linejoin="round"/>', G('r2', '#4ea43e', '#25601f')) },
  { id: 'amateur', name: 'AMATEUR', xp: 400, color: '#cd8b4a', icon: svg('<path d="M10 14h44v24L32 58 10 38z" fill="url(#r3)" stroke="#ffd9b0" stroke-width="2.5" stroke-linejoin="round"/><path d="M18 26l14 9 14-9M18 35l14 9 14-9" fill="none" stroke="#fff2e0" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>', G('r3', '#d99a58', '#8a4f1e')) },
  { id: 'skilled', name: 'SKILLED', xp: 800, color: '#2fd0c0', icon: svg('<path d="M32 4l24 14v28L32 60 8 46V18z" fill="url(#r4)" stroke="#bffaf2" stroke-width="2.5" stroke-linejoin="round"/><path d="M32 17l4.6 9.6 10.4 1.4-7.6 7.2 2 10.4L32 40.4 22.6 45.6l2-10.4L17 28l10.4-1.4z" fill="#eafffb"/>', G('r4', '#2fd0c0', '#0f6f78')) },
  { id: 'advanced', name: 'ADVANCED', xp: 1400, color: '#4a9dff', icon: svg('<path d="M32 4l24 8v22c0 14-10 22-24 28C18 56 8 48 8 34V12z" fill="url(#r5)" stroke="#cfe5ff" stroke-width="2.5" stroke-linejoin="round"/><path d="M36 10L20 36h10l-4 18 18-28H33z" fill="#fff3a8" stroke="#fffbe0" stroke-width="1.5" stroke-linejoin="round"/>', G('r5', '#4a9dff', '#1b3f9a')) },
  { id: 'expert', name: 'EXPERT', xp: 2200, color: '#b36bff', icon: svg('<path d="M32 4l24 20-24 36L8 24z" fill="url(#r6)" stroke="#ecd6ff" stroke-width="2.5" stroke-linejoin="round"/><path d="M8 24h48M32 4l-9 20 9 36 9-36z" fill="none" stroke="#f6ecff" stroke-width="2" stroke-linejoin="round" opacity=".85"/>', G('r6', '#c58bff', '#5a22b0')) },
  { id: 'master', name: 'MASTER', xp: 3300, color: '#ff4d6d', icon: svg('<path d="M32 14l12 6v14c0 8-5 13-12 16-7-3-12-8-12-16V20z" fill="url(#r7)" stroke="#ffd0d9" stroke-width="2.2" stroke-linejoin="round"/><path d="M20 22C12 20 6 24 3 32c6-2 10-1 14 3-4-1-8 0-11 3 6 3 12 2 15-2zM44 22c8-2 14 2 17 10-6-2-10-1-14 3 4-1 8 0 11 3-6 3-12 2-15-2z" fill="#ffe0e6" stroke="#ff9fb2" stroke-width="1.2"/><circle cx="32" cy="30" r="4" fill="#fff"/>', G('r7', '#ff5d7a', '#8c1030')) },
  { id: 'elite', name: 'ELITE', xp: 4800, color: '#ffc83a', icon: svg('<circle cx="32" cy="36" r="22" fill="url(#r8)" stroke="#fff0b0" stroke-width="3"/><path d="M14 22l6 10 8-12 4 12 4-12 8 12 6-10v16H14z" fill="#fff6c8" stroke="#a96b00" stroke-width="1.6" stroke-linejoin="round"/><circle cx="14" cy="22" r="2.4" fill="#fff"/><circle cx="32" cy="14" r="2.4" fill="#fff"/><circle cx="50" cy="22" r="2.4" fill="#fff"/><rect x="18" y="42" width="28" height="5" rx="2" fill="#a96b00" opacity=".55"/>', G('r8', '#ffd45a', '#c27a00')) },
  { id: 'veteran', name: 'VETERAN', xp: 6800, color: '#dfe8f2', icon: svg('<path d="M32 58C14 52 6 38 8 22c4 2 8 6 9 11-1-8 1-15 6-21 2 4 2 9 0 13 3-4 5-9 9-12 4 3 6 8 8 12-2-4-2-9 0-13 5 6 7 13 6 21 1-5 5-9 9-11 2 16-6 30-24 36z" fill="url(#r9)" stroke="#ffffff" stroke-width="2" stroke-linejoin="round" transform="translate(0 -2)"/><path d="M32 22l4 8.5 9 1.2-6.5 6.2 1.7 9L32 42.6 23.8 46.9l1.7-9L19 31.7l9-1.2z" fill="#6a7a8c"/>', G('r9', '#f6fbff', '#8fa3b8')) },
  { id: 'legend', name: 'LEGEND', xp: 9500, color: '#ff9a1f', icon: svg('<g stroke="#fff3b0" stroke-width="3" stroke-linecap="round"><path d="M32 2v8M32 54v8M2 32h8M54 32h8M11 11l6 6M47 47l6 6M53 11l-6 6M17 47l-6 6"/></g><path d="M32 8l6 14 15-1-11 10 5 14-15-8-15 8 5-14L11 21l15 1z" fill="url(#r10)" stroke="#fff6c8" stroke-width="2" stroke-linejoin="round"/><path d="M20 50l4-9 8 5 8-5 4 9z" fill="#ff4d2e" stroke="#ffe08a" stroke-width="1.6" stroke-linejoin="round"/><circle cx="32" cy="29" r="5" fill="#fff"/>', G('r10', '#fff08a', '#ff6a00')) }
];
let ST = LS.get('pk3d_rank', null);
if (!ST || typeof ST !== 'object' || !isFinite(ST.xp)) ST = { xp: 0, hist: [], seen: {} };
if (!Array.isArray(ST.hist)) ST.hist = []; if (!ST.seen || typeof ST.seen !== 'object') ST.seen = {};
const save = () => LS.set('pk3d_rank', ST);
export const rankIndex = xp => { let r = 0; RANKS.forEach((k, i) => { if (xp >= k.xp) r = i; }); return r; };
export function rankState() {
  const i = rankIndex(ST.xp), cur = RANKS[i], nxt = RANKS[i + 1] || null;
  return { xp: Math.round(ST.xp), i, rank: cur, next: nxt, into: ST.xp - cur.xp, need: nxt ? nxt.xp - cur.xp : 1, pct: nxt ? Math.min(1, (ST.xp - cur.xp) / (nxt.xp - cur.xp)) : 1, hist: ST.hist.slice().reverse() };
}
// Опыт за результат: зависит от карты/режима/времени/техники. Повторные прохождения дают мало, рекорды — бонус.
export function awardRun(o) {
  const key = o.mode + '|' + o.map; const first = !ST.seen[key]; ST.seen[key] = (ST.seen[key] || 0) + 1;
  let xp = [0, 60, 100, 150][o.diff] || 60; const lines = [['Прохождение карты', 0]];
  if (o.mode === 'speedrun') xp *= 1.3; if (o.mode === 'timeattack') xp *= 1.2;
  if (!first) xp *= 0.35;
  lines[0][1] = Math.round(xp);
  if (o.par && o.time >= o.par * 0.25) { const r = o.par / o.time; const b = Math.round(xp * 0.8 * Math.max(0, Math.min(1.5, r) - 0.6)); if (b > 0) lines.push(['Время относительно эталона', b]); }
  if (o.falls === 0) lines.push(['Без падений', Math.round(xp * 0.25)]);
  if (first) lines.push(['Первое прохождение', 50]); if (o.pb && !first) lines.push(['Личный рекорд', 40]);
  if (o.cat === 'bhop') { const b = Math.round(Math.min(60, o.streak * 3 + Math.max(0, o.maxSpeed - 10) * 4)); if (b > 0) lines.push(['Результат BHOP (серия/скорость)', b]); }
  if (o.cat === 'surf') { const b = Math.round(Math.min(60, Math.max(0, o.maxSpeed - 12) * 5 + (o.surfTime || 0) * 1.5)); if (b > 0) lines.push(['Результат SURF', b]); }
  if (o.cat === 'parkour') { const b = Math.round(Math.min(40, (o.cps || 0) * 4)); if (b > 0) lines.push(['Пройденные маршруты PARKOUR', b]); }
  const gain = lines.reduce((s, l) => s + l[1], 0), old = rankIndex(ST.xp);
  ST.xp += gain; const nw = rankIndex(ST.xp);
  for (let k = old + 1; k <= nw; k++) ST.hist.push({ t: Date.now(), rank: RANKS[k].id, xp: Math.round(ST.xp), why: o.map });
  save(); return { gain, lines, oldRank: old, newRank: nw, up: nw > old };
}
export function resetRank() { LS.del('pk3d_rank'); }
