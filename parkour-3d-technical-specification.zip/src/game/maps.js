// Каталог карт. Категория (cat) и список поддерживаемых режимов (modes) заданы в ДАННЫХ карты — фильтрация не визуальная:
// PARKOUR ↔ cat:'parkour', BHOP ↔ cat:'bhop', SURF ↔ cat:'surf', FREE ROAM ↔ cat:'free'. SPEEDRUN и TIME ATTACK — режимы на время для маршрутных карт.
import { S } from './state.js';
import { W, resetWorld, seed, applyAtmosphere, buildBatches, qualityParams } from './core.js';
import { CPS } from './collision.js';
import { buildCity, buildIndustrial, buildSky, buildNight, buildPure } from './maps_parkour.js';
import { buildBhop, buildTowerBhop, buildBhopIndustrial, buildBhopNeon } from './maps_bhop.js';
import { buildSurfClassic, buildSurfSpace, buildSurfNeon, buildSurfCanyon } from './maps_surf.js';
import { buildFreeIsland, buildFreeNight } from './maps_free.js';

const TIMED = ['timeattack', 'speedrun'];
const mk = (cat, o) => Object.assign({ cat, modes: [cat].concat(TIMED), tags: [] }, o);
export const MAPS = [
  /* ---------------- PARKOUR ---------------- */
  mk('parkour', { id: 'city', name: 'CITY ROOFTOPS', diff: 2, seed: 20240607, build: buildCity, par: 150, route: '9 крыш · 3 развилки · балки и трубы', theme: 'city', tags: ['РАЗВИЛКИ', 'ВЕРТИКАЛЬ'],
    desc: 'Крыши разной высоты, вентиляция, балки, трубы, барьеры для vault и три параллельных маршрута перед финишем.',
    atmo: { sky: [0x2f86e0, 0x86beef, 0xcfe4f6], fog: [0xcfe4f6, 50, 320], hemi: [0xcfe6ff, 0x9a9488, .85], sun: [0xfff0d8, .95, [.7, .55, .3]] } }),
  mk('parkour', { id: 'industrial', name: 'INDUSTRIAL ZONE', diff: 2, seed: 777, build: buildIndustrial, par: 170, route: 'Цеха · конвейеры · лифт · портал-шорткат', theme: 'industrial', tags: ['ПОРТАЛ', 'ПОДВИЖНЫЕ'],
    desc: 'Завод: ржавые настилы, огромные трубы, контейнеры, конвейерные платформы, лифт и портал в полу, ведущий в последний цех.',
    atmo: { sky: [0x4d5f70, 0xa8a193, 0xdcb98c], fog: [0xd2ad84, 40, 260], hemi: [0xe6d6c0, 0x6a5848, .8], sun: [0xffd9a8, .9, [-.6, .5, .4]], sunSpriteColor: 0xffc890 } }),
  mk('parkour', { id: 'sky', name: 'SKY PARKOUR', diff: 3, seed: 99, build: buildSky, par: 190, route: 'Острова над облаками · мосты · портал', theme: 'sky', tags: ['ПОРТАЛ', 'ВЫСОТА'],
    desc: 'Платформы высоко над облаками: длинные прыжки, узкие мосты, движущиеся облака, большой разрыв и облачный портал-шорткат.',
    atmo: { sky: [0x1c6fe0, 0x7fc3ff, 0xf6fbff], fog: [0xe3f1ff, 80, 420], hemi: [0xffffff, 0xb8c8e0, .95], sun: [0xfff6e0, 1.0, [.4, .7, .3]] } }),
  mk('parkour', { id: 'night', name: 'NIGHT CITY', diff: 3, seed: 4242, build: buildNight, par: 185, route: 'Неоновые крыши · секретный путь через портал', theme: 'night', tags: ['СЕКРЕТ', 'НЕОН'],
    desc: 'Ночной город: неоновые вывески, высотки, три маршрута по крышам и тайный портал на скрытую площадку.',
    atmo: { sky: [0x04060f, 0x121a44, 0x2c2260], fog: [0x161a3c, 30, 240], hemi: [0x7f8fe0, 0x1a1230, .8], sun: [0x9fb4ff, .55, [-.5, .6, .5]], sunSpriteColor: 0xb8c8ff } }),
  mk('parkour', { id: 'pure', name: 'PURE PARKOUR', diff: 3, seed: 1313, build: buildPure, par: 175, route: 'Полоса препятствий · wall run · vault', theme: 'pure', tags: ['WALL RUN', 'VAULT'],
    desc: 'Полноценная полоса препятствий: барьеры для vault, узкие балки, коридоры wall run над пропастью, вертикальный подъём и развилка.',
    atmo: { sky: [0x3b6ea8, 0x9fc0e0, 0xe8eef2], fog: [0xe0e8ee, 50, 300], hemi: [0xf0f4ff, 0x8a8c90, .9], sun: [0xfff4e0, .95, [.5, .7, .4]] } }),
  /* ---------------- BHOP ---------------- */
  mk('bhop', { id: 'bhop_classic', name: 'BHOP CLASSIC', diff: 2, seed: 5150, build: buildBhop, par: 150, route: 'Разгоны 40–50 м · серии прыжков · повороты', theme: 'bhop', tags: ['РАЗГОН', 'ЗИГЗАГИ'],
    desc: 'Классика: длинные участки для разгона, последовательные платформы с растущими зазорами, повороты и сложные финальные серии.',
    atmo: { sky: [0x120a30, 0x4a1c6e, 0xff6aa0], fog: [0x3a1a5a, 40, 280], hemi: [0xd0b0ff, 0x301848, .85], sun: [0xffa0d0, .7, [-.5, .5, .4]], sunSpriteColor: 0xffb0e0 } }),
  mk('bhop', { id: 'bhop_tower', name: 'BHOP TOWER', diff: 3, seed: 8080, build: buildTowerBhop, par: 200, route: 'Спираль вверх · спуск прыжками · портал', theme: 'tower', tags: ['ВЕРТИКАЛЬ', 'ПОРТАЛ'],
    desc: 'Вертикальная башня: подъём по спирали на разных уровнях, прыжки между высотами, спуск длинными прыжками и портал-шорткат.',
    atmo: { sky: [0x050816, 0x1a2a5a, 0x5a5ab0], fog: [0x1a2248, 40, 300], hemi: [0xa0b8ff, 0x20244a, .85], sun: [0xb0c0ff, .6, [-.4, .7, .3]], sunSpriteColor: 0xc0d0ff } }),
  mk('bhop', { id: 'bhop_industrial', name: 'BHOP INDUSTRIAL', diff: 3, seed: 9191, build: buildBhopIndustrial, par: 190, route: 'Трубы · узкие настилы · конвейер', theme: 'industrial', tags: ['УЗКИЕ', 'ПОВОРОТЫ'],
    desc: 'Промышленные конструкции: узкие платформы между цехами, сложные повороты, трубы-разгоны и подвижные конвейеры.',
    atmo: { sky: [0x403830, 0x9a8a78, 0xe0a870], fog: [0xd0a070, 40, 260], hemi: [0xe6d0b0, 0x5a4838, .8], sun: [0xffc890, .9, [-.6, .45, .4]], sunSpriteColor: 0xffb870 } }),
  mk('bhop', { id: 'bhop_neon', name: 'BHOP NEON GRID', diff: 3, seed: 6161, build: buildBhopNeon, par: 210, route: 'Змейка из 6 отрезков · неоновые кольца', theme: 'neon', tags: ['ЗМЕЙКА', 'НЕОН'],
    desc: 'Неоновая змейка: шесть отрезков с поворотами на 90°, зигзаги на нарастающей скорости и светящиеся кольца-ориентиры.',
    atmo: { sky: [0x02030a, 0x0a1a3a, 0x182a60], fog: [0x0a1030, 30, 260], hemi: [0x6a90ff, 0x100830, .8], sun: [0x80a0ff, .5, [-.3, .6, .4]], sunSpriteColor: 0x90b0ff } }),
  /* ---------------- SURF ---------------- */
  mk('surf', { id: 'surf_classic', name: 'SURF CLASSIC', diff: 2, seed: 3001, build: buildSurfClassic, par: 80, route: 'Дуги · прыжки между рампами · 3 пути', theme: 'surf', tags: ['РАМПЫ', 'РАЗВИЛКА'],
    desc: 'Классические треугольные рампы под разными углами, плавные дуги, прыжки между жёлобами и развилка на три маршрута.',
    atmo: { sky: [0x2f86e0, 0x86beef, 0xe6f2fc], fog: [0xcfe4f6, 90, 520], hemi: [0xcfe6ff, 0x9a9488, .9], sun: [0xfff0d8, 1, [.6, .6, .3]] } }),
  mk('surf', { id: 'surf_space', name: 'SURF SPACE', diff: 3, seed: 3002, build: buildSurfSpace, par: 95, route: 'Огромные рампы · launch-трамплины · 3 пути', theme: 'space', tags: ['КОСМОС', 'ВЫСОКИЕ ПРЫЖКИ'],
    desc: 'Космос: огромные наклонные рампы среди планет, трамплины запуска, высокие прыжки между жёлобами и необычная геометрия.',
    atmo: { sky: [0x000000, 0x070418, 0x1a0a40], fog: [0x050210, 160, 900], hemi: [0xb0a0ff, 0x100830, .95], sun: [0xc0b0ff, .8, [-.4, .6, .4]], sunSprite: false } }),
  mk('surf', { id: 'surf_neon', name: 'SURF NEON', diff: 3, seed: 3003, build: buildSurfNeon, par: 100, route: 'Светящиеся рампы · S-образные повороты', theme: 'neon', tags: ['НЕОН', 'ПОВОРОТЫ'],
    desc: 'Неоновые конструкции: светящиеся рампы, сложные S-повороты, разворот на 180° и серия прыжков между жёлобами.',
    atmo: { sky: [0x02030a, 0x100a30, 0x2a1060], fog: [0x0a0828, 80, 500], hemi: [0x8a80ff, 0x100830, .85], sun: [0xff80e0, .6, [-.3, .6, .4]], sunSpriteColor: 0xff90e8 } }),
  mk('surf', { id: 'surf_canyon', name: 'SURF CANYON', diff: 2, seed: 3004, build: buildSurfCanyon, par: 90, route: 'Спираль-воронка · каньон на закате · 3 пути', theme: 'canyon', tags: ['СПИРАЛЬ', 'КАНЬОН'],
    desc: 'Каньон на закате: каменные рампы, спираль-воронка на 360°, развилка и прыжки через пропасти.',
    atmo: { sky: [0x3f60b0, 0xf2a870, 0xffd8a8], fog: [0xf0b890, 70, 480], hemi: [0xffe0c0, 0x8a6048, .9], sun: [0xffc080, 1.05, [.8, .35, .2]], sunSpriteColor: 0xffb060 } }),
  /* ---------------- FREE ROAM ---------------- */
  { cat: 'free', modes: ['freeroam'], id: 'free_island', name: 'TRAINING ISLAND', diff: 1, seed: 7001, build: buildFreeIsland, par: 0, route: 'Остров · сад · BHOP-аллея · SURF-спуск · порталы', theme: 'island', tags: ['ПОРТАЛЫ', 'ОТКРЫТАЯ'],
    desc: 'Просторный остров для тренировки: парковый сад, BHOP-аллея, SURF-спуск с башни и порталы между зонами.',
    atmo: { sky: [0x2f86e0, 0x86beef, 0xe6f2fc], fog: [0xdceaf6, 90, 520], hemi: [0xffffff, 0xa0a890, .95], sun: [0xfff0d8, 1, [.6, .65, .3]] } },
  { cat: 'free', modes: ['freeroam'], id: 'free_night', name: 'NEON PLAYGROUND', diff: 1, seed: 7002, build: buildFreeNight, par: 0, route: 'Ночной район · неоновые зоны · порталы', theme: 'night', tags: ['ПОРТАЛЫ', 'НОЧЬ'],
    desc: 'Ночная площадка в неоне: свободное исследование, BHOP-линия, SURF-спуск и сеть порталов.',
    atmo: { sky: [0x04060f, 0x121a44, 0x2c2260], fog: [0x161a3c, 40, 320], hemi: [0x7f8fe0, 0x1a1230, .85], sun: [0x9fb4ff, .55, [-.5, .6, .5]], sunSpriteColor: 0xb8c8ff } }
];

export const CAT_OF_MODE = { parkour: 'parkour', bhop: 'bhop', surf: 'surf', freeroam: 'free' };
export const mapById = id => MAPS.find(m => m.id === id);
// карты режима: строго по данным (map.modes), без визуальной фильтрации
export const mapsForMode = mode => MAPS.filter(m => m.modes.indexOf(mode) >= 0);

export function loadMap(id) {
  const m = mapById(id) || MAPS[0];
  resetWorld(); W.decor = qualityParams().decor; W.decorLevel = S.quality; W.route = []; W.branches = [];
  seed(m.seed); applyAtmosphere(m.atmo); W.id = m.id;
  m.build(); buildBatches();
  return m;
}
export const cpCount = () => CPS.length;
